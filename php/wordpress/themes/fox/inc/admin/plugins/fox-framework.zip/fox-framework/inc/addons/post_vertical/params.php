<?php
$params = foxfw3_query_params();
$params += foxfw3_generate_options([

    'base' => 'grid',
    'exclude' => [
        'first_standard',
        'item_card',
        'item_card_background',
        'item_border',
        'item_border_color',
        'list_sep',
        'list_sep_style',
        'list_sep_color',
        
        'column',
        'item_spacing',
        'item_align',
        'list_spacing',
        'list_valign',
        // 'thumbnail',
        'thumbnail_custom',
        'thumbnail_width',
        'thumbnail_placeholder',
        'thumbnail_shape',
        'list_mobile_layout',
        // 'title_size',
    ],
    'override' => [
        'thumbnail_position' => [
            'title' => 'Thumbnail Position',
        ],
        'thumbnail' => [
            /*
            'options' => [
                'landscape' => 'Landscape',
                'square' => 'Square',
                'portrait' => 'Portrait',
                'large' => 'Original (No Crop)',
                'custom' => 'Custom',
            ],
            */
            'std' => 'large',
        ],
    ],

    'append' => [
        'thumbnail_type' => array (
            'title' => 'Thumbnail type',
            'type' => 'select',
            'options' => [
                'advanced' => 'Full slider, video etc',
                'simple' => 'Just simple image thumbnail',
            ],
            'std' => 'simple',
            'after' => 'show_thumbnail',
        ),
    ],

    'context' => 'elementor',
    'section' => 'layout',
    'section_title' => 'Layout',

]);
<?php
get_header(); ?>

<?php
while ( have_posts() ) : the_post();

        $block_id = $final_block_id;
    if ( $block_id ) {
        if ( function_exists( 'fox_block' ) ) {
            ?>
<div class="archive-builder">
    
    <div class="container">
        
        <?php fox_block( $block_id ); ?>
        
    </div>
    
</div><!-- .archive-builder -->
<?php
        } else {
            echo '<em>Please install Fox Framework to use this feature.</em>';
        }
    } else {
        echo '<em>Please create at least 1 Archive Template in Dashboard > FOX Blocks.</em>';
    } 

endwhile;
?>

<?php get_footer();
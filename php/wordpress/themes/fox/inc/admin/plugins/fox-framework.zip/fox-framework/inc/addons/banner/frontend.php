<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    'source' => 'banner',
    'code' => '',
    
    'image' => '',
    'link' => '',
    
    // tablet
    'tablet_image' => '',
    'tablet_link' => '',
    
    // mobile
    'mobile_link' => '',
    'mobile_image' => '',
]) );

$cl = [ 'el-ad' ];

/* Source
------------------------ */
if ( 'code' == $source ) {
    $cl[] = 'el-code';
} else {
    $cl[] = 'el-banner';
}

/* Final
------------------------ */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <?php if ( 'code' == $source ) { ?>
    
    <?php echo do_shortcode( $code ); ?>
    
    <?php } else { ?>
    
    <div class="the-banner">
    
        <?php if ( $link[ 'url' ] ) {
            $this->add_link_attributes( 'link', $link ); ?>
        <a class="banner-link desktop-link" <?php $this->print_render_attribute_string( 'link' ); ?>></a>
        <?php } ?>
        
        <?php if ( $tablet_link[ 'url' ] ) {
            $this->add_link_attributes( 'tablet_link', $tablet_link ); ?>
        <a class="banner-link tablet-link" <?php $this->print_render_attribute_string( 'tablet_link' ); ?>></a>
        <?php } ?>
        
        <?php if ( $mobile_link[ 'url' ] ) {
            $this->add_link_attributes( 'mobile_link', $mobile_link ); ?>
        <a class="banner-link mobile-link" <?php $this->print_render_attribute_string( 'mobile_link' ); ?>></a>
        <?php } ?>
        
        <?php if ( ! empty( $mobile_image[ 'id'] ) ) { ?>
        <div class="the-image mobile-image">
            <?php echo wp_get_attachment_image( $mobile_image[ 'id' ], 'full' ); ?>
        </div>
        <?php } ?>
            
        <?php if ( ! empty( $tablet_image[ 'id'] ) ) { ?>
        <div class="the-image tablet-image">
            <?php echo wp_get_attachment_image( $tablet_image[ 'id' ], 'full' ); ?>
        </div>
        <?php } ?>
        
        <?php if ( ! empty( $image[ 'id'] ) ) { ?>
        <div class="the-image desktop-image">
            <?php echo wp_get_attachment_image( $image[ 'id' ], 'full' ); ?>
        </div>
        <?php } ?>
        
    </div><!-- .the-banner -->
    
    <?php } ?>
    
</div><!-- .el-ad -->
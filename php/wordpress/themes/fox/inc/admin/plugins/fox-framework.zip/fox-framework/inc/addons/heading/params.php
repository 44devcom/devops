<?php
$params[ 'title' ] = array(
    'type' => 'textarea',
    'title' => 'Title',
    'std' => 'Enter title here',

    'section' => 'heading',
    'section_title' => 'Heading',
);

$params[ 'title_tag' ] = array(
    'type' => 'select',
    'title' => 'Title tag',
    'options' => [
        'h1' => 'H1',
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
        'p' => 'p',
        'span' => 'span',
        'div' => 'div',
    ],
    'std' => 'h2',
);

$params[ 'title_color' ] = array(
    'type' => 'color',
    'title' => 'Custom title color',
    'selectors' => [
        '{{WRAPPER}} .heading-title-main' => 'color: {{VALUE}};'
    ],
);

$params[ 'title_typography' ] = array(
    'type' => 'typography',
    'title' => 'Title typography',
    'selector' => '{{WRAPPER}} .heading-title-main',
);

$params[ 'title_size' ] = array(
    'type' => 'select',
    'options' => [
        'large' => 'Large',
        'medium' => 'Medium',
        'normal' => 'Normal',
        'small' => 'Small',
        'tiny' => 'Tiny',
        'supertiny' => 'Supertiny',
    ],
    'std' => 'large',
    'title' => 'Title size',
);

/*
removed when we have typography already
$params[ 'title_text_transform' ] = array(
    'type' => 'select',
    'options' => [
        '' => 'Default',
        'none' => 'None',
        'uppercase' => 'UPPERCASE',
        'lowercase' => 'lowercase',
        'capitalize' => 'Capitalize',
    ],
    'std' => '',
    'title' => 'Text transform',
);
*/

$params[ 'line' ] = array(
    'type' => 'select',
    'options' => [
        '' => 'None',
        '1px' => 'Solid 1px',
        '2px' => 'Solid 2px',
        '3px' => 'Solid 3px',
        '4px' => 'Solid 4px',
        'dashed' => 'Dashed',
        'double' => 'Double',
        'wave' => 'Wave',
    ],
    'std' => '',
    'title' => 'Horizontal Line',
);

$params[ 'line_color' ] = array(
    'type' => 'color',
    'title' => 'Line color',
    'selectors' => [
        '{{WRAPPER}} .line' => 'border-color: {{VALUE}};',
    ]
);

/* SUB-TITLE
------------------------------------------------ */
$params[ 'subtitle' ] = array(
    'type' => 'textarea',
    'title' => 'Subtitle',
    
    'section' => 'subtitle',
    'section_title' => 'Subtitle',
);

$params[ 'subtitle_title_spacing' ] = array(
    'type' => 'size',
    'title' => 'Subtitle - Title spacing',
    
    'std_unit' => 'px',
    'std_size' => 8,
    'px_max' => 30,
    'px_min' => 0,
    
    'selectors' => [
        '{{WRAPPER}} .heading-section+.heading-section' => 'margin-top:{{SIZE}}{{UNIT}};'
    ],
);

$params[ 'subtitle_tag' ] = array(
    'options' => [
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
        'h5' => 'H5',
        'p' => 'p',
    ],
    'std' => 'h3',
    'type' => 'select',
    'title' => 'Subtitle tag',
);

$params[ 'subtitle_color' ] = array(
    'type' => 'color',
    'title' => 'Custom subtitle color',
    
    'selectors' => [
        '{{WRAPPER}} .heading-subtitle-main' => 'color: {{VALUE}};'
    ],
);

$params[ 'subtitle_typography' ] = array(
    'type' => 'typography',
    'title' => 'Subtitle Typography',
    
    'selector' => '{{WRAPPER}} .heading-subtitle-main',
);

/* ADDITIONAL
------------------------------------------------ */
$params[ 'align' ] = array(
    'title' => 'Align',
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'center',
    
    'section' => 'additional',
    'section_title' => 'Additional',
);

$params[ 'image' ] = array(
    'type' => 'media',
    'title' => 'Heading image',
);

$params[ 'image_width' ] = array(
    'type' => 'size',
    
    'std_unit' => 'px',
    'std_size' => 50,
    'px_max' => 1000,
    'px_min' => 10,
    
    'title' => 'Image Width',
    'selectors' => [
        '{{WRAPPER}} .heading-image-main' => 'width:{{SIZE}}{{UNIT}};'
    ],
);

$params[ 'url' ] = array(
    'type' => 'text',
    'title' => 'URL',
);

$params[ 'url_target' ] = array(
    'type' => 'select',
    'title' => 'Open link in',
    'options' => [
        '_self' => 'Current tab',
        '_blank' => 'New tab',
    ],
    'std' => '_self',
);

$params[ 'url_text' ] = array(
    'type' => 'text',
    'title' => 'Link text',
);

$params[ 'url_position' ] = array(
    'type' => 'select',
    'options' => [
        'next'  => 'Next to title',
        'right' => 'Right side',
    ],
    'std' => 'right',
    'title' => 'Link position',
);

$params[ 'url_typography' ] = array(
    'type' => 'typography',
    'title' => 'Link typography',
    'selector' => '{{WRAPPER}} .heading-title a',
);

$params[ 'url_color' ] = array(
    'type' => 'color',
    'title' => 'Link color',
    'selectors' => [
        '{{WRAPPER}} .heading-title a' => 'color: {{VALUE}};',
    ]
);

$params[ 'extra_class' ] = array(
    'title' => 'Extra Class',
    'type' => 'text',
    'desc' => 'Enter your custom CSS class',
);
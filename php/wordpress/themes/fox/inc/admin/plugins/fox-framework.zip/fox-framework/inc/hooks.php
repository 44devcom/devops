<?php
/**
 * this adds extra functionality to Elementor section
 */
add_action( 'elementor/element/section/section_layout/after_section_end', 'fox_elementor_section_controls', 10, 2 );
add_action( 'elementor/element/after_add_attributes', 'fox_elementor_section_attrs', 99 );

function fox_elementor_section_controls( $element, $ags ) {
    
    $element->start_controls_section( 'fox_controls_section', array(
        'label' => 'FOX Options',
        'type' => \Elementor\Controls_Manager::SECTION,
        'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
    ) );
    
    $element->add_control( 'fox_sticky_header', array(
        'label'	=> 'Sticky Header?',
        'description' => 'Enable this if this section is used for header and you want to set this section to stick at top when visitors scroll. Note that while this option is well designed for header sections, DO NOT enable it for an arbitrary section or your site layout will be broken.',
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'prefix_class' => '',
        'default' => '',
        'label_on' => 'on',
        'label_off' => 'off',
    ) );
    
    /*
    $element->add_control( 'fox_sticky_sidebar', array(
        'label'	=> 'Sticky Sidebar?',
        'description' => 'Enable sticky sidebar effect for columns of this section.',
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'prefix_class' => '',
        'default' => '',
        'label_on' => 'on',
        'label_off' => 'off',
    ) );
    */
    
    $element->end_controls_section();
    
}

function fox_elementor_section_attrs( $element ) {
    
    if ( 'section' != $element->get_name() ) {
        return;
    }
    
    $settings = $element->get_settings_for_display();
    if ( 'yes' == $settings[ 'fox_sticky_header' ] ) {
        
        $element->add_render_attribute( '_wrapper', 'class', 'fox-sticky-section' );
        
    }
    
    /*
    if ( 'yes' == $settings[ 'fox_sticky_sidebar' ] ) {
        
        $element->add_render_attribute( '_wrapper', 'class', 'sticky-sidebar-effect' );
        
    }
    */ 
}

/* ------------------------------------------------------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------------------------------------------------------ */
add_action( 'elementor/element/text-editor/section_style/after_section_end', 'fox_elementor_text_editor_link_options', 10, 2 );
function fox_elementor_text_editor_link_options( $element, $ags ) {
    
    $element->start_controls_section( 'fox_controls_section', array(
        'label' => 'Link Options',
        'type' => \Elementor\Controls_Manager::SECTION,
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
    ) );
    
    $element->add_control( 'link_color', array(
        'label'	=> 'Link color',
        'type' => \Elementor\Controls_Manager::COLOR,
        'prefix_class' => '',
        'default' => '',
        'selectors' => [
            '{{WRAPPER}} a' => 'color:{{VALUE}};'
        ],
    ) );
    
    $element->add_control( 'link_hover_color', array(
        'label'	=> 'Link hover color',
        'type' => \Elementor\Controls_Manager::COLOR,
        'prefix_class' => '',
        'default' => '',
        'selectors' => [
            '{{WRAPPER}} a:hover' => 'color:{{VALUE}};'
        ],
    ) );
    
    $element->end_controls_section();
    
}
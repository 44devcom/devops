<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    'title' => 'Enter title here',
    'title_tag' => '',
    'title_size' => '',
    'title_text_transform' => '',

    'subtitle' => '',
    'subtitle_tag' => '',
    
    'url' => '',
    'url_target' => '',
    'url_text' => '',
    'url_position' => 'right',

    'image' => '',
    'line' => false,

    'extra_class' => '',
]) );

$title = trim( $title );
if ( $title == '' ) return;

$class = [ 'fox-heading' ];
if ( $extra_class ) {
    $class[] = $extra_class;
}

$title_attrs = $subtitle_attrs = [];
$title_class = [ 'heading-title-main' ];
$subtitle_class = [ 'heading-subtitle-main' ];

/* TITLE
-------------------- */

// size
if ( ! in_array( $title_size, [ 'large', 'medium', 'normal', 'small', 'tiny', 'supertiny' ] ) ) $title_size = 'large';
$title_class[] = 'size-' . $title_size;

// transform
if ( $title_text_transform ) {
    $title_class[] = 'text-' . $title_text_transform;
}

// attrs
$title_attrs[] = 'class="' . esc_attr( join( ' ', $title_class ) ) . '"';
$title_attrs = join( ' ', $title_attrs );

// title
if ( ! in_array( $title_tag, [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'div' ] ) ) $title_tag = 'h2';
$line_html = '';
if ( $line ) {
    $class[] = 'heading-line-' . $line;
    $line_html = '<span class="line line-left"></span><span class="line line-right"></span>';
}
$title_html = "<{$title_tag} {$title_attrs}>{$title}{$line_html}</{$title_tag}>";

/* LINK
-------------------- */
$link_html = '';
if ( $url && $url_text ) {
    
    if ( '_blank' != $url_target ) $url_target = '_self';
    $link_html = '<a href="' . esc_url( $url ) . '" target="' . esc_attr( $url_target ) . '">' . esc_html( $url_text ) . '</a>';
    $class[] = 'has-link';

    if ( 'next' != $url_position ) $url_position = 'right';
    $class[] = 'link-position-' . $url_position;

}

/* SUBTITLE
-------------------- */
$subtitle_attrs[] = 'class="' . esc_attr( join( ' ', $subtitle_class ) ) . '"';
$subtitle_attrs = join( ' ', $subtitle_attrs );

// subtitle
$subtitle_html = '';
$subtitle = trim( $subtitle );

if ( $subtitle ) {

    if ( ! in_array( $subtitle_tag, [ 'h1', 'h2', 'h3', 'h4', 'p' ] ) ) $subtitle_tag = 'h3';
    $subtitle_html = "<{$subtitle_tag} {$subtitle_attrs}>{$subtitle}</{$subtitle_tag}>";

}

/* IMAGE
-------------------- */
$img_html = '';
if ( $image && isset( $image[ 'id' ] ) ) {
    $img_html = wp_get_attachment_image( $image[ 'id' ], 'full' );
    if ( $img_html ) {
        $img_html = '<div class="heading-image-main">' . $img_html . '</div>';
    }
}

?>

<div class="<?php echo esc_attr( join( ' ', $class ) ); ?>">

<?php if ( $img_html ) { ?>
<div class="heading-section heading-image">

    <?php echo $img_html; ?>

</div>
<?php } ?>

<div class="heading-section heading-title">

    <?php echo $title_html; ?>
    <?php echo $link_html; ?>

</div><!-- .heading-title -->

<?php if ( $subtitle_html ) { ?>
<div class="heading-section heading-subtitle">

    <?php echo $subtitle_html; ?>

</div><!-- .heading-subtitle -->
<?php } ?>

</div><!-- .fox-heading -->
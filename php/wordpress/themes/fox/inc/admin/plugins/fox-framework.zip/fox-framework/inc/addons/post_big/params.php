<?php
$params = foxfw3_query_params();
$params += foxfw3_generate_options([
    'base' => 'standard',
    'context' => 'elementor',

    'exclude' => [
        'header_align', 
        'thumbnail_type',
        'show_thumbnail',
        'show_share',
        'show_related'
    ],

    'override' => [
        'show_author' => [
            'std' => '',
        ],
    ],

    'append' => [
        
        'thumbnail' => [
            'type' => 'select',
            'title' => 'Thumbnail',
            'std' => 'original',
            'after' => 'thumbnail_shape',
            'options' => [
                'original' => 'Original Size',
                'large' => 'Large',
                'custom' => 'Custom',
            ],
        ],

        'thumbnail_custom' => [
            'type' => 'text',
            'title' => 'Custom Size (Eg. 425x360)',
        ],

        'title_size' => [
            'type'  => 'select',
            'title' => 'Title size',
            'options' => [
                'extra' => 'Extra',
                'large' => 'Large',
                'medium' => 'Medium',
            ],
            'std' => 'extra',
            'after' => 'show_title',
        ],
        
        'show_excerpt' => [
            'type' => 'switcher',
            'title' => 'Show content/excerpt',
            'std' => 'yes',
        ],
        
        'excerpt_length' => [
            'title' => 'Excerpt length',
            'type' => 'text',
            'std'   => '-1',
        ],

        'meta_background' => [
            'type'  => 'color',
            'title' => 'Meta Background',
            'after' => 'text_color',
        ],

        'item_align' => [
            'type'  => 'select',
            'title' => 'Item Align',
            'options' => [
                '' => 'Default',
                'left' => 'Left',
                'center' => 'Center',
                'right' => 'Right',
            ],
            'std' => '',
        ],

    ],

    'section' => 'layout',
    'section_title' => 'Layout',
]);
<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Single_Comments extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_single_comments';
	}
    
    public function _base() {
        return 'single_comments';
    }

	public function get_title() {
		return 'FOX - Single Comments';
	}
    
    public function get_keywords() {
		return [ 'post comments', 'comments', 'comment form' ];
	}

	public function get_icon() {
        return 'eicon-comments';
	}
    
    public function get_categories() {
        return [ 'fox_single' ];
	}
    
}
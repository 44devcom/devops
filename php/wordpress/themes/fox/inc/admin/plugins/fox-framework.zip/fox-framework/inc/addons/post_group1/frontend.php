<?php
$settings = $this->get_settings_for_display();
$settings[ 'layout' ] = 'group-1';

extract( wp_parse_args( $settings, [
    'bigpost_position' => 'left',
    'bigpost_ratio' => '2/3',
    'sep_border' => '',
    'group1_small_display' => 'list',
    'group1_spacing_type' => 'predefined',
    'group1_spacing' => '',
    'group1_big_number' => 1,
    'group1_small_column' => 1,
    
    // alignment problem
    'bigpost_item_align' => 'center',
    'small_posts_item_align' => 'left',
    
    // youtube
    'bigpost_thumbnail_youtube_player' => 'no',
    'small_posts_thumbnail_youtube_player' => 'no',
] ) );

// no posts found
// don't waste my time
$query = foxfw3_query( $settings );
if ( ! $query ) {
    return;
}

if ( isset( $settings[ 'source' ] ) && 'archive' == $settings[ 'source' ] ) {
    $pagination = 'yes';
}

if ( ! $query->have_posts() ) {
    wp_reset_query();
    return;
}

$container_class = [
    'blog-container',
    'blog-container-group',
    'blog-container-group-1'
];

$class = [
    'wi-blog',
    'fox-blog',
    'blog-group',
    'blog-group-1',
    'post-group-row',

    // legacy
    'wi-newsblock',
    'newsblock-1',
];

/* columns order
------------------------------ */
if ( 'right' != $bigpost_position ) {
    $bigpost_position = 'left';
}
$class[] = 'big-post-' . $bigpost_position;

/* big post ratio
------------------------------ */
if ( ! in_array( $bigpost_ratio, [ '3/4', '1/2' ] ) ) {
    $bigpost_ratio = '2/3';
}
$class[] = 'big-post-ratio-' . str_replace( '/', '-', $bigpost_ratio );

/* spacing
------------------------------ */
if ( 'custom' == $group1_spacing_type ) {
    $class[] = 'post-group-spacing-custom';
} else {
    $class[] = 'post-group-spacing-' . $group1_spacing;
}

/* sep border
------------------------------ */
if ( 'yes' == $sep_border ) {
    $class[] = 'has-border';
}

/* number of big posts
------------------------------ */
$big_number = absint( $group1_big_number );
if ( ! $big_number ) {
    $big_number = 1;
}

// collecting HTML
$big = $small = [
    'settings' => [],
    'items' => [],
    'class' => [],
];
$big[ 'class' ] = [ 'post-group-col', 'post-group-col-big', 'article-big-wrapper', 'align-' . $bigpost_item_align ];

/**
 * youtube
 */
if ( 'yes' == $bigpost_thumbnail_youtube_player ) {
    $big[ 'class' ][] = 'behavior-thumbnail-youtube-player';
}

$small[ 'class' ] = [ 'post-group-col' , 'post-group-col-small', 'article-small-wrapper', 'align-' . $small_posts_item_align ];
/**
 * youtube
 */
if ( 'yes' == $small_posts_thumbnail_youtube_player ) {
    $small[ 'class' ][] = 'behavior-thumbnail-youtube-player';
}

/**
 * collect to build settings for each post group
 */
foreach ( $settings as $k => $v ) {
    if ( substr( $k, 0, 8 ) == 'bigpost_' ) {
        $big[ 'settings' ][ substr( $k, 8 ) ] = $v;
    } elseif ( substr( $k, 0, 12 ) == 'small_posts_' ) {
        $small[ 'settings' ][ substr( $k, 12 ) ] = $v;
    }
}

$backup_settings = $settings;
$count = 0;

while ( $query->have_posts() ) {
    
    $query->the_post(); 
    $count++;
    
    ob_start();
    
    // we'll use big settings and collect post for big
    if ( $count <= $big_number ) {
        
        $local_settings = $big[ 'settings' ];
        
        $col = 'big';
        $template = FOX_FRAMEWORK_PATH . 'content/post-grid.php';
        
        /* additional settings */
        $local_settings[ 'post_extra_class' ] = 'article-big';
        $local_settings[ 'layout' ] = 'grid';
        $local_settings[ 'column' ] = 1;
        
    } else {
        
        $local_settings = $small[ 'settings' ];
        $col = 'small';
        
        if ( isset( $backup_settings[ 'small_posts_disable_thumbnail_after_first' ] ) && $backup_settings[ 'small_posts_disable_thumbnail_after_first' ] == 'yes' && $count - $big_number >= 2 ) {
            $local_settings[ 'show_thumbnail' ] = false;
        }
        
        /* additional settings */
        $local_settings[ 'live' ] = false;
        $local_settings[ 'list_mobile_layout' ] = 'list';
        
        if ( 'list' == $group1_small_display ) {
            $template = FOX_FRAMEWORK_PATH . 'content/post-list.php';
            $local_settings[ 'layout' ] = 'list';
            $local_settings[ 'post_extra_class' ] = 'article-small article-small-list';
        } else {
            $template = FOX_FRAMEWORK_PATH . 'content/post-grid.php';
            $local_settings[ 'layout' ] = 'grid';
            $local_settings[ 'column' ] = $group1_small_column;
            $local_settings[ 'post_extra_class' ] = 'article-small article-small-grid';
        }
        
    }
    
    $settings = $local_settings;
    $settings[ 'count' ] = $count;
    include $template;
    
    do_action( 'fox_after_render_post' );
    
    ${$col}[ 'items' ][] = ob_get_clean();
    
} // endwhile

wp_reset_query();
?>

<div class="<?php echo esc_attr( join( ' ', $container_class ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $class ) ); ?>">
        
        <div class="<?php echo esc_attr( join( ' ', $big[ 'class' ] ) ); ?>">
            
            <?php if ( isset( $backup_settings[ 'bigpost_code_before' ] ) ) { echo $backup_settings[ 'bigpost_code_before' ]; } ; ?>
            
            <?php echo join( "\n", $big[ 'items' ] ); ?>
            
            <?php if ( isset( $backup_settings[ 'bigpost_code_after' ] ) ) { echo $backup_settings[ 'bigpost_code_after' ]; } ; ?>
            
        </div><!-- .post-group-col -->
        
        <div class="<?php echo esc_attr( join( ' ', $small[ 'class' ] ) ); ?>">
            
            <?php if ( isset( $backup_settings[ 'small_posts_code_before' ] ) ) { echo $backup_settings[ 'small_posts_code_before' ]; } ; ?>
            
            <?php if ( 'grid' == $group1_small_display ) { ?>
            <div class="blog-grid spacing-small fox-grid column-<?php echo esc_attr( $group1_small_column ); ?>">
                <?php echo join( "\n", $small[ 'items' ] ); ?>
            </div>
            <?php } else { ?>
            
            <?php echo join( "\n", $small[ 'items' ] ); ?>
            
            <?php } ?>
            
            <?php if ( isset( $backup_settings[ 'small_posts_code_after' ] ) ) { echo $backup_settings[ 'small_posts_code_after' ]; } ; ?>
            
        </div><!-- .post-group-col -->
        
        <?php if ( 'yes' == $sep_border ) { ?>
        
        <div class="sep-border"></div>
        
        <?php } ?>

    </div><!-- .wi-newsblock -->
    
</div><!-- .blog-container-group -->
<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    
    'source' => 'query',

    // query options
    'number' => '',
    'orderby' => '',
    'order' => '',
    'include' => '',
    'exclude' => '',
    'has_published_posts' => 'yes',

    // layout
    'layout' => '',
    'valign' => '',
    'column' => '',
    'border' => 'yes',
    
    // avatar
    'show_author_avatar' => 'yes',
    'author_avatar_shape' => 'circle',
    
    // name
    'show_author_name' => 'yes',
    
    // desc
    'show_author_description' => 'yes',
    
    // social
    'show_author_social' => 'yes',
    'author_social_style' => '',

    'show_author_posts' => 'no',
    'author_posts_number' => 3,
    'author_posts_source' => 'latest',
    
    // 'show_post_count' => false,
    // 'recent_posts' => 0, @todo

] ) );

$result = [];
if ( 'author_page' == $source ) {
    
    if ( ! fox_is_edit() ) {
        if ( ! is_author() ) {
            return;
        }
        $user = get_queried_object();
        if ( $user && ! is_wp_error( $user ) ) {
            $result = [ $user ];   
        }
    }
    
} elseif ( 'post_author' == $source ) {
    
    if ( ! fox_is_edit() ) {
        $author_id = get_post_field( 'post_author', get_the_ID() );
        $user = get_user_by( 'ID', $author_id );
        if ( $user && ! is_wp_error( $user ) ) {
            $result = [ $user ];
        }
    }
    
} else {

    /* Query
    -------------------- */
    $args = array(
        'number' => $number,
        'orderby' => $orderby,
        'order' => $order,
    );
    if ('yes' == $has_published_posts) {
        $args[ 'capability' ] = 'edit_posts';
        $args[ 'has_published_posts' ] = 'post';
    }

    $include = trim( $include );
    if ( ! empty( $include ) ) {
        $include = explode( ',', $include );
        $include = array_map( 'absint', $include );
        $args = [ 'include' => $include ];
        $args[ 'orderby' ] = 'include';
    }
    $exclude = trim( $exclude );
    if ( ! empty( $exclude ) ) {
        $exclude = explode( ',', $exclude );
        $exclude = array_map( 'absint', $exclude );
        $args[ 'exclude' ] = $exclude;
    }

    // The Query
    $user_query = new WP_User_Query( $args );
    $result = $user_query->get_results();
    
}

if ( fox_is_edit() && in_array( $source, [ 'author_page', 'post_author' ] ) ) {
    
    // get avatar of current author
    $author_id = get_post_field( 'post_author', get_the_ID() );
    $user = get_user_by( 'ID', $author_id );
    if ( $user && ! is_wp_error( $user ) ) {
        $result = [ $user ];
    } else {
        $result = [];
    }
    
}

if ( empty( $result ) ) {
    echo '<div class="fox-error">' . esc_html__( 'No users found', 'wi' ) . '</div>';
    return;
}

/* layout
-------------------- */
$cl = [
    'fox-authors',
    'fox-users',
];

if ( 'list' != $layout ) $layout = 'grid';
$cl[] = 'fox-authors-' . $layout;

if ( 'grid' == $layout ) {
    // column
    if ( $column < 1 || $column > 5 ) $column = 3;
    $cl[] = 'column-' . $column;
}

if ( 'list' == $layout ) {
    if ( $valign != 'bottom' && $valign != 'middle' ) {
        $valign = 'top';
    }
    $cl[] = 'valign-' . $valign;
}

if ( 'yes' == $border ) {
    $cl[] = 'has-border';
}

/* final
-------------------- */
$cl = join( ' ', $cl );
    
?>

<div class="fox-authors-wrapper">
    
    <div class="<?php echo esc_attr( $cl ); ?>">

        <?php foreach ( $result as $user ) :
        
        /**
         * user posts
         * since v.5.4
         */
        $after_body = '';
        $after_desc = '';
        if ( 'yes' == $show_author_posts ) {
            $post_query_args = [
                'posts_per_page' => absint( $author_posts_number ),
                'no_found_rows' => true,
            ];
            if ( 'view' == $author_posts_source ) {
                
                $post_query_args[ 'orderby' ] = 'post_views';
                $post_query_args[ 'order' ] = 'DESC';
                
            } elseif ( 'featured' == $author_posts_source ) {
                
                $post_query_args[ 'orderby' ] = 'date';
                $post_query_args[ 'order' ] = 'DESC';
                $post_query_args[ 'featured' ] = true;
                
            } else {
                
                $post_query_args[ 'orderby' ] = 'date';
                $post_query_args[ 'order' ] = 'DESC';
                
            }
            
            $post_query_args[ 'author' ] = $user->ID;
            
            $q = new WP_Query( $post_query_args  );
            if ( ! $q->have_posts() ) {
                wp_reset_query();
            } else {
                ob_start();
                echo '<div class="user-item-posts"><ol>';
                
                while ( $q->have_posts() ) {
                    $q->the_post();
                    
                    echo '<li>';
                    echo '<a href="' . get_permalink() . '">';
                    the_title();
                    echo '</a></li>';
                }

                echo '</ol></div><!-- .user-item-posts -->';
                
                if ( 'list' == $layout ) {
                    $after_desc = ob_get_clean();
                    $after_body = '';
                } else {
                    $after_desc = '';
                    $after_body = ob_get_clean();
                }
                
                wp_reset_query();
                
            }
            
        }
        
            foxfw3_user([
                'user' => $user,

                'avatar' => ('yes' == $show_author_avatar ),
                'avatar_shape' => $author_avatar_shape,

                'name' => ( 'yes' == $show_author_name ),
                'description' => ( 'yes' == $show_author_description ),

                'social' => ( 'yes' == $show_author_social ),
                'social_style' => $author_social_style,
                
                'after_body' => $after_body,
                'after_desc' => $after_desc,
                 
                'author_page' => ( 'author_page' == $source ),
                
            ]);

        endforeach; // each user ?>
        
        <?php if ( 'yes' == $border && 'grid' == $layout ) { for ( $i = 1; $i < $column; $i++ ) { ?>
        
        <div class="line line-<?php echo $i; ?>"></div>
        
        <?php } } ?>

    </div><!-- .fox-authors -->
    
</div><!-- .fox-authors-wrapper -->
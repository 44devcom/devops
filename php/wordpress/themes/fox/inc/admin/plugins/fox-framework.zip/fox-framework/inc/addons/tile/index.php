<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Tile extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_tile';
	}
    
    public function _base() {
        return 'tile';
    }

	public function get_title() {
		return 'FOX Tile';
	}
    
    public function get_keywords() {
		return [ 'tile', 'imagebox', 'square', 'block', 'image' ];
	}

	public function get_icon() {
        return 'eicon-square';
	}
    
}
<?php
/* OLD BLOG FUNCTION, USED TO DISPLAY:
post big
------------------------------------------------------------------------ */
function foxfw3_blog( $fn_params, $query ) {
    
    $fn_params = wp_parse_args( $fn_params, [
        'pagination' => '',
        
        'layout' => '',
        'column' => '',
        'first_standard' => '',
        'item_card' => '',
        'item_card_background' => '',
        'item_border' => '',
        'item_border_color' => '',
        'item_spacing' => '',
        'color' => '',
        'big_first_post' => true, // for masonry
        'align' => '',
        'item_template' => '',
        'live' => true,
        'components' => '',
        'thumbnail_components' => '',
        
        // component params
        'thumbnail_show' => '',
        'title_show' => '',
        'date_show' => '',
        'category_show' => '',
        'author_show' => '',
        'author_avatar_show' => '',
        'excerpt_show' => '',
        'excerpt_more_show' => '',
        'view_show' => '',
        'reading_time_show' => '',
        'comment_link_show' => '',
        'share_show' => '',
        
        // thumbnail options
        'thumbnail' => 'landscape',
        'thumbnail_custom' => '',
        'thumbnail_placeholder' => true,
        'thumbnail_placeholder_id' => '',
        'thumbnail_shape' => '',
        'thumbnail_hover' => '',
        'thumbnail_hover_logo' => '',
        'thumbnail_hover_logo_width' => '',
        'thumbnail_showing_effect' => '',
        
        'thumbnail_format_indicator' => '',
        'thumbnail_index' => '',
        'thumbnail_view' => '',
        'thumbnail_review_score' => '',
        
        'thumbnail_extra_class' => '',
        
        // since 4.6.7
        'thumbnail_caption' => '', // show caption or not in case the thumbnail has caption
        'thumbnail_order' => '', // if 'after' then display the thumbnail after post content
        
        // title options
        'title_tag' => '',
        'title_color' => '',
        'title_size' => '',
        'title_weight' => '',
        
        // excerpt options
        'excerpt_length' => 22,
        'excerpt_size' => '',
        'excerpt_color' => '',
        'excerpt_hellip' => '',
        'excerpt_more' => '',
        'excerpt_more_style' => '',
        'excerpt_more_text' => '',
        
        /**
         * LIST
         */
        'list_spacing' => '',
        'list_sep' => true,
        'list_sep_style' => 'solid',
        'list_sep_color' => '',
        'thumbnail_position' => 'left',
        'thumbnail_width' => '',
        'list_mobile_layout' => 'grid',
        'list_valign' => 'top',
        
        'list_index' => '', // since 4.6.2
        
        /**
         * MASONRY
         */
        'masonry_dropcap' => '',
        'masonry_item_creative' => '',
        
        /**
         * STANDARD
         */
        'thumbnail_type' => 'simple', // simple or rich
        'share_show' => '',
        'related_show' => '',
        
        'standard_sep' => true, // since 4.6.2.3
        'standard_thumbnail_type' => '',
        'standard_thumbnail_header_order' => '',
        'standard_content_excerpt' => '',
        'standard_excerpt_length' => '',
        'standard_excerpt_more' => '',
        'standard_excerpt_more_style' => '',
        'standard_header_align' => '',
        'standard_column_layout' => '',
        'standard_dropcap' => '',
        
        /**
         * NEWSPAPER
         */
        'newspaper_header_align' => '',
        'newspaper_dropcap' => '',
        'newspaper_content_excerpt' => '',
        'newspaper_column_layout' => '',
        
        /**
         * VERTICAL
         */
        'vertical_thumbnail_type' => '',
        'vertical_thumbnail_position' => '',
        'vertical_excerpt_size' => '',
        
        /**
         * BIG
         */
        'big_content_excerpt' => '',
        'big_align' => '',
        'big_meta_background' => '',
        
        /**
         * SLIDER
         */
        'slider_effect' => 'slide',
        'slider_nav_style' => 'text',
        'slider_dot_style' => 'disabled',
        'slider_size' => '1020x510',
        'slider_title_background' => '',
        
        'slider_autoplay' => '',
        
        /**
         * SLIDER 1
         */
        'slider1_height' => '',
        'slider1_content_color' => '',
        'slider1_content_background' => '',
        'slider1_content_background_opacity' => '',
        
        /**
         * SLIDER 2
         */
        'slider2_text_background' => '',
        
        /**
         * SLIDER 3
         */
        'slider3_text_background' => '',
        
        /**
         * GROUP 1
         */
        'group1_big_position' => '',
        'group1_big_ratio' => '',
        'group1_spacing' => '',
        'group1_sep_border' => '',
        'group1_sep_border_color' => '',
        
        // since 4.7.2
        'group1_big_number' => '',
        'group1_small_display' => '',
        'group1_small_column' => '',
        
        'group1_big_components' => '',
        'group1_big_align' => '',
        'group1_big_item_template' => '',
        'group1_big_thumbnail' => '',
        'group1_big_excerpt_length' => '',
        'group1_big_excerpt_more_text' => '',
        'group1_big_excerpt_more_style' => '',
        
        'group1_small_components' => '',
        'group1_small_item_template' => '',
        'group1_small_list_spacing' => '',
        'group1_small_thumbnail' => '',
        'group1_small_excerpt_length' => '',
        
        /**
         * GROUP 2
         */
        'group2_spacing' => '', // 4.6.8
        'group2_columns_order' => '',
        'group2_sep_border' => '',
        'group2_sep_border_color' => '',
        
        // since 4.7.2
        'group2_big_number' => '',
        'group2_medium_number' => '',
        'group2_small_display' => '',
        
        'group2_big_components' => '',
        'group2_big_align' => '',
        'group2_big_item_template' => '',
        'group2_big_excerpt_length' => '',
        'group2_big_excerpt_more_text' => '',
        'group2_big_excerpt_more_style' => '',
        
        'group2_medium_components' => '',
        'group2_medium_item_template' => '',
        'group2_medium_thumbnail' => '',
        'group2_medium_excerpt_length' => '',
        
        'group2_small_components' => '',
        'group2_small_item_template' => '',
        'group2_small_excerpt_length' => '',
        'group2_small_title_size' => '',
        
        // extra
        'extra_class' => '',
        
    ]);
    
    // no posts found
    // don't waste my time
    if ( ! $query ) {
        return;
    }
    
    if ( ! $query->have_posts() ) {
        wp_reset_query();
        return;
    }
    
    // only validate the layout
    $layout = $fn_params[ 'layout' ];
    
    $layout_to_function = [
        
        'masonry' => 'foxfw3_blog_masonry',
        'newspaper' => 'foxfw3_blog_newspaper',
        'vertical' => 'foxfw3_blog_vertical',
        'big' => 'foxfw3_blog_big',
        'slider' => 'foxfw3_blog_slider',
        
    ];
    
    if ( ! isset( $layout_to_function[ $layout ] ) ) {
        $layout = 'list';
    }
    $fn_params[ 'layout' ] = $layout;
    
    /*
        @since 4.5
        10 - fox_justify_params
     */
    $fn_params = apply_filters( 'foxfw3_final_params', $fn_params, $query );
    if ( function_exists( $layout_to_function[ $layout ] ) ) {
        call_user_func( $layout_to_function[ $layout ], $fn_params, $query );
    }
    wp_reset_query();
    
}

add_filter( 'foxfw3_final_params', 'foxfw3_justify_params', 10, 1 );
/**
 * adjust minor problems on fn_params
 * @since 4.5
 */
function foxfw3_justify_params( $fn_params ) {
    
    // only apply for list layout
    if ( 'list' != $fn_params[ 'layout' ] ) {
        $fn_params[ 'thumbnail_width' ] = '';
    }
    
    if ( ! in_array( $fn_params[ 'layout' ], [ 'standard', 'newspaper', 'vertical' ] ) ) {
        $fn_params[ 'thumbnail_type' ] = 'simple';
    }
    
    if ( 'false' == get_theme_mod( 'wi_live_grid_list', 'false' ) ) {
        if ( in_array( $fn_params[ 'layout' ], [ 'list', 'grid' ] ) ) {
            $fn_params[ 'live' ] = false;
        }
    } else {
        $fn_params[ 'live' ] = true;
    }
    
    /**
     * 01 - components
     */
    $components_to_show = foxfw3_component_to_show( $fn_params[ 'components' ] );
    $fn_params = array_merge( $fn_params, $components_to_show );

    /**
     * 02 - thumbnail components
     */
    $components = isset( $fn_params[ 'thumbnail_components' ] ) ? $fn_params[ 'thumbnail_components' ] : 'format_indicator';
    if ( ! is_array( $components ) ) {
        $components = explode( ',', $components );
        $components = array_map( 'trim', $components );
    }
    $fn_params[ 'thumbnail_format_indicator' ] = in_array( 'format_indicator', $components );
    $fn_params[ 'thumbnail_index' ] = in_array( 'index', $components );
    $fn_params[ 'thumbnail_view' ] = in_array( 'view', $components );
    $fn_params[ 'thumbnail_review_score' ] = in_array( 'review', $components );

    /**
     * 03 - true/false
     */
    foreach ( $fn_params as $k => $v ) {
        if ( 'true' == $v ) {
            $fn_params[ $k ] = true;
        } elseif ( 'false' == $v ) {
            $fn_params[ $k ] = false;
        }
    }
    
    return $fn_params;
    
}

/**
 * a helper function
 * ------------------------------------------------------------------------------------------------
 */
function foxfw3_component_to_show( $components ) {
    
    $show_params = [];
    
    if ( ! is_array( $components ) ) {
        $coms = explode( ',', $components );
        $coms = array_map( 'trim', $coms );
    } else {
        $coms = $components;
    }
    
    $possible_components = [
        'thumbnail',
        'title',
        'date',
        'category',
        'author',
        'author_avatar',
        'excerpt', 
        'excerpt_more', 
        'reading_time',
        'comment_link',
        'view',
        'share',
        'related',
    ];
    foreach ( $possible_components as $com ) {
        $show_params[ $com . '_show' ] = in_array( $com, $coms );
    }
    $show_params[ 'excerpt_more' ] = in_array( 'excerpt_more', $coms );
    
    return $show_params;
    
}

/**
 * Blog Big
 * @since 4.5
 * ------------------------------------------------------------------------------------------------
 */
function foxfw3_blog_big( $fn_params, $query ) {
    
    $container_class = [ 'blog-container', 'blog-container-big' ];
    $class = [ 'wi-blog', 'fox-blog', 'blog-big' ];
    
    if ( $fn_params[ 'extra_class' ] ) {
        $class[] = $fn_params[ 'extra_class' ];
    }

    /**
     * color
     */
    $css_str = '';
    $id_attr = '';
    $color = trim( $fn_params[ 'color' ] );
    if ( $color ) {
        $class[] = 'blog-custom-color';
        $unique_id = uniqid( 'blog-' );
        $id_attr = ' id="' . esc_attr( $unique_id ) . '"';
        $css_str = '<style type="text/css">#' . $unique_id . '{color:' . esc_html( $color ). ';}</style>';
    }
    
    ?>

    <?php echo $css_str; ?>

<div class="<?php echo esc_attr( join( ' ', $container_class ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $class ) ); ?>"<?php echo $id_attr; ?>>
    
    <?php
    $count = 0;
    while( $query->have_posts() )  {
    
        $query->the_post();
        $count++;
        
        $params = $fn_params;
        $params[ 'count' ] = $count;
        
        include FOX_FRAMEWORK_PATH . 'content/post-big.php';
        
        do_action( 'fox_after_render_post' );
        
    } ?>
    
    </div><!-- .fox-blog -->
    
    <?php if ( $fn_params[ 'pagination' ] ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->

    <?php
    
}

/**
 * Blog Slider
 *
 * @since 4.4
 * ------------------------------------------------------------------------------------------------
 */
function foxfw3_blog_slider( $fn_params, $query ) {
    
    $class = [
        'wi-flexslider',
        'fox-flexslider',
        'blog-slider',
    ];
    
    /**
     * nav class
     */
    $nav_style = $fn_params[ 'slider_nav_style' ];
    if ( ! in_array( $nav_style, [
        'circle-1',
        'square-1',
        'square-2',
        'square-3',
        'text',
    ] ) ) {
        $nav_style = 'circle-1';
    }
    $class[] = 'style--slider-nav-' . $nav_style;
    
    $slider_options = [
        'slideshow' => $fn_params[ 'slider_autoplay' ],
        'animationSpeed' => 1000,
        'slideshowSpeed' =>	5000,
        'easing' => 'easeOutCubic',
    ];
    
    /**
     * arrow
     */
    if ( 'text' == $nav_style ) {
        $slider_options[ 'prevText' ] = '<i class="fa fa-chevron-left"></i>' . '<span>' . foxfw3_word( 'previous' ) . '</span>';
        $slider_options[ 'nextText' ] = '<span>' . foxfw3_word( 'next' ) . '</span>' . '<i class="fa fa-chevron-right"></i>';
    } else {
        $slider_options[ 'prevText' ] = '<i class="fa fa-angle-left"></i>';
        $slider_options[ 'nextText' ] = '<i class="fa fa-angle-right"></i>';
    }
    
    // effect
    if ( 'fade' != $fn_params[ 'slider_effect' ] ) $fn_params[ 'slider_effect' ] = 'slide';
    $slider_options[ 'animation' ] = $fn_params[ 'slider_effect' ];
    
    // nav style
    if ( 'arrow' != $fn_params[ 'slider_nav_style' ] ) $fn_params[ 'slider_nav_style' ] = 'text';
    $class[] = 'style--slider-nav' . $fn_params[ 'slider_nav_style' ];
    
    /**
     * color
     */
    $css_str = '';
    $id_attr = '';
    $color = trim( $fn_params[ 'color' ] );
    if ( $color ) {
        $class[] = 'blog-custom-color';
        $unique_id = uniqid( 'blog-' );
        $id_attr = ' id="' . esc_attr( $unique_id ) . '"';
        $css_str = '<style type="text/css">#' . $unique_id . '{color:' . esc_html( $color ). ';}</style>';
    }
    
    ?>

<?php echo $css_str; ?>

<div class="<?php echo esc_attr( join( ' ', $class ) ); ?>"<?php echo $id_attr; ?> data-options='<?php echo json_encode( $slider_options ); ?>'>
            
    <div class="flexslider">
        
        <ul class="slides">
            
            <?php 
            $count = 0;
            while( $query->have_posts()) {
                $query->the_post();
                $params = $fn_params;
                $count++;
                $params[ 'count' ] = $count;

                include FOX_FRAMEWORK_PATH . 'content/post-slider.php';

                do_action( 'fox_after_render_post' );

            } ?>
            
        </ul>
        
    </div><!-- .flexslider -->
    
    <?php echo '<span class="fox-loading-element"><i class="fa fa-spinner fa-spin"></i></span>'; ?>

</div><!-- .wi-flexslider -->
    
<?php
}

/**
 * Blog Masonry
 * @since 4.5
 * ------------------------------------------------------------------------------------------------
 */
function foxfw3_blog_masonry( $fn_params, $query ) {
    
    $container_class = [ 'blog-container', 'blog-container-masonry' ];
    
    $class = [ 'wi-blog', 'fox-blog', 'blog-masonry', 'fox-grid', 'fox-masonry' ];
    
    $grid_line_class = [ 'fox-grid', 'grid-lines' ];
    
    /**
     * extra class
     */
    if ( $fn_params[ 'extra_class' ] ) {
        $class[] = $fn_params[ 'extra_class' ];
    }
    
    /**
     * creative item
     */
    if ( $fn_params[ 'masonry_item_creative' ] ) {
        $class[] = 'blog-item-creative';
    }
    
    /**
     * card layout
     */
    if ( strpos( $fn_params[ 'item_card' ], 'no_shadow' ) === false ) {
        $class[] = 'blog-card-has-shadow';
    } else {
        $class[] = 'blog-card-no-shadow';
    }
    $fn_params[ 'item_card' ] = str_replace( '_no_shadow', '', $fn_params[ 'item_card' ] );
        
    if ( in_array( $fn_params[ 'item_card' ], [ 'normal', 'overlap' ] ) ) {
        $class[] = 'blog-card-' . $fn_params[ 'item_card' ];
    }
    
    /**
     * column
     */
    $class[] = 'column-' . $fn_params['column'];
    $grid_line_class[] = 'column-' . $fn_params['column'];
    
    /**
     * big first post
     */
    if ( $fn_params[ 'big_first_post' ] ) {
        $class[] = 'fox-masonry-featured-first';
    }
    
    /**
     * item spacing
     */
    $item_spacing = $fn_params[ 'item_spacing' ];
    if ( ! in_array( $item_spacing, [ 'none', 'tiny', 'small', 'normal', 'medium', 'wide', 'wider' ] ) ) {
        $item_spacing = 'normal';
    }
    $class[] = 'spacing-' . $item_spacing;
    
    /**
     * color
     */
    $css_str = '';
    $id_attr = '';
    $color = trim( $fn_params[ 'color' ] );
    if ( $color ) {
        $class[] = 'blog-custom-color';
        $unique_id = uniqid( 'blog-' );
        $id_attr = ' id="' . esc_attr( $unique_id ) . '"';
        $css_str = '<style type="text/css">#' . $unique_id . '{color:' . esc_html( $color ). ';}</style>';
    }
    
    /**
     * border
     */
    if ( 'true' == $fn_params[ 'item_border' ] ) {
        $container_class[] = 'blog-container-has-border';
    }
    
    /**
     * border css
     * @since 4.4.2
     */
    $border_css = '';
    if ( $fn_params[ 'item_border_color' ] ) {
        $border_css = ' style="color:' . esc_attr( $fn_params[ 'item_border_color' ] ) . '"';
    }
    ?>

<?php echo $css_str; ?>

<div class="<?php echo esc_attr( join( ' ', $container_class ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $class ) ); ?>"<?php echo $id_attr; ?>>
    
    <?php 
    $count = 0;
    while ( $query->have_posts() ) {
        
        $query->the_post();
        $count++;
        
        $params = $fn_params;
        $params[ 'count' ] = $count;
        
        include FOX_FRAMEWORK_PATH . 'content/post-masonry.php';

        do_action( 'fox_after_render_post' );
        
    } ?>
        
        <div class="grid-sizer fox-grid-item"></div>
        
        <?php if ( 'true' == $fn_params[ 'item_border' ] ) { ?>
        
        <div class="<?php echo esc_attr( join( ' ', $grid_line_class ) ); ?>"<?php echo $border_css; ?>>
            
            <?php for ( $i = 1; $i <= $fn_params['column']; $i++ ) { ?>
            
            <div class="grid-line fox-grid-item"><div class="grid-line-inner"></div></div>
            
            <?php } ?>
            
        </div><!-- .grid-lines -->
        
        <?php } ?>
    
    </div><!-- .fox-blog -->
    
    <?php if ( $fn_params[ 'pagination' ] ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->

    <?php
    
}

/**
 * Blog Newspaper
 * @since 4.5
 * ------------------------------------------------------------------------------------------------
 */
function foxfw3_blog_newspaper( $fn_params, $query ) {
    
    $container_class = [ 'blog-container', 'blog-container-newspaper' ];
    
    $class = [ 'wi-blog', 'fox-blog', 'blog-newspaper' ];
    
    $class[] = 'fox-masonry fox-grid column-2 spacing-normal';
    
    if ( $fn_params[ 'extra_class' ] ) {
        $class[] = $fn_params[ 'extra_class' ];
    }
    
    /**
     * color
     */
    $css_str = '';
    $id_attr = '';
    $color = trim( $fn_params[ 'color' ] );
    if ( $color ) {
        $class[] = 'blog-custom-color';
        $unique_id = uniqid( 'blog-' );
        $id_attr = ' id="' . esc_attr( $unique_id ) . '"';
        $css_str = '<style type="text/css">#' . $unique_id . '{color:' . esc_html( $color ). ';}</style>';
    }
    ?>

<?php echo $css_str; ?>

<div class="<?php echo esc_attr( join( ' ', $container_class ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $class ) ); ?>"<?php echo $id_attr; ?>>
    
    <?php 
    $count = 0;
    while ( $query->have_posts() ) {
        
        $query->the_post();
        $count++;
        
        $params = $fn_params;
        $params[ 'count' ] = $count;
        
        include FOX_FRAMEWORK_PATH . 'content/post-newspaper.php';
        
    } ?>
        
        <div class="grid-sizer fox-grid-item"></div>
    
    </div><!-- .fox-blog -->
    
    <?php if ( $fn_params[ 'pagination' ] ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->
    <?php
}

/**
 * Blog Vertical
 * @since 4.5
 * ------------------------------------------------------------------------------------------------
 */
function foxfw3_blog_vertical( $fn_params, $query ) {
    
    $container_class = [ 'blog-container', 'blog-container-vertical' ];
    
    $class = [ 'wi-blog', 'fox-blog', 'blog-vertical' ];
    
    if ( $fn_params[ 'extra_class' ] ) {
        $class[] = $fn_params[ 'extra_class' ];
    }
    
    /**
     * color
     */
    $css_str = '';
    $id_attr = '';
    $color = trim( $fn_params[ 'color' ] );
    if ( $color ) {
        $class[] = 'blog-custom-color';
        $unique_id = uniqid( 'blog-' );
        $id_attr = ' id="' . esc_attr( $unique_id ) . '"';
        $css_str = '<style type="text/css">#' . $unique_id . '{color:' . esc_html( $color ). ';}</style>';
    }
    
    ?>

<?php echo $css_str; ?>

<div class="<?php echo esc_attr( join( ' ', $container_class ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $class ) ); ?>"<?php echo $id_attr; ?>>
    
    <?php 
    $count = 0;
    while ( $query->have_posts() ) {
        
        $query->the_post();
        $count++;
        
        $params = $fn_params;
        $params[ 'count' ] = $count;
        
        include FOX_FRAMEWORK_PATH . 'content/post-vertical.php';
        
        do_action( 'fox_after_render_post' );
        
    } ?>
    
    </div><!-- .fox-blog -->
    
    <?php if ( $fn_params[ 'pagination' ] ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->

    <?php
    
}
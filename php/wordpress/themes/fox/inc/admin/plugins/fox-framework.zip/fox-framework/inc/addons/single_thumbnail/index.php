<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Single_Thumbnail extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_single_thumbnail';
	}
    
    public function _base() {
        return 'single_thumbnail';
    }

	public function get_title() {
		return 'FOX - Single Thumbnail';
	}
    
    public function get_keywords() {
		return [ 'post thumbnail', 'thumbnail', 'single post', 'featured image' ];
	}

	public function get_icon() {
        return 'eicon-image';
	}
    
    public function get_categories() {
        return [ 'fox_single' ];
	}
    
}
<?php
$params[ 'align' ] = array(
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'left',
    'title' => 'Alignment',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'disable_on_author_page' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Disable on author page',
);

$params[ 'title_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-archive-title .el-title-tag',
    'title' => 'Typography',
);

$params[ 'title_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-archive-title .el-title-tag' => 'color:{{VALUE}};',
    ],
    'title' => 'Color',
);
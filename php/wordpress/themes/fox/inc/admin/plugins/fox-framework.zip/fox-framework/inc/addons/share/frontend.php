<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'share_icons' => 'facebook, twitter, pinterest, linkedin, whatsapp, reddit, email',
]) );

$cl = [ 'el-share' ];

/**
 * share_icons
 */
$share_icons = explode( ',', $share_icons );
$share_icons = array_map( 'trim', $share_icons );
if ( ! is_array( $share_icons ) ) {
    $share_icons = [ 'facebook', 'twitter' ];
}
if ( empty( $share_icons ) ) {
    return;
}

/**
 * data
 */
$image = '';
if ( fox_is_edit() ) {
    $url = 'https://themeforest.net/user/withemes';
    $title = 'ThemeForest';
    $image = '';
    $via = 'withemes';
} else {
    
    $url = get_permalink();
    $title = trim( get_the_title() );
    $title = strip_tags( $title );
    
    if ( has_post_thumbnail() ) {
        $image = wp_get_attachment_thumb_url();
    }
    if ( is_engine_v6() ) {
        $via = trim( get_theme_mod( 'twitter_username', 'withemes' ) );
    } else {
        $via = trim( get_theme_mod( 'wi_twitter_username', 'withemes' ) );
    }
}

/**
 * final
 */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <?php foxfw3_share_icon_list([
        'share_icons' => $share_icons,
        'url' => $url,
        'title' => $title,
        'image' => $image,
        'via' => $via,
    ]); ?>
    
</div>
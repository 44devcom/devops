<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    'type' => 'text',
    'layout' => '1',
    'text_custom_enable' => 'no',
    'text_custom' => '',
    'image' => null,
    'custom_url' => []
]) );

$cl = [ 'el-logo' ];

/* logo type
--------------------------- */
if ( 'text' == $type ) {
    $cl[] = 'logo-text';
} else if ( 'image' == $type ) {
    $cl[] = 'logo-image';
} else {
    $type = 'mix';
    $cl[] = 'logo-mix';
}

/* logo mix layout
--------------------------- */
if ( ! in_array( $layout, [ '1', '2', '3', '4' ] ) ) {
    $layout = '1'; // text - image
}
if ( 'mix' == $type ) {
    $cl[] = 'logo-layout-' . $layout;
}

/* text
--------------------------- */
if ( 'yes' == $text_custom_enable ) {
    $text = trim( $text_custom );
} else {
    $text = get_bloginfo( 'name' );
}
if ( $text == '' ) {
    $text = 'My Site Name';
}

/* custom URL
--------------------------- */
if ( $custom_url && isset( $custom_url['url']) && $custom_url['url'] ) {
    $url = $custom_url['url'];
} else {
    $url = home_url( '/' );
}

/* final
--------------------------- */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <a href="<?php echo esc_url( $url ); ?>" rel="home">
    
        <?php if ( 'text' == $type || 'mix' == $type ) { ?>
        <span class="site-logo-text">
            <?php echo $text; ?>
        </span>
        <?php } ?>

        <?php if ( 'image' == $type || 'mix' == $type ) {
        if ( ! empty( $image[ 'id'] ) ) {
        ?>
        <div class="site-logo-image">
            <?php \Elementor\Group_Control_Image_Size::print_attachment_image_html( $settings, 'image', 'image' ); ?>
        </div>
        <?php } } ?>
        
    </a>
    
</div>
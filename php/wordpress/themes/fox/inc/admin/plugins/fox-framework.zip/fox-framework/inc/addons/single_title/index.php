<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Single_Title extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_single_title';
	}
    
    public function _base() {
        return 'single_title';
    }

	public function get_title() {
		return 'FOX - Single Title';
	}
    
    public function get_keywords() {
		return [ 'post title', 'title', 'single post' ];
	}

	public function get_icon() {
        return 'eicon-post-title';
	}
    
    public function get_categories() {
        return [ 'fox_single' ];
	}
    
}
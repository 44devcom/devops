<?php
$params[ 'components' ] = array(
    'type' => 'repeater',
    'title' => 'Components',
    
    'fields' => [
        
        'type' => [
            'title' => 'Type',
            'type' => 'select',
            'options' => [
                'date' => 'Date',
                'category' => 'Category',
                'author' => 'Author',
                'view' => 'View count',
                'comment' => 'Comment link',
                'reading' => 'Reading time',
                'live' => 'Live Indicator',
            ],
            'std' => 'date',
        ],
        
        'date_format' => [
            'type' => 'text',
            'condition' => [
                'type[value]' => 'date',
            ],
            'title' => 'Date format',
            'desc' => '<a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">Learn about date format here</a>. If you are not sure, leave it blank.',
        ],
        
        'author_avatar' => [
            'type' => 'switcher',
            'condition' => [
                'type[value]' => 'author',
            ],
            'std' => '',
            'title' => 'Author avatar',
        ],
        
    ],
    'std' => [
        [
            'type' => 'date',
        ],
        [
            'type' => 'author',
        ],
    ],
    'title_field' => 'type',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'meta_align' ] = array(
    'type' => 'align',
    'title' => 'Align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'left',
);

$params[ 'meta_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-meta',
    'title' => 'Typography',
);

$params[ 'meta_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-meta' => 'color:{{VALUE}};',
    ],
    'title' => 'Color',
);

$params[ 'avatar_size' ] = array(
    'type' => 'size',
    'title' => 'Avatar size',
    
    'std_size' => 32,
    'std_unit' => 'px',
    'px_min' => 10,
    'px_max' => 80,
    
    'selectors' => array(
        '{{WRAPPER}} .el-single-meta .meta-author-avatar' => 'width:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .el-single-meta .meta56__author a img' => 'width:{{SIZE}}{{UNIT}};',
    )
);

/**
 * LINK
 */
$params[ 'meta_separator_heading' ] = array(
    'type' => 'heading',
    'title' => 'Separator',
);

$params[ 'meta_link_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-meta a',
    'title' => 'Link Typography',
);

$params[ 'meta_link_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-meta a' => 'color:{{VALUE}};',
    ],
    'title' => 'Link Color',
);

$params[ 'meta_link_hover_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-meta a:hover' => 'color:{{VALUE}};',
    ],
    'title' => 'Link Hover Color',
);

$params[ 'meta_link_underline' ] = array(
    'type' => 'select',
    'options' => [
        'none' => 'None',
        'rest' => 'Underline normal state',
        'hover' => 'Underline on hover',
        'always' => 'Always underline',
    ],
    'std' => 'none',
    'title' => 'Link underline',
);

/**
 * SEPARATOR
 */
$params[ 'meta_separator_heading' ] = array(
    'type' => 'heading',
    'title' => 'Separator',
);

$params[ 'meta_separator' ] = array(
    'type' => 'text',
    'title' => 'Separator',
    'std' => '&middot;'
);

$params[ 'meta_separator_typography' ] = array(
    'type' => 'typography',
    'title' => 'Separator typography',
    'selector' => '{{WRAPPER}} .el-single-meta .sep',
);

$params[ 'meta_separator_color' ] = array(
    'type' => 'color',
    'title' => 'Separator color',
    'selectors' => array(
        '{{WRAPPER}} .el-single-meta .sep' => 'color:{{VALUE}};',
    )
);

$params[ 'meta_separator_spacing' ] = array(
    'type' => 'size',
    'title' => 'Separator spacing',
    
    'std_size' => 5,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 30,
    
    'selectors' => array(
        '{{WRAPPER}} .el-single-meta .sep' => 'margin-left:{{SIZE}}{{UNIT}}; margin-right:{{SIZE}}{{UNIT}};',
    )
);
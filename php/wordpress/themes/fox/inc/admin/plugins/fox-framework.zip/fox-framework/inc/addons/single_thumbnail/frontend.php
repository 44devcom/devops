<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'demo_image' => '',
    'thumbnail_size' => 'full',
]) );

$cl = [ 'el-single-thumbnail' ];

/**
 * final
 */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    <?php if ( fox_is_edit() || is_singular( 'elementor_library' ) || is_singular( 'fox_block' ) ) { ?>
    
    <div class="thumbnail-main">
                
        <div class="thumbnail-stretch-area">

            <figure class="fox-figure post-thumbnail post-thumbnail-standard hover-none thumbnail-acute" itemscope="" itemtype="https://schema.org/ImageObject">
                
                <span class="image-element thumbnail-inner">
                
                    <?php 
                                                                                                    $img_html = '';
if ( ! empty( $demo_image[ 'id'] ) ) {
    $img_html = wp_get_attachment_image( $demo_image[ 'id'], $thumbnail_size );
}
    if ( $img_html ) {
        echo $img_html;
    } else { ?>
                    <img src="<?php echo FOX_ELEMENTOR_URL; ?>images/placeholder3.jpg" alt="Placeholder Image" />
                    <?php } ?>
                
                </span>
                
            </figure>                    
        </div><!-- .thumbnail-stretch-area -->

    </div>
    
    <?php } else { ?>
    
        <?php if ( function_exists( 'foxfw3_elementor_single_thumbnail' ) ) {
            foxfw3_elementor_single_thumbnail([
                'size' => $thumbnail_size,
            ]);
        } else {
            the_post_thumbnail( $thumbnail_size );
        } ?>
    
    <?php } ?>
</div>
<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'source' => 'post_tag',
    'tax' => '',
    'include' => '',
    'exclude' => '',
    'number' => 'number',
    'hide_empty' => 'no',
    'show_count' => 'no',
    'orderby' => 'name',
    'order' => 'ASC',
    
    'heading' => '',
]) );

$cl = [ 'el-tax' ];

/**
 * final
 */
$cl = join( ' ', $cl );

ob_start();

/* General Tax
------------------------------------------------------------ */
if ( in_array( $source, [ 'post_tag', 'category', 'tax' ] ) ) { ?>

<?php
    if ( $source != 'tax' ) {
        $tax = $source;
    }

    $query_args = [ 'taxonomy' => $tax ];

    if ( $include ) {
        $include = explode( ',', $include );
        $include = array_map( 'absint', $include );
        $query_args[ 'include' ] = $include;
        $query_args[ 'orderby' ] = 'include';
        $query_args[ 'order' ] = 'ASC';
    } else {

        $query_args[ 'orderby' ] = $orderby;
        $query_args[ 'order' ] = $order;

        if ( $number ) {
            $query_args[ 'number' ] = $number;
        }

    }

    if ( $exclude ) {
        $exclude = explode( ',', $exclude );
        $exclude = array_map( 'absint', $exclude );
        $query_args[ 'exclude' ] = $exclude;
    }

    $query_args[ 'hide_empty' ] = ( 'yes' == $hide_empty );
    $q = get_terms( $query_args );

    if ( is_wp_error( $q ) ) {

        echo '<p class="error">' . $q->get_error_message() . '</p>';

    } else if ( is_array( $q ) && ! empty( $q ) ) {

        echo '<ul class="tax-inner">';

        foreach ( $q as $t ) {
            $count = ( $show_count == 'yes' ) ? '<sup>' . $t->count . '</sup>' : '';
            echo '<li><a href="' . esc_url( get_term_link( $t, $tax ) ) . '"><span class="tax-item-name">' . $t->name . '</span>' . $count . '</a></li>';
        }

        echo '</ul><!-- .tax-inner -->';
    }
    ?>

<?php
/* Single Tax
------------------------------------------------------------ */ } else { ?>

<?php if ( fox_is_edit() ) { ?>

<ul class="tax-inner">

    <li>
        <a href="#">
            <span class="tax-item-name">Travel</span>
            <?php if ( 'yes' == $show_count ) { echo '<sup>22</sup>'; } ?>
        </a>
    </li>

    <li>
        <a href="#">
            <span class="tax-item-name">Lifestyle</span>
            <?php if ( 'yes' == $show_count ) { echo '<sup>14</sup>'; } ?>
        </a>
    </li>

    <li>
        <a href="#">
            <span class="tax-item-name">Food</span>
            <?php if ( 'yes' == $show_count ) { echo '<sup>9</sup>'; } ?>
        </a>
    </li>

</ul>

<?php } else { ?>

<?php if ( ! is_single() ) {
    echo '<p class="error">This can only be used for single posts</p>';
} else {

    if ( 'single_tax' != $source ) {
        $tax = str_replace( 'single_', '', $source );
    }

    $q = get_the_terms( get_the_ID(), $tax );

    if ( is_wp_error( $q ) ) {

        echo '<p class="error">' . $q->get_error_message() . '</p>';

    } else if ( is_array( $q ) && ! empty( $q ) ) {
            
        echo '<ul class="tax-inner">';

        foreach ( $q as $t ) {
            echo '<li><a href="' . esc_url( get_term_link( $t, $tax ) ) . '"><span class="tax-item-name">' . $t->name . '</span></a></li>';
        }

        echo '</ul>';
    }

} ?>

<?php } ?>

<?php }

$result = ob_get_clean();

/**
 * in case no result found
 */
if ( ! $result ) {
    return;
}
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <?php if ( $heading ) { ?>
    <h3 class="el-tax-heading"><?php echo $heading; ?></h3>
    <?php } ?>
    
    <?php echo $result; ?>
    
</div>
<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'type' => 'wpcf7',
    
    // wpcf7
    'wpcf7_id' => 0,
    
    // mc4wp
    'mc4wp_id' => 0,
    'mc4wp_layout' => 'stack',
    
    // custom
    'custom_form_shortcode' => '',
    
    // common
    'label' => 'yes',
    'placeholder' => 'yes',
    
]) );

$cl = [
    'el-form',
];
$content = '';

/* Contact Form 7
------------------------------------------------------ */
if ( 'wpcf7' == $type ) {
    
    $cl[] = 'el-form-wpcf7';
    $sc = '[contact-form-7 id="' . $wpcf7_id . '"]';
    $content = do_shortcode( $sc );
 
/* Mailchimp
------------------------------------------------------ */
} elseif ( 'mc4wp' == $type ) {
    
    $cl[] = 'el-form-mc4wp';
    $sc = '[mc4wp_form id="' . esc_attr( $mc4wp_id ) . '"]';
    $content = do_shortcode( $sc );
    
    /* layout
    --------------------------- */
    if ( 'inline' != $mc4wp_layout ) {
        $mc4wp_layout = 'stack';
    }
    $cl[] = 'el-form-' . $mc4wp_layout;
    
/* Custom
------------------------------------------------------ */
} elseif ( 'custom' == $type ) {
    
    $cl[] = 'el-form-custom';
    $sc = $custom_form_shortcode;
    $content = do_shortcode( $sc );
    
}

if ( in_array( $type, [ 'reservation', 'custom' ] ) ) {

    /* placeholder
    --------------------------- */
    if ( 'yes' == $placeholder ) {
        $cl[] = 'form-has-placeholder';
    } else {
        $cl[] = 'form-no-placeholder';
    }

    /* label
    --------------------------- */
    if ( 'yes' == $label ) {
        $cl[] = 'form-has-label';
    } else {
        $cl[] = 'form-no-label';
    }
    
}

/* final
--------------------------- */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <?php echo $content ?>
    
</div><!-- .fox-restaurant-reservation -->
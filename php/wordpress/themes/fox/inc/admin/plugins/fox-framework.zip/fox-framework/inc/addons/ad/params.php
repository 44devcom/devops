<?php
$params = [];
    
$params[ 'code' ] = array(
    'title' => esc_html__( 'Custom Ad Code', 'wi' ),
    'type' => 'textarea',

    'section' => 'settings',
    'section_title' => 'Settings',
);

$params[ 'image' ] = array(
    'id' => 'image',
    'title' => esc_html__( 'Image', 'wi' ),
    'type' => 'media',
);

$params[ 'width' ] = array(
    'id' => 'width',
    'title' => 'Image width',
    'type' => 'text',
);

$params[ 'tablet' ] = array(
    'id' => 'tablet',
    'title' => 'Tablet Image',
    'type' => 'media',
);

$params[ 'tablet_width' ] = array(
    'id' => 'tablet_width',
    'title' => 'Width tablet screen',
    'type' => 'text',
);


$params[ 'phone' ] = array(
    'id' => 'phone',
    'title' => 'Phone Image',
    'type' => 'media',
);

$params[ 'phone_width' ] = array(
    'id' => 'phone_width',
    'title' => 'Width phone screen',
    'type' => 'text',
);

$params[ 'url' ] = array(
    'id' => 'url',
    'title' => esc_html__( 'Link', 'wi' ),
    'type' => 'text',
);

$params[ 'target' ] = array(
    'title' => 'Open link in',
    'type' => 'select',
    'options' => [
        '_self' => 'Same tab',
        '_blank' => 'New tab',
    ],
    'std' => '_blank',
);
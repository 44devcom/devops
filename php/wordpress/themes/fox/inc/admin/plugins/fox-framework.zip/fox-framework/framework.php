<?php
/**
 * Plugin Name: FOX Framework
 * Plugin URI: https://themeforest.net/user/withemes/
 * Description: Core Framework for The Fox theme: Elementor Addon Elements, Header Builder, Footer Builder, Post Builder, Archive Builder and many more functionalities
 * Version: 3.0
 * Author: WiThemes
 * Author URI: https://themeforest.net/user/withemes
 * Copyright: (c) 2022 WiThemes
 * Text Domain: wi
 */

// Do not load directly
if ( ! defined ( 'ABSPATH' ) ) die ( '-1' );

/* SYSTEM STUFFS
------------------------------------------------------------------------------------------ */
/**
 * this function checks if theme engine = v6
 */
function is_engine_v6() {
    return function_exists( 'fox56' ) && fox56();
}

// Define things
define ( 'FOX_FRAMEWORK_VERSION', '3.0' );
define ( 'FOX_FRAMEWORK_FILE', __FILE__ );
define ( 'FOX_FRAMEWORK_PATH', plugin_dir_path( FOX_FRAMEWORK_FILE ) );
define ( 'FOX_FRAMEWORK_URL', plugins_url ( '/', FOX_FRAMEWORK_FILE ) );

define ( 'FOX_ELEMENTOR_FILE', __FILE__ );
define ( 'FOX_ELEMENTOR_PATH', plugin_dir_path( FOX_ELEMENTOR_FILE ) );
define ( 'FOX_ELEMENTOR_URL', plugins_url ( '/', FOX_ELEMENTOR_FILE ) );

/* INCLUDE
------------------------------------------------------------------------------------------ */
/**
 * FUNCTIONS
 */
require FOX_FRAMEWORK_PATH . 'inc/helpers.php';
require FOX_FRAMEWORK_PATH . 'inc/functions3.php'; // GENERAL FUNCTIONS, TEMPLATE-TAGS
require FOX_FRAMEWORK_PATH . 'inc/blog.php'; // OLD BLOG FUNCTION: big, vertical, masonry..
require FOX_FRAMEWORK_PATH . 'inc/query.php'; // QUERY functions
require FOX_FRAMEWORK_PATH . 'inc/params.php'; // PARAMS FOR ELEMENTOR

/**
 * CPT FOX_BLOCK
 * yes, It works on its own
 */
require FOX_FRAMEWORK_PATH . 'inc/fox_block.php';

/**
 * LOAD ELEMENTOR ADDONS
 * this will load elementor-addons.php
 */
require FOX_FRAMEWORK_PATH . 'inc/elementor-loader.php';

/**
 * ELEMENTOR TEMPLATES
 * this should work on its own
 */
function fox_elementor_load_templates() {
    require FOX_FRAMEWORK_PATH . 'inc/templates.php';
}
add_action( 'elementor/init', 'fox_elementor_load_templates' );

/**
 * CUSTOM HOOKS, EG. ADD MORE SECTION OPTIONS
 * this should work on its own
 */
require FOX_FRAMEWORK_PATH . 'inc/hooks.php';

/* MISC
------------------------------------------------------------------------------------------ */
/**
 * DEBUG INFO
 */
add_action( 'wp_footer', 'fox_framework_print_version' );
function fox_framework_print_version() {
    echo '<span data-foxframework-version="' . esc_attr( FOX_FRAMEWORK_VERSION ) . '"></span>';
}

/**
 * ACTIVATION/DEACTIVATION
 */
function fox_framework_deactivation() {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'fox_framework_deactivation' );
function fox_framework_activation() {
    fox_elementor_register_multipurpose_blocks();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'fox_framework_activation' );

/* ADMIN NOTICE
------------------------------------------------------------------------------------------ */
add_action( 'wp_body_open', 'fox_framework_regenerate_style_notice' );
function fox_framework_regenerate_style_notice() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    if ( isset( $_GET['fox_framework_30_dismiss_message'] ) ) {
        update_option( 'fox_framework_30_dismiss_message', true );
    }
    if ( get_option( 'fox_framework_30_dismiss_message' ) ) {
        return;
    }
    // if Elementor not installed, then we don't need this message
    if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
        update_option( 'fox_framework_30_dismiss_message', true );
        return;
    }
    $dismiss_url = add_query_arg( 'fox_framework_30_dismiss_message', '1', get_site_url() );
    ?>
    <div style="background:#e7cccc; color: #821818; margin: 10px; padding: 10px; text-align: center; font-size: 20px;">
        <p>ADMIN NOTICE (Your visitors don't see this): You have just updated the plugin Fox Framework to verions 3.0<br>
        Please go to <a href="<?php echo admin_url( 'admin.php?page=elementor-tools' ); ?>" target="_blank" style="font-weight: bold; text-decoration: underline;">Dashboard &raquo; Elementor &raquo; Tools</a> and "Regenerate CSS & Data" to update your site style.</p>
        
        <a href="<?php echo esc_url( $dismiss_url ); ?>" style="display: block; border: 2px solid red; color: red; font-weight: bold; background: white; margin: 20px 0 0; line-height: 60px;">I did it. Hide this message.</a>
    </div>
    <?php
}
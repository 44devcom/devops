<?php
function fox_is_preview() {
    $check = false;
    if ( class_exists( '\Elementor\Plugin' ) ) {
        $check = \Elementor\Plugin::$instance->preview->is_preview_mode();
    }

    return $check;
}

function fox_is_edit() {
    if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ){
        return true;
    }
    if ( is_singular() ) {
        if ( in_array( get_post_type(), [ 'fox_block', 'elementor_library' ] ) ) {
            return true;
        }
    }

    return false;
}

function fox_elementor_fake_comment( $args ){
    extract( wp_parse_args( $args, [
        'image' => '',
        'content' => '',
        'name' => 'John Doe',
        'children' => '',
    ] ) );
    ob_start();
    ?>
    <li class="comment">
        <article class="comment-body">
            <footer class="comment-meta">
                
                <div class="comment-author vcard">
                    <img alt="Image" src="<?php echo esc_attr( $image ); ?>" />
                    <b class="fn"><?php echo $name; ?></b> 
                    <span class="says">says:</span> 
                </div>
                
                <div class="comment-metadata">
                    <a href="#">
                        <time>May 12 at 12:20 pm</time>
                    </a> 
                </div>
            </footer>
            
            <div class="comment-content">
                <?php if ( ! $content ) {
            $content = 'Has no sale fierent, libris audire voluptua sit et. Vis assum iriure mnesarchum in, novum invenire reprimique cum id. Mazim reprehendunt at vel';
    } ?>
                <p><?php echo $content; ?></p>
            </div>
            <div class="reply">
                <a class="comment-reply-link" href="#">Reply</a>
            </div> 
        </article>
        <?php if ( $children ) { ?>
        <ul class="children">
            <?php echo $children; ?>
        </ul>
        <?php } ?>
    </li>
<?php
    return ob_get_clean();
}

function foxfw3_word( $w ) {
    if ( function_exists( 'fox_word' ) ) {
        return fox_word( $w );
    }
    return $w;
}

/* turn 2555 --> 2.5k
 // thank to https://stackoverflow.com/a/14531760/1346258
------------------------------------------------------------------------------------ */
function foxfw3_number( $n, $precision = 1 ) {
    
    if ($n < 1000) {
        // Anything less than a million
        $n_format = number_format($n) + 0;
    } else if ($n < 1000000) {
        // Anything less than a billion
        $n_format = ( number_format($n / 1000, $precision) + 0 ) . 'K';
    } else if ($n < 1000000000) {
        // Anything less than a billion
        $n_format = ( number_format($n / 1000000, $precision) + 0 ) . 'M';
    } else {
        // At least a billion
        $n_format = ( number_format($n / 1000000000, $precision) + 0 ) . 'B';
    }

    return $n_format;
}
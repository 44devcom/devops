<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    'source' => 'menu',
    'taxonomy' => '',
    'number' => '',
    'orderby' => 'slug',
    'order' => 'asc',
    // 'item_count' => 'no',
    'menu' => '',
    'dir' => 'horizontal',
    
    'item_hover_effect' => '',
    'hnav_item_sep_between' => 'no',
    'dropdown_align' => 'left',
    'has_dropdown_indicator' => '',
]) );

$cl = [ 'el-nav', 'nav-' . $menu ];

/* dir
--------------------------- */
if ( 'vertical' != $dir ) {
    $dir = 'horizontal';
}
if ( 'vertical' == $dir ) {
    $cl[] = 'vnav';
} else {
    $cl[] = 'hnav';
}

/* dropdown align
--------------------------- */
if ( ! in_array( $dropdown_align, [ 'center', 'right' ] ) ) {
    $dropdown_align = 'left';
}
$cl[] = 'el-nav-dropdown-' . $dropdown_align;

/* angle down option
--------------------------- */
if ( 'horizontal' == $dir ) {
    
    if ( ! in_array( $has_dropdown_indicator, [ 'caret-down', 'angle-down', 'plus' ] ) ) {
        $has_dropdown_indicator = '';
    }
    
}

/* sep between items
--------------------------- */
if ( 'horizontal' == $dir ) {
    if ( 'yes' == $hnav_item_sep_between ) {
        $cl[] = 'style-has-sep-between';
    }
    if ( ! in_array( $item_hover_effect, [ 'border_top', 'border_bottom', 'background' ] ) ) {
        $item_hover_effect = '';
    }
    if ( $item_hover_effect ) {
        $cl[] = 'style-hover-' . $item_hover_effect;
    }
}

/* source
--------------------------- */
$cl[] = 'el-nav-' . $source;

/* final
--------------------------- */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <div class="nav-inner">
    
        <?php
        if ( 'menu' == $source ) {
            
            $menu_args = array(
                'menu'          =>  $menu,
                'depth'         =>	6,
                'link_before'   => '<span>',
                'link_after'    => '</span><u class="mk"></u>',
            );
            
            if ( 'horizontal' == $dir ) {
                if ( $has_dropdown_indicator ) {
                    $menu_args[ 'container_class' ] = 'style-indicator-' . $has_dropdown_indicator;   
                }
            }
            
            if ( is_nav_menu( $menu ) ) {
                wp_nav_menu( $menu_args );
            } else {
                echo '<p class="error">Please select your menu</p>';
            }
        } else {
            if ( 'category' == $source || 'post_tag' == $source ) {
                $tax = $source;
            } else {
                $tax = $taxonomy;
            }
            if ( ! $tax ) {
                echo '<p class="error">Please enter taxonomy slug</p>';
            } else {
                
                echo '<div><ul class="menu">';
                wp_list_categories([
                    'hide_title_if_empty' => true,
                    'title_li' => '',
                    'taxonomy' => $tax,
                    'echo' => 1,
                    // 'show_count' => ( $item_count == 'yes' ),
                    'style' => 'list',
                    'number' => $number,
                    
                    'orderby' => $orderby,
                    'order' => strtoupper( $order ),
                ]);
                echo '</ul></div>';
            }
        }
        
        ?>
        
    </div>
    
</div>
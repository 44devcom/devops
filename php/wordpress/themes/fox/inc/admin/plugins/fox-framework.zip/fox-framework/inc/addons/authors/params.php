<?php
/* Query
------------------------ */
$params[ 'source' ] = array(
    'type' => 'select',
    'options' => [
        'query' => 'Author list',
        'author_page' => 'Current Author (Author Page)',
        'post_author' => 'Post Author (Single Post)',
    ],
    'title' => 'Source',
    'desc' => 'If you choose source "Current Author" or "Post Author", it shows only 1 user for corresponding context.',
    'std' => 'query',
    
    'section' => 'query',
    'section_title' => 'Query',
);

$params[ 'number' ] = array(
    'type' => 'text',
    'title' => 'Number to display',
    'std' => '4',
    
    'condition' => [
        'source[value]' => 'query',
    ],
);

$params[ 'orderby' ] = array(
    'type' => 'select',
    'options' => array(
        'display_name' => 'Name',
        'post_count' => 'Post count',
        'registered' => 'Registered Date',
    ),
    'std' => 'post_count',
    'title' => 'Order by',
    
    'condition' => [
        'source[value]' => 'query',
    ],
);

$params[ 'order' ] = array(
    'type' => 'select',
    'options' => array(
        'asc' => 'Ascending',
        'desc' => 'Descending',
    ),
    'std' => 'desc',
    'title' => 'Order',
    
    'condition' => [
        'source[value]' => 'query',
    ],
);

$params[ 'has_published_posts' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Only display authors',
    'desc'  => 'Author means users have at least 1 published post.',
    
    'condition' => [
        'source[value]' => 'query',
    ],
);

$params[ 'include' ] = array(
    'type' => 'text',
    'title' => 'Only show users with IDs:',
    'desc' => 'Separate ids by comma',
    
    'condition' => [
        'source[value]' => 'query',
    ],
);

$params[ 'exclude' ] = array(
    'type' => 'text',
    'title' => 'Exclude authors by IDs:',
    'desc' => 'Separate ids by comma',
    
    'condition' => [
        'source[value]' => 'query',
    ],
);

/* Display
------------------------ */
$params[ 'layout' ] = array(
    'type' => 'select',
    'title' => 'Layout',
    'options' => array(
        'grid' => 'Grid',
        'list' => 'List',
    ),
    'std' => 'grid',
    
    'section' => 'display',
    'section_title' => 'Display',
);

$params[ 'column' ] = array(
    'type' => 'select',
    'title' => 'Column',
    'options' => array(
        '1' => '1 column',
        '2' => '2 columns',
        '3' => '3 columns',
        '4' => '4 columns',
        '5' => '5 columns',
    ),
    'std' => '3',
    'condition' => [
        'layout[value]' => 'grid',
    ],
);

$params[ 'grid_spacing' ] = array(
    'type' => 'size',
    'title' => 'Grid spacing',
    'condition' => [
        'layout[value]' => 'grid',
    ],
    
    'std_unit' => 'px',
    'std_size' => 16,
    'px_max' => 100,
    'px_min' => 0,

    'selectors' => [
        '{{WRAPPER}} .fox-authors-grid .fox-user-item' => 'padding: {{SIZE}}{{UNIT}} {{SIZE}}{{UNIT}} 0;',
        '{{WRAPPER}} .fox-authors-grid' => 'margin: -{{SIZE}}{{UNIT}} -{{SIZE}}{{UNIT}} 0;',
    ],
);

$params[ 'align' ] = array(
    'type' => 'align',
    'title' => 'Align',
    'std' => 'left',
    'condition' => [
        'layout[value]' => 'grid',
    ],
);

$params[ 'valign' ] = array(
    'type' => 'select',
    'title' => 'Vertical alignment',
    'std' => 'top',
    'options' => [
        'top' => 'Top',
        'middle' => 'Middle',
        'bottom' => 'Bottom',
    ],
    'condition' => [
        'layout[value]' => 'list',
    ],
);

$params[ 'list_spacing' ] = array(
    'type' => 'size',
    'title' => 'List spacing',
    'condition' => [
        'layout[value]' => 'list',
    ],
    
    'std_unit' => 'px',
    'std_size' => 16,
    'px_max' => 100,
    'px_min' => 0,

    'selectors' => [
        '{{WRAPPER}} .fox-authors-list .fox-user-item + .fox-user-item' => 'padding-top: {{SIZE}}{{UNIT}};margin-top: {{SIZE}}{{UNIT}};',
    ],
);

$params[ 'avatar_text_spacing' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .fox-authors-list .user-item-avatar' => 'margin-right:{{SIZE}}{{UNIT}}',
    ],
    'title' => 'Avatar - Text spacing',
    
    'condition' => [
        'layout[value]' => 'list',
    ],
    
    'std_unit' => 'px',
    'std_size' => 32,
    'px_max' => 80,
    'px_min' => 0,
);

/* @todo: list valign */

$params[ 'text_color' ] = array(
    'type' => 'color',
    'title' => 'Text Color',
    'selectors' => [
        '{{WRAPPER}} .fox-authors' => 'color:{{VALUE}};'
    ],
);

$params[ 'border' ] = array(
    'type' => 'switcher',
    'title' => 'Border',
    'std' => 'yes',
);

$params[ 'border_color' ] = array(
    'type' => 'color',
    'title' => 'Border Color',
    'std' => '#c0c0c0',
    'selectors' => [
        '{{WRAPPER}} .line' => 'background:{{VALUE}};',
        '{{WRAPPER}} .fox-authors-list .fox-user-item + .fox-user-item' => 'border-top-color:{{VALUE}};',
    ],
);

/* avatar
------------------------ */
$params[ 'show_author_avatar' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display author avatar',
    
    'section' => 'avatar',
    'section_title' => 'Avatar',
);

$params[ 'author_avatar_width' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .user-item-avatar img' => 'width:{{SIZE}}{{UNIT}}',
    ],
    'title' => 'Avatar size',
    
    'std_unit' => 'px',
    'std_size' => 120,
    'px_max' => 400,
    'px_min' => 40,
);

$params[ 'author_avatar_border_radius' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .user-item-avatar img' => 'border-radius:{{SIZE}}{{UNIT}}',
    ],
    'title' => 'Avatar border radius',
    
    'std_unit' => '%',
    'std_size' => 50,
    'px_max' => 60,
    'px_min' => 0,
);

/* name
------------------------ */
$params[ 'show_author_name' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display author name',
    
    'section' => 'author_name',
    'section_title' => 'Author name',
);

$params[ 'author_name_typography' ] = array(
    'type' => 'typography',
    'title' => 'Author name typography',
    'selector' => '{{WRAPPER}} .user-item-name',
);

$params[ 'author_name_color' ] = array(
    'type' => 'color',
    'title' => 'Author name color',
    'selectors' => [
        '{{WRAPPER}} .user-item-name' => 'color:{{VALUE}};'
    ],
);

/* description
------------------------ */
$params[ 'show_author_description' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display author description',
    
    'section' => 'author_description',
    'section_title' => 'Author description',
);

$params[ 'author_description_typography' ] = array(
    'type' => 'typography',
    'title' => 'Author description typography',
    'selector' => '{{WRAPPER}} .user-item-description',
);

$params[ 'author_description_color' ] = array(
    'type' => 'color',
    'title' => 'Author user-item-description color',
    'selectors' => [
        '{{WRAPPER}} .user-item-description' => 'color:{{VALUE}};',
    ],
);

/* social
------------------------ */
$params[ 'show_author_social' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display author social links',
    
    'section' => 'author_social',
    'section_title' => 'Author social',
);

$params[ 'author_social_style' ] = array(
    'type' => 'select',
    'options' => [
        'plain' => 'Plain',
        'black' => 'Black',
        'outline' => 'Outline',
        'fill' => 'Fill',
        'text_color' => 'Brand Color',
        'color' => 'Brand Background',
    ],
    'std' => 'plain',
    'title' => 'Social icon style',
);

$params[ 'author_social_size' ] = array(
    'type' => 'size',
    'title' => 'Social icon size',
    'selectors' => [
        '{{WRAPPER}} .user-item-social a' => 'font-size:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 16,
    'px_max' => 30,
    'px_min' => 8,
);

/* latest posts
------------------------ */
$params[ 'show_author_posts' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Show user posts',
    
    'section' => 'author_posts',
    'section_title' => 'Author Posts',
);

$params[ 'author_posts_number' ] = array(
    'type' => 'text',
    'title' => 'Number of posts',
    'std'   => '2',
);

$params[ 'author_posts_source' ] = [
    'type' => 'select',
    'options' => [
        'latest' => 'Latest posts',
        'featured' => 'Featured posts',
        'view' => 'Most viewed',
    ],
    'std' => 'latest',
    'title' => 'Post Source',
];

$params[ 'author_posts_typography' ] = array(
    'type' => 'typography',
    'title' => 'Author posts typography',
    'selector' => '{{WRAPPER}} .user-item-posts a',
);

$params[ 'author_posts_color' ] = array(
    'type' => 'color',
    'title' => 'Author posts color',
    'selectors' => [
        '{{WRAPPER}} .user-item-posts' => 'color:{{VALUE}};',
    ],
);

$params[ 'author_posts_margin_top' ] = array(
    'type' => 'size',
    'title' => 'Author posts top spacing',
    'selectors' => [
        '{{WRAPPER}} .user-item-posts' => 'padding-top:{{SIZE}}{{UNIT}};margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 10,
    'px_max' => 30,
    'px_min' => 0,
);

$params[ 'author_posts_item_border_width' ] = array(
    'type' => 'size',
    'title' => 'Author posts item sep',
    'selectors' => [
        '{{WRAPPER}} .user-item-posts' => 'border-top-width:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 1,
    'px_max' => 8,
    'px_min' => 0,
);

$params[ 'author_posts_item_border_color' ] = array(
    'type' => 'color',
    'title' => 'Author posts sep color',
    'selectors' => [
        '{{WRAPPER}} .user-item-posts' => 'border-top-color:{{VALUE}};',
    ],
);
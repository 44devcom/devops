<?php
namespace Fox_Elementor;

/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.0
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @since 1.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;
    
    /**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.0
	 * @access public
	 */
	public function __construct() {
        
        add_action( 'elementor/frontend/before_register_scripts', array( $this, 'widget_scripts' ) ); 
        // add_action( 'elementor/frontend/after_register_scripts', array( $this, 'widget_scripts' ) );
        
        // addons
        add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ), 0 );
        
        // categories
        add_action( 'elementor/elements/categories_registered', array( $this, 'register_categories' ) );
        
        // editor css
        add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'editor_scripts' ) );
            
	}

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
    
    function register_categories( $elements_manager ) {

        $elements_manager->add_category(
            'fox',
            [
                'title' => 'Fox Elements',
                'icon' => 'eicon-archive-posts',
            ]
        );
        
        $elements_manager->add_category(
            'fox_single',
            [
                'title' => 'Fox Single Post',
                'icon' => 'eicon-single-post',
            ]
        );
        
        $elements_manager->add_category(
            'fox_archive',
            [
                'title' => 'Fox Archive',
                'icon' => 'eicon-archive-posts',
            ]
        );
        
        $reorder_cats = function() {
            uksort( $this->categories, function( $k1, $k2 ) {
                
                if ( $k1 == 'fox' ) {
                    return -1;
                }
                if ( $k2 == 'fox' ) {
                    return 1;
                }
                
                if ( $k1 == 'fox_single' ) {
                    return -1;
                }
                if ( $k2 == 'fox_single' ) {
                    return 1;
                }
                
                if ( $k1 == 'fox_archive' ) {
                    return -1;
                }
                if ( $k2 == 'fox_archive' ) {
                    return 1;
                }
                
                return 0;
                
            } );

        };
        \Closure::bind( $reorder_cats, $elements_manager, $elements_manager )();

    }

	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.0
	 * @access public
	 */
	public function widget_scripts() {
        
        // Register widget scripts
		wp_enqueue_style( 'fox-elementor', FOX_FRAMEWORK_URL . 'css/framework.css', [ 'elementor-frontend', 'swiper' ], FOX_FRAMEWORK_VERSION );
        
        wp_enqueue_script( 'fox-elementor-imagesloaded', FOX_FRAMEWORK_URL . 'js/imagesloaded.pkgd.min.js', [], FOX_FRAMEWORK_VERSION, true );

        wp_enqueue_script( 'fox-elementor-easing', FOX_FRAMEWORK_URL . 'js/jquery.easing.1.3.js', [], FOX_FRAMEWORK_VERSION, true );

        wp_enqueue_script( 'fox-elementor-flexslider', FOX_FRAMEWORK_URL . 'js/jquery.flexslider-min.js', [], FOX_FRAMEWORK_VERSION, true );

        wp_enqueue_script( 'fox-elementor-masonry', FOX_FRAMEWORK_URL . 'js/masonry.pkgd.min.js', [], FOX_FRAMEWORK_VERSION, true );

        wp_enqueue_script( 'fox-elementor-inview', FOX_FRAMEWORK_URL . 'js/jquery.inview.min.js', [], FOX_FRAMEWORK_VERSION, true );

        wp_enqueue_script( 'fox-elementor', FOX_FRAMEWORK_URL . 'js/fox-elementor.js', array( 'jquery' ), FOX_FRAMEWORK_VERSION, true );
        
        /**
         * load more style if It's engine v6
         */
        if ( is_engine_v6() || ! defined( 'FOX_VERSION' ) ) {
            wp_enqueue_style( 'fox-v55', FOX_FRAMEWORK_URL . 'css/v55.css', [ 'elementor-frontend' ], FOX_FRAMEWORK_VERSION );
        }
        
	}
    
    /**
     * editor script
     * since 1.1
     */
    function editor_scripts( ) {
        wp_enqueue_style( 'fox-elementor-editor', FOX_FRAMEWORK_URL . 'css/editor.css', [ 'elementor-editor' ], FOX_FRAMEWORK_VERSION );
		// wp_enqueue_script( 'fox-elementor-editor', plugins_url( '/js/editor.js', __FILE__ ), array( 'jquery' ), FOX_FRAMEWORK_VERSION, true );
    }

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.0
	 * @access private
	 */
	private function include_widgets_files() {
        
        require_once FOX_FRAMEWORK_PATH . 'inc/widget-base.php';
        
        require_once( __DIR__ . '/addons/logo/index.php' );
        require_once( __DIR__ . '/addons/btn/index.php' );
        require_once( __DIR__ . '/addons/search/index.php' );
        require_once( __DIR__ . '/addons/nav/index.php' );
        require_once( __DIR__ . '/addons/heading/index.php' );
        require_once( __DIR__ . '/addons/form/index.php' );
        require_once( __DIR__ . '/addons/tile/index.php' );
        require_once( __DIR__ . '/addons/banner/index.php' );
        require_once( __DIR__ . '/addons/instagram/index.php' );
        require_once( __DIR__ . '/addons/authors/index.php' );
        require_once( __DIR__ . '/addons/share/index.php' );


        require_once( __DIR__ . '/addons/post_grid/index.php' );
        require_once( __DIR__ . '/addons/post_list/index.php' );
        require_once( __DIR__ . '/addons/post_standard/index.php' );
        require_once( __DIR__ . '/addons/post_group2/index.php' );
        require_once( __DIR__ . '/addons/post_group1/index.php' );

        require_once( __DIR__ . '/addons/post_big/index.php' );
        require_once( __DIR__ . '/addons/post_slider/index.php' );
        require_once( __DIR__ . '/addons/post_masonry/index.php' );
        require_once( __DIR__ . '/addons/post_newspaper/index.php' );
        require_once( __DIR__ . '/addons/post_vertical/index.php' );

        require_once( __DIR__ . '/addons/single_title/index.php' );
        require_once( __DIR__ . '/addons/single_subtitle/index.php' );
        require_once( __DIR__ . '/addons/single_meta/index.php' );
        require_once( __DIR__ . '/addons/single_thumbnail/index.php' );
        require_once( __DIR__ . '/addons/single_content/index.php' );
        require_once( __DIR__ . '/addons/single_comments/index.php' );
        require_once( __DIR__ . '/addons/taxonomy/index.php' );

        require_once( __DIR__ . '/addons/archive_title/index.php' );
        require_once( __DIR__ . '/addons/archive_description/index.php' );

        /*
        // deprecated
        require_once( __DIR__ . '/addons/button/index.php' );
        require_once( __DIR__ . '/addons/ad/index.php' );
        require_once( __DIR__ . '/addons/subscribe_form/index.php' );
        */
        
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.0
	 * @access public
	 */
	public function register_widgets() {
        
		// Its is now safe to include Widgets files
		$this->include_widgets_files();
        
        // ELEMENTS
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Logo() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Btn() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Search() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Nav() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Heading() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Form() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Tile() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Banner() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Instagram() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Authors() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Share() );

        // MAJOR
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Grid() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_List() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Standard() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Group2() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Group1() );

        // MINOR
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Big() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Slider() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Masonry() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Newspaper() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Post_Vertical() );

        // SINGLE
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Single_Title() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Single_Subtitle() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Single_Meta() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Single_Thumbnail() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Single_Content() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Single_Comments() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Taxonomy() );

        // ARCHIVE
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Archive_Title() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Archive_Description() );

        /*
        // deprecated
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Button() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Subscribe_Form() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Ad() );
        */
        return;
        
	}
}

// Instantiate Plugin Class
Plugin::instance();
<?php
$settings = $this->get_settings_for_display();
$settings[ 'layout' ] = 'standard';

extract( wp_parse_args( $settings, [
    'pagination' => '',
    'layout' => 'standard',
    
    'item_template' => '1',
    
    'header_align' => '',
    
    // component params
    'show_thumbnail' => '',
    'show_title' => '',
    'show_date' => '',
    'show_category' => '',
    'show_author' => '',
    'show_author_avatar' => '',
    'show_excerpt' => '',
    'show_excerpt_more' => '',
    'show_view' => '',
    'show_reading_time' => '',
    'show_comment_link' => '',

    // thumbnail options
    'thumbnail_type' => 'simple',
    'thumbnail_header_order' => 'thumbnail',
    
    // title options
    'title_tag' => '',
    
    // excerpt options
    'display_excerpt' => 'yes',
    'content_excerpt' => 'excerpt',
    'excerpt_length' => 22,
    'excerpt_size' => '', // legacy
    'excerpt_hellip' => '',
    'excerpt_more' => '',
    'excerpt_more_style' => '',
    'excerpt_more_text' => '',
    
    'show_share' => 'no',
    'show_related' => 'no',

    // extra
    'extra_class' => '', // legacy
    
]) );

// no posts found
// don't waste my time
$query = foxfw3_query( $settings );
if ( ! $query ) {
    return;
}

if ( isset( $settings[ 'source' ] ) && 'archive' == $settings[ 'source' ] ) {
    $pagination = 'yes';
}

if ( ! $query->have_posts() ) {
    wp_reset_query();
    return;
}


$container_cl = [ 'blog-container', 'blog-container-grid' ];    
$cl = [ 'wi-blog', 'fox-blog', 'blog-standard' ];

/* extra class
-------------------------------------- */
if ( $extra_class ) {
    $cl[] = $extra_class;
}

/* spacing
// we set the default spacing level while we have total control over it by number
-------------------------------------- */
$cl[] = 'standard-spacing-normal';

?>

<div class="<?php echo esc_attr( join( ' ', $container_cl ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $cl ) ); ?>">
    
    <?php 
    $count = 0;
    while ( $query->have_posts() ) {
        
        $query->the_post();
        $count++;
        
        include FOX_FRAMEWORK_PATH . 'content/post-standard.php';
        do_action( 'fox_after_render_post' );
        
    } ?>
        
    </div><!-- .fox-blog -->
    
    <?php if ( 'yes' == $pagination ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->

    <?php

wp_reset_query();
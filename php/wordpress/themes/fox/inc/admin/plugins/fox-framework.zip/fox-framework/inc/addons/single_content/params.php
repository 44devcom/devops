<?php
/* General
------------------------------------------- */
$params[ 'h_content' ] = array(
    'type' => 'heading',
    'title' => 'General',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'content_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-content',
    'title' => 'Typography',
);

$params[ 'content_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content' => 'color:{{VALUE}};',
    ],
    'title' => 'Color',
);


/* Heading
------------------------------------------- */
$params[ 'h_heading' ] = array(
    'type' => 'heading',
    'title' => 'Heading',
);
$params[ 'heading_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-content h1, {{WRAPPER}} .el-single-content h2, {{WRAPPER}} .el-single-content h3, {{WRAPPER}} .el-single-content h4, {{WRAPPER}} .el-single-content h5, {{WRAPPER}} .el-single-content h6',
    'title' => 'Heading Typgraphy',
);

$params[ 'heading_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content h1' => 'color:{{VALUE}};',
        '{{WRAPPER}} .el-single-content h2' => 'color:{{VALUE}};',
        '{{WRAPPER}} .el-single-content h3' => 'color:{{VALUE}};',
        '{{WRAPPER}} .el-single-content h4' => 'color:{{VALUE}};',
        '{{WRAPPER}} .el-single-content h5' => 'color:{{VALUE}};',
        '{{WRAPPER}} .el-single-content h6' => 'color:{{VALUE}};',
    ],
    'title' => 'Heading Color',
);

/* Link
------------------------------------------- */
$params[ 'h_link' ] = array(
    'type' => 'heading',
    'title' => 'Link',
);

$params[ 'link_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content a' => 'color:{{VALUE}};',
    ],
    'title' => 'Link Color',
);

$params[ 'link_hover_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content a:hover' => 'color:{{VALUE}};',
    ],
    'title' => 'Link Hover Color',
);

$params[ 'link_style' ] = array(
    'type' => 'select',
    'options' => [
        '' => 'Default',
        '1' => 'Grey underline',
        '2' => 'Same color underline',
        '3' => 'Black underline',
        '4' => 'No style',
    ],
    'title' => 'Link Style',
);

/* Blockquote
------------------------------------------- */
$params[ 'h_blockquote' ] = array(
    'type' => 'heading',
    'title' => 'Blockquote',
);

$params[ 'blockquote_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-content blockquote',
    'title' => 'Blockquote Typography',
);

$params[ 'blockquote_background' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content blockquote' => 'background-color:{{VALUE}};',
    ],
    'title' => 'Blockquote background',
);

$params[ 'blockquote_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content blockquote' => 'color:{{VALUE}};',
    ],
    'title' => 'Blockquote Color',
);

$params[ 'blockquote_cite_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-content blockquote cite',
    'title' => 'Blockquote cite typography',
);

$params[ 'blockquote_cite_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content blockquote cite' => 'color:{{VALUE}};',
    ],
    'title' => 'Blockquote cite color',
);

$params[ 'blockquote_padding' ] = array(
    'type' => 'size',
    'std_size' => 0,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 100,
    
    'selectors' => array(
        '{{WRAPPER}} .el-single-content blockquote' => 'padding:{{SIZE}}{{UNIT}};' 
    ),
    'title' => 'Blockquote padding',
);

/* Image
------------------------------------------- */
$params[ 'h_image' ] = array(
    'type' => 'heading',
    'title' => 'Image',
);

$params[ 'caption_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-content .wp-caption-text, {{WRAPPER}} .el-single-content .wp-block-image figcaption, {{WRAPPER}} .el-single-content .blocks-gallery-caption',
    'title' => 'Image Caption Typography',
);

$params[ 'caption_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-content .wp-caption-text, {{WRAPPER}} .el-single-content .wp-block-image figcaption, {{WRAPPER}} .el-single-content .blocks-gallery-caption' => 'color:{{VALUE}};',
    ],
    'title' => 'Image Caption Color',
);
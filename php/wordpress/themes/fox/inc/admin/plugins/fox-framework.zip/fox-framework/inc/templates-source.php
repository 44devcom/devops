<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Fox_Elementor_Templates_Source extends Elementor\TemplateLibrary\Source_Base {
	/**
	 * Get remote template ID.
	 * Retrieve the remote template ID.
	 * @return string The remote template ID.
	 */
	public function get_id() {
		return 'fox';
	}
	/**
	 * Get remote template title.
	 * Retrieve the remote template title.
	 *
	 * @return string The remote template title.
	 */
	public function get_title() {
		return 'Fox Templates';
	}
	/**
	 * Register remote template data.
	 * Used to register custom template data like a post type, a taxonomy or any
	 * other data.
	 */
	public function register_data() {}
	/**
	 * Get remote templates.
	 * Retrieve remote templates from Elementor.com servers.
	 * @param array $args Optional. Nou used in remote source.
	 * @return array Remote templates.
	 */
	public function get_items( $args = [] ) {
		return [];
	}
	/**
	 * Get remote template.
	 * Retrieve a single remote template from Elementor.com servers.
	 * @param int $template_id The template ID.
	 * @return array Remote template.
	 */
	public function get_item( $template_id ) {
		$templates = $this->get_items();
		return $templates[ $template_id ];
	}

	/**
	 * Get template content.
	 *
	 * Retrieve the templates content received from a remote server.
	 *
	 * @since 1.0.0
	 *
	 * @param int $template_id The template ID.
	 *
	 * @return object|WP_Error The template content.
	 */
	public function get_template_content( $template_id ) {
        $ids = explode( '-', $template_id );
        $blog_id = $ids[0];
        $post_id = $ids[1];
        
        $response = wp_remote_get( 'https://thefox.withemes.com/wp-json/fox-templates/v1/template/' . $blog_id . '/' . $post_id );
        // $response = wp_remote_get( 'http://localhost/fox/wp-json/fox-templates/v1/template/' . $blog_id . '/' . $post_id );
		if ( is_wp_error( $response ) || ! is_array( $response )) {
			return $response;
		}
		$data = json_decode( $response['body'], true );
		if ( isset( $data[ 'error' ] ) ) {
			return new WP_Error( 'no_data', $data[ 'error' ] );
		}
		return $data;
	}
	/**
	 * Get remote template data.
	 * Retrieve the data of a single remote template from Elementor.com servers.
	 * @param array  $args Custom template arguments.
	 * @param string $context Optional. The context. Default is `display`.
	 * @return array|WP_Error Remote Template data.
	 */
	public function get_data( array $args, $context = 'display' ) {
		if ( 'update' === $context ) {
			$data = $args['data'];
		} else {
			$data = $this->get_template_content( $args['template_id'] );
		}

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$data['content'] = $this->replace_elements_ids( $data['content'] );
		$data['content'] = $this->process_export_import_content( $data['content'], 'on_import' );

		$post_id  = $args['editor_post_id'];
		$document = Elementor\Plugin::$instance->documents->get( $post_id );
		if ( $document ) {
			$data['content'] = $document->get_elements_raw_data( $data['content'], true );
		}

		if ( 'update' === $context ) {
			update_post_meta( $post_id, '_elementor_data', $data['content'] );
		}

		return $data;
	}
	/**
	 * Save remote template.
	 * Remote template from Elementor.com servers cannot be saved on the
	 * database as they are retrieved from remote servers.
	 * @param array $template_data Remote template data.
	 * @return WP_Error
	 */
	public function save_item( $template_data ) {
		return new WP_Error( 'invalid_request', 'Cannot save template to a remote source' );
	}
	/**
	 * Update remote template.
	 * Remote template from Elementor.com servers cannot be updated on the
	 * database as they are retrieved from remote servers.
	 * @param array $new_data New template data.
	 * @return WP_Error
	 */
	public function update_item( $new_data ) {
		return new WP_Error( 'invalid_request', 'Cannot update template to a remote source' );
	}
	/**
	 * Delete remote template.
	 * Remote template from Elementor.com servers cannot be deleted from the
	 * database as they are retrieved from remote servers.
	 * @param int $template_id The template ID.
	 * @return WP_Error
	 */
	public function delete_template( $template_id ) {
		return new WP_Error( 'invalid_request', 'Cannot delete template from a remote source' );
	}
	/**
	 * Export remote template.
	 * Remote template from Elementor.com servers cannot be exported from the
	 * database as they are retrieved from remote servers.
	 * @param int $template_id The template ID.
	 * @return WP_Error
	 */
	public function export_template( $template_id ) {
		return new WP_Error( 'invalid_request', 'Cannot export template from a remote source' );
	}
	/**
	* Get import data
	*/
	public function get_init_import_data( $data ) {
		$data = $this->replace_elements_ids( $data );
		$data = $this->process_export_import_content( $data, 'on_import' );
		return $data;
	}
}
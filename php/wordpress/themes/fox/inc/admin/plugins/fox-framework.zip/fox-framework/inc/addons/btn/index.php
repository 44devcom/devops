<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1
 */
class Btn extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_btn';
	}
    
    public function _base() {
        return 'btn';
    }

	public function get_title() {
		return 'FOX Button';
	}
    
    public function get_keywords() {
		return [ 'btn', 'button' ];
	}

	public function get_icon() {
        return 'eicon-button';
	}
    
}
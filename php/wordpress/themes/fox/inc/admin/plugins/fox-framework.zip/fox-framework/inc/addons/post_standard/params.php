<?php

/* query params
----------------------------------- */
$params += foxfw3_query_params();

$params[ 'header_align' ] = array(
    'title' => 'Header text align',
    'type' => 'select',
    'options' => array(
        '' => 'Default',
        'left' => 'Left',
        'center' => 'Center',
        'right' => 'Right',
    ),
    'std' => '',
    
    'section'   => 'general',
    'section_title' => 'General',
);

$params[ 'thumbnail_header_order' ] = array(
    'type' => 'select',
    'std' => 'thumbnail',
    'title' => 'Thumbnail/Header order',
    'options' => [
        'thumbnail' => 'Thumbnail first',
        'header' => 'Header first',
    ],
);

$params[ 'spacing_thumbnail_content' ] = array(
    'type' => 'size',
    'title' => 'Spacing thumbnail - content',
    
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-thumbnail+.post-standard-text-outer,{{WRAPPER}} .post-standard .post-thumbnail+.post-content' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    'std_unit' => 'px',
    'std_size' => 32,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'spacing_header_content' ] = array(
    'type' => 'size',
    'title' => 'Spacing header - content',
    
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-header' => 'margin-bottom:{{SIZE}}{{UNIT}};',
    ],
    'std_unit' => 'px',
    'std_size' => 36,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'item_template' ] = array(
    'title' => 'Elements order',
    'type' => 'select',

    'options' => [
        '1' => 'Title > Meta > Excerpt',
        '2' => 'Meta > Title > Excerpt',
        '3' => 'Title > Excerpt > Meta',

        '4' => 'Category > Title > Meta > Excerpt',
        '5' => 'Category > Title > Excerpt > Meta',
    ],
    'std' => '1',
);

$params[ 'text_color' ] = array(
    'title' => 'Custom Text Color',
    'type' => 'color',
    
    'selectors' => [
        '{{WRAPPER}} .post-standard' => 'color:{{VALUE}};',
    ],
);

$params[ 'sep' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Separator',
);

$params[ 'sep_color' ] = array(
    'type' => 'color',
    'title' => 'Separator color',
    'selectors' => [
        '{{WRAPPER}} .post-sep' => 'border-color:{{VALUE}};',
    ],
);

/* Thumbnail
 * ------------------------ */
$params[ 'show_thumbnail' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show thumbnail',
    
    'section'   => 'thumbnail',
    'section_title' => 'Thumbnail',
);

$params[ 'thumbnail_type' ] = array (
    'title' => 'Thumbnail type',
    'type' => 'select',
    'options' => [
        'advanced' => 'Full slider, video etc',
        'simple' => 'Just simple image thumbnail',
    ],
    'std' => 'simple',
);

$params[ 'thumbnail_caption' ] = array(
    'type'  => 'switcher',
    'title' => 'Thumbnail caption?',
    
    'condition' => [
        'thumbnail_type[value]' => 'simple',
    ]
);

$params[ 'thumbnail_shape' ] = array(
    'type'  => 'select',
    'std'   => 'acute',
    'options' => [
        'acute'     => 'Acute',
        'round'     => 'Round',
        'circle'    => 'Circle',
    ],
    'title' => 'Thumbnail shape',
);

/* Text
 * ------------------------ */
$params[ 'title_heading' ] = [
    'type' => 'heading',
    'title' => 'Excerpt',
    
    'section'   => 'text',
    'section_title' => 'Text',
];

$params[ 'show_title' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show title',
);

$params[ 'title_tag' ] = array(
    'type' => 'select',
    'options' => [
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
    ],
    'std' => 'h2',
    'title' => 'Title tag',
    
    'condition' => [
        'show_title[value]' => 'yes',
    ],
);

/* Excerpt
 * ------------------------ */
$params[ 'excerpt_heading' ] = [
    'type' => 'heading',
    'title' => 'Excerpt',
];

$params[ 'display_excerpt' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display excerpt?',
);

$params[ 'content_excerpt' ] = array(
    'title' => 'Display content/excerpt',
    'type' => 'select',
    'options' => [
        'content' => 'Full Content',
        'excerpt' => 'Excerpt',
    ],
    'std' => 'excerpt',
    
    'condition' => [
        'display_excerpt[value]' => 'yes',
    ],
);

$params[ 'excerpt_length' ] = array(
    'type' => 'text',
    'std' => '22',
    'title' => 'Excerpt length',
    
    'condition' => [
        'display_excerpt[value]' => 'yes',
        'content_excerpt[value]' => 'excerpt',
    ],
);

$params[ 'excerpt_more' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'More Link',
    
    'condition' => [
        'display_excerpt[value]' => 'yes',
        'content_excerpt[value]' => 'excerpt',
    ],
);

$params[ 'excerpt_more_style' ] = array(
    'type' => 'select',
    'options' => [
        'simple' => 'Plain Link',
        'simple-btn' => 'Minimal Link', // simple button
        'btn' => 'Fill Button', // default btn
        'btn-black' => 'Solid Black Button',
        'btn-primary' => 'Primary Button',
    ],
    'std' => 'simple',
    'title' => 'More text style',
    
    'condition' => [
        'excerpt_more[value]' => 'yes',
        'content_excerpt[value]' => 'excerpt',
    ],
);

$params[ 'excerpt_more_text' ] = array(
    'type' => 'text',
    'placeholder' => 'More',
    'title' => 'Custom More Text',
    
    'condition' => [
        'excerpt_more[value]' => 'yes',
        'content_excerpt[value]' => 'excerpt',
    ],
);

/* Date
 * ------------------------ */
$params[ 'date_heading' ] = [
    'type' => 'heading',
    'title' => 'Date',
];

$params[ 'show_date' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show date',
);

/* Category
 * ------------------------ */
$params[ 'category_heading' ] = [
    'type' => 'heading',
    'title' => 'Category',
];

$params[ 'show_category' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show category',
);

/* Author
 * ------------------------ */
$params[ 'author_heading' ] = [
    'type' => 'heading',
    'title' => 'Author',
];

$params[ 'show_author' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show author',
);

$params[ 'show_author_avatar' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show author avatar',
);

/* Others
 * ------------------------ */
$params[ 'others_link_heading' ] = [
    'type' => 'heading',
    'title' => 'Others',
];

$params[ 'show_comment_link' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show comment link',
);

$params[ 'show_view' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show view count',
);

$params[ 'show_reading_time' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show reading time',
);

$params[ 'show_share' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Show share icons',
);

$params[ 'show_related' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Show related posts',
);



/* ----------------------------------------------------------------------
// STYLE
---------------------------------------------------------------------- */

/* title
----------------------------------- */
$params[ 'title_typography' ] = array(
    'type' => 'typography',
    'title' => 'Title typography',
    'selector' => '{{WRAPPER}} .post-standard .post-item-title, {{WRAPPER}} .post-standard .title56',
    
    'section' => 'post_item_style',
    'section_title' => 'Post item style',
    'section_tab' => 'style',
);

$params[ 'title_color' ] = array(
    'type' => 'color',
    'title' => 'Title color',
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-item-title a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-standard .title56 a' => 'color:{{VALUE}};'
    ],
);

$params[ 'title_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Title hover color',
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-item-title a:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-standard .title56 a:hover' => 'color:{{VALUE}};',
    ],
);

/* excerpt
----------------------------------- */
$params[ 'excerpt_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Excerpt',
);

$params[ 'excerpt_typography' ] = array(
    'type' => 'typography',
    'title' => 'Excerpt typography',
    'selector' => '{{WRAPPER}} .post-standard .post-item-excerpt, {{WRAPPER}} .post-standard .excerpt56',
);

$params[ 'excerpt_color' ] = array(
    'type' => 'color',
    'title' => 'Excerpt color',
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-item-excerpt' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-standard .excerpt56' => 'color:{{VALUE}};',
    ],
);

/* meta
----------------------------------- */
$params[ 'meta_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Post meta',
);

$params[ 'meta_typography' ] = array(
    'type' => 'typography',
    'title' => 'Meta typography',
    'selector' => '{{WRAPPER}} .post-standard .post-item-meta, {{WRAPPER}} .post-standard .meta56',
);

$params[ 'meta_color' ] = array(
    'type' => 'color',
    'title' => 'Meta color',
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-item-meta' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-standard .meta56' => 'color:{{VALUE}};',
    ],
);

$params[ 'meta_link_color' ] = array(
    'type' => 'color',
    'title' => 'Meta link color',
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-item-meta a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-standard .meta56 a' => 'color:{{VALUE}};',
    ],
);

$params[ 'meta_link_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Meta link hover color',
    'selectors' => [
        '{{WRAPPER}} .post-standard .post-item-meta a:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-standard .meta56 a:hover' => 'color:{{VALUE}};',
    ],
);

/* standalone categories
----------------------------------- */
$params[ 'standalone_categories_typography' ] = array(
    'type' => 'typography',
    'title' => 'Standalone Category typography',
    'selector' => '{{WRAPPER}} .post-standard .standalone-categories, {{WRAPPER}} .post-standard .meta56__category--fancy',
);

/* readmore button
----------------------------------- */


/* pagination params
----------------------------------- */
$params += foxfw3_pagination_params();
<?php
$params[ 'align' ] = array(
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'left',
    'title' => 'Alignment',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'disable_on_author_page' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Disable on author page',
);

$params[ 'typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-archive-description',
    'title' => 'Typography',
);

$params[ 'color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-archive-description' => 'color:{{VALUE}};',
    ],
    'title' => 'Color',
);
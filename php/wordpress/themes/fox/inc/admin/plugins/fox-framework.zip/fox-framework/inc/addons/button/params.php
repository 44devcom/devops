<?php
$params = function_exists( 'fox_btn_params' ) ? fox_btn_params() : [];
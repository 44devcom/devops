<?php
$params = foxfw3_query_params();
$params += foxfw3_generate_options([
    'base' => 'standard',
    'context' => 'elementor',

    'override' => [
        'thumbnail_type' => [
            'std' => 'simple',
        ]
    ],

    'section' => 'layout',
    'section_title' => 'Layout',
]);
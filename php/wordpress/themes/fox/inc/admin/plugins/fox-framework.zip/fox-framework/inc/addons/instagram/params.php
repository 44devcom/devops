<?php
$params[ 'shortcode' ] = array(
    'type' => 'textarea',
    'title' => 'Instagram Shortcode',
    'std' => '[instagram-feed feed=1]',
    'desc' => 'something like: [instagram-feed feed=1]',

    'section' => 'shortcode',
    'section_title' => 'Instagram Shortcode',
);
<?php
$params[ 'share_icons' ] = [
    'type' => 'textarea',
    'title' => 'Share icons',
    'std' => 'facebook, twitter, pinterest, linkedin, whatsapp, reddit, email',
    'desc' => 'Available icons: facebook, messenger, twitter, pinterest, linkedin, whatsapp, reddit, email',
    
    'section' => 'general',
    'section_title' => 'General',
];

$params[ 'align' ] = [
    'type' => 'align',
    'title' => 'Alignment',
    'std' => 'center',
    'options' => [ 'left', 'center', 'right' ],
];

$params[ 'spacing' ] = array(
    'type' => 'size',
    'title' => 'Icon spacing',
    
    'std_size' => 8,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 30,
    
    'selectors' => array(
        '{{WRAPPER}} .el-share ul li + li' => 'margin-left:{{SIZE}}{{UNIT}};'
    )
);

$params[ 'size' ] = array(
    'type' => 'size',
    'title' => 'Icon size',
    
    'std_size' => 18,
    'std_unit' => 'px',
    'px_min' => 6,
    'px_max' => 50,
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'font-size:{{SIZE}}{{UNIT}};'
    )
);

$params[ 'container_size' ] = array(
    'type' => 'size',
    'title' => 'Icon container size',
    
    'std_size' => 32,
    'std_unit' => 'px',
    'px_min' => 10,
    'px_max' => 100,
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}};'
    )
);

$params[ 'border_width' ] = array(
    'type' => 'size',
    'title' => 'Icon border width',
    
    'std_size' => 0,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 8,
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'border-width:{{SIZE}}{{UNIT}};',
    )
);

$params[ 'border_radius' ] = array(
    'type' => 'size',
    'title' => 'Icon border radius',
    
    'std_size' => 50,
    'std_unit' => '%',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'border-radius:{{SIZE}}{{UNIT}};',
    )
);

$params[ 'icon_color' ] = array(
    'type' => 'color',
    'title' => 'Icon text color',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'color:{{VALUE}};'
    ),
    
    'tabs' => 'icon_style',
    'tab' => 'normal',
    'tab_title' => 'Normal',
);

$params[ 'icon_background' ] = array(
    'type' => 'color',
    'title' => 'Icon background color',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'background-color:{{VALUE}};'
    )
);

$params[ 'icon_border_color' ] = array(
    'type' => 'color',
    'title' => 'Icon border color',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a' => 'border-color:{{VALUE}};'
    ),
);

$params[] = [
    'type' => 'tab_close',
];

$params[ 'icon_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Icon text color',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a:hover' => 'color:{{VALUE}};'
    ),
    
    'tab' => 'hover',
    'tab_title' => 'Hover',
);

$params[ 'icon_hover_background' ] = array(
    'type' => 'color',
    'title' => 'Icon background color',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a:hover' => 'background-color:{{VALUE}};'
    )
);

$params[ 'icon_hover_border_color' ] = array(
    'type' => 'color',
    'title' => 'Icon border color',
    
    'selectors' => array(
        '{{WRAPPER}} .el-share a:hover' => 'border-color:{{VALUE}};'
    ),
);

$params[] = [
    'type' => 'tab_close',
];

$params[] = [
    'type' => 'tabs_close',
];
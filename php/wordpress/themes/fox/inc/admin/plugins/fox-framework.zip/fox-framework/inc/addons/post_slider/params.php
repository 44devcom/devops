<?php
$params = foxfw3_query_params( [ 'pagination' ] );

$params[ 'slider_size' ] = [
    'type' => 'text',
    'std' => '1080x540',
    'title' => 'Slider Size (Eg. 1080x540)',

    'section' => 'layout',
    'section_title' => 'Layout',
];

$params[ 'nav_style' ] = [
    'type' => 'select',
    'std' => 'text',
    'title' => 'Nav Arrow Style',
    'options' => [
        'text' => 'Text',
        'arrow' => 'Arrow',
    ],
];

$params[ 'slider_effect' ] = [
    'type' => 'select',
    'std' => 'slide',
    'title' => 'Slider Effect',
    'options' => [
        'slide' => 'Slide',
        'fade' => 'Fade',
    ],
];

$params[ 'slider_autoplay' ] = [
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Autoplay',
];

$params[ 'item_align' ] = array(
    'title' => 'Text Alignment',
    'type' => 'select',
    'options' => array(
        'left' => 'Left',
        'center' => 'Center',
        'right' => 'Right',
    ),
    'std' => 'left',
);

/* Title
 * ------------------------ */
$params[ 'placeholder_heading_title' ] = [
    'type' => 'heading',
    'title' => 'Title',
];

$params[ 'show_title' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show title',
);

$params[ 'title_background' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Bckground for title?',
);

$params[ 'title_tag' ] = array(
    'type' => 'select',
    'options' => [
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
    ],
    'std' => 'h2',
    'title' => 'Title tag',
);

$params[ 'title_size' ] = array(
    'type'  => 'select',
    'std'   => 'large',
    'options' => [
        'tiny' => 'Tiny',
        'small' => 'Small',
        'normal' => 'Normal',
        'medium' => 'Medium',
        'large' => 'Large',
    ],
    'title' => 'Title size',
);

$params[ 'title_weight' ] = array(
    'type'  => 'select',
    'std'   => '',
    'options' => [
        '' => 'Default',
        '300' => 'Light',
        '400' => 'Normal',
        '700' => 'Bold',
    ],
    'title' => 'Title weight',
);

$params[ 'title_text_transform' ] = array(
    'type'  => 'select',
    'std'   => '',
    'options' => [
        '' => 'Default',
        'none' => 'None',
        'lowercase' => 'lowercase',
        'uppercase' => 'UPPERCASE',
        'capitalize' => 'Capitalize',
    ],
    'title' => 'Title text transform',
);

/* Excerpt
 * ------------------------ */
$params[ 'placeholder_heading_excerpt' ] = [
    'type' => 'heading',
    'title' => 'Excerpt',
];

$params[ 'show_excerpt' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display excerpt?',
);

$params[ 'excerpt_length' ] = array(
    'type' => 'text',
    'std' => '22',
    'title' => 'Excerpt length',
);

$params[ 'excerpt_more' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'More Link',
);

/* Other elements
 * ------------------------ */
$params[ 'placeholder_heading_elements' ] = [
    'type' => 'heading',
    'title' => 'Other elements',
];

$params[ 'show_date' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show post date',
);

$params[ 'show_category' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show post categories',
);

$params[ 'show_author' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show post author',
);

$params[ 'show_view' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show view count',
);

$params[ 'show_comment_link' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show comment link',
);

$params[ 'show_reading_time' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show reading time',
);
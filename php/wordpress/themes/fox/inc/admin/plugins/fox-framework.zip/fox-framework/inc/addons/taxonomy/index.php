<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Taxonomy extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_taxonomy';
	}
    
    public function _base() {
        return 'taxonomy';
    }

	public function get_title() {
		return 'FOX - Tags / Taxonomy';
	}
    
    public function get_keywords() {
		return [ 'post tags', 'tags', 'categories', 'taxonomy', 'custom taxonomy' ];
	}

	public function get_icon() {
        return 'eicon-tags';
	}
    
    public function get_categories() {
        return [ 'fox' ];
	}
    
}
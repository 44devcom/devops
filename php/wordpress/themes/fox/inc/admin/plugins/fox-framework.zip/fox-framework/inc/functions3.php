<?php
/* USER
------------------------------------------------------------------------ */
if ( ! function_exists( 'foxfw3_user' ) ) :
    function foxfw3_user( $args = [] ) {
        
        extract( wp_parse_args( $args, [
            
            'user' => null,
            
            'avatar' => true,
            'avatar_shape' => 'circle',
            
            'name' => true,
            'post_count' => true,
            'description' => true,
            
            'social' => true,
            'social_style' => 'plain',
            
            'extra_class' => '',
            'after_body' => '',
            'after_desc' => '',
            
            'author_page' => false,
            'name_tag' => 'h3',
            
        ] ) );
        
        // in case no user set
        if ( ! $user ) {
            if ( is_single() ) {
                $user = get_userdata( get_the_author_meta( 'ID' ) );
            } elseif ( is_author() ) {
                
                $user_id = get_the_author_meta( 'ID' );
                global $coauthors_plus;
                if ( $coauthors_plus ) {
                    $user = $coauthors_plus->get_coauthor_by( 'id', $user_id );
                } else {
                    $user = get_userdata( $user_id );
                }
                
            }
        }
        
        if ( ! is_object( $user ) ) return;
        
        $link = get_author_posts_url( $user->ID, $user->user_nicename );
        
        $class = [
            'fox-user-item',
            'fox-author',
            'fox-user',
        ];
        
        if ( $extra_class ) $class[] = $extra_class;
        ?>
        <div class="<?php echo esc_attr( join( ' ', $class ) ); ?>">
    
            <?php if ( $avatar ) { ?>
    
            <div class="user-item-avatar avatar-<?php echo esc_attr( $avatar_shape ); ?>">
    
                <a href="<?php echo $link; ?>">
    
                    <?php echo get_avatar( $user->ID, 300 ); ?>
    
                </a>
    
            </div><!-- .user-item-avatar -->
    
            <?php } ?>
    
            <div class="user-item-body">
    
                <?php if ( $name ) { ?>
    
                <div class="user-item-header">
    
                    <div class="user-item-name-wrapper">
                        
                        <?php if ( ! $author_page ) { ?>
                        <h3 class="user-item-name">
    
                            <a href="<?php echo $link; ?>"><?php echo $user->display_name; ?></a>
    
                        </h3>
                        <?php } else { ?>
                        
                        <h1 class="user-item-name"><?php echo $user->display_name; ?></h1>
                        
                        <?php } ?>
                        
                    </div><!-- .user-item-name-wrapper -->
    
                </div><!-- .user-item-header -->
    
                <?php } ?>
    
                <?php if ( $description && $user->description ) { ?>
    
                <div class="user-item-description">
    
                    <?php echo wpautop( do_shortcode( $user->description ) ); ?>
    
                </div><!-- .user-item-description -->
    
                <?php } ?>
                
                <?php if ( $social ) { ?>
    
                <?php foxfw3_user_social([ 'user' => $user->ID, 'style' => $social_style, 'extra_class' => 'user-item-name-meta' ] ); ?>
    
                <?php } ?>
                
                <?php if ( $after_desc ) { echo $after_desc; } ?>
    
            </div><!-- .user-item-body -->
            
            <?php if ( $after_body ) { echo $after_body; } ?>
    
        </div><!-- .fox-user-item -->
    
        <?php
    
    }
endif;

function foxfw3_user_social( $args = [] ) {

    extract( wp_parse_args( $args, [
        
        'user' => null,
        'style' => 'plain',
        'extra_class' => '',
        
    ] ) );
    
    if ( ! in_array( $style, [ 'plain', 'black', 'outline', 'fill', 'color' ] ) ) {
        $style = 'plain';
    }
    
    // in case no user set
    if ( ! $user ) {
        if ( is_single() ) {
            $user = get_the_author_meta( 'ID' );
        } elseif ( is_author() ) {
            global $author;
            $userdata = get_userdata( $author );
            $user = $userdata->ID;
        }
    }
    
    $class = [
        'social-list',
        'user-item-social',
        'shape-circle',
        
        'style-' . $style,
    ];
    if ( $extra_class ) {
        $class[] = $extra_class;
    }
    
    $legacy = [
        'facebook' => 'facebook-square',
        'pinterest' => 'pinterest-p',
        'vimeo' => 'vimeo-square',
        'vkontakte' => 'vk',
    ];
    
    $social_arr = foxfw3_social_data();
    
    ?>

<div class="<?php echo esc_attr( join( ' ', $class ) ); ?>">
    
    <ul>
    
        <?php foreach ( foxfw3_user_social_support() as $brand ) : $url = get_user_meta( $user, $brand, true ); 

        // legacy, try to get value from old key
        if ( ! $url ) {
            if ( isset( $legacy[ $brand ] ) ) {
                $url = get_user_meta( $user, $legacy[ $brand ], true );
            }
        }
        if ( ! $url ) continue;
    
        // this icon not supported
        if ( ! isset( $social_arr[ $brand ] ) ) {
            continue;
        }

            $title = $social_arr[ $brand ][ 'title' ];
            $icon = $social_arr[ $brand ][ 'icon' ];

        if ( 'facebook' == $brand ) {
            $icon = 'facebook-square'; // legacy
        }
            
        ?>

        <li class="li-<?php echo esc_attr( $brand ); ?>">
            <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener" title="<?php echo esc_attr( $title ); ?>">
                <i class="fab fa-<?php echo $icon; ?>"></i>
            </a>
        </li>

        <?php endforeach; ?>
        
        <?php $userdata = get_userdata( $user ); $url = isset( $userdata->user_url ) ? $userdata->user_url : ''; if ( $url ) { ?>
        
        <li class="li-website">
            <a href="<?php echo esc_url( $url ); ?>" target="_blank" title="<?php echo esc_html__( 'Website', 'wi' ); ?>">
                <i class="fa fa-link"></i>
            </a>
        </li>
        
        <?php } ?>
        
    </ul>
    
</div><!-- .user-item-social -->

<?php

}

function foxfw3_social_data() {
    $dt = [
        'facebook' => [ 'title' => 'Facebook', 'icon' => 'facebook-square' ],
        'twitter' => [ 'title' => 'Twitter', 'icon' => 'twitter' ],
        'instagram' => [ 'title' => 'Instagram', 'icon' => 'instagram' ],
        'pinterest' => [ 'title' => 'Pinterest', 'icon' => 'pinterest-p' ],
        'linkedin' => [ 'title' => 'LinkedIn', 'icon' => 'linkedin-in' ],
        'youtube' => [ 'title' => 'YouTube', 'icon' => 'youtube' ],
        'snapchat' => [ 'title' => 'Snapchat', 'icon' => 'snapchat-ghost' ],
        'tiktok' => [ 'title' => 'Tiktok', 'icon' => 'tiktok' ],
        'medium' => [ 'title' => 'Medium', 'icon' => 'medium-m' ],
        'reddit' => [ 'title' => 'Reddit', 'icon' => 'reddit-alien' ],
        'whatsapp' => [ 'title' => 'WhatsApp', 'icon' => 'whatsapp' ],
        'soundcloud' => [ 'title' => 'SoundCloud', 'icon' => 'soundcloud' ],
        'spotify' => [ 'title' => 'Spotify', 'icon' => 'spotify' ],
        'tumblr' => [ 'title' => 'Tumblr', 'icon' => 'tumblr' ],
        'yelp' => [ 'title' => 'Yelp', 'icon' => 'yelp' ],
        'vimeo' => [ 'title' => 'Vimeo', 'icon' => 'vimeo-v' ],
        'telegram' => [ 'title' => 'Telegram', 'icon' => 'telegram' ],
        'vkontakte' => [ 'title' => 'VKontakte', 'icon' => 'vk' ],
        'google-play' => [ 'title' => 'Google Play', 'icon' => 'google-play' ],
        'twitch-tv' => [ 'title' => 'Twitch', 'icon' => 'twitch' ],
        'tripadvisor' => [ 'title' => 'TripAdvisor', 'icon' => 'tripadvisor' ],
        'behance' => [ 'title' => 'Behance', 'icon' => 'behance' ],
        'bitbucket' => [ 'title' => 'Bitbucket', 'icon' => 'bitbucket' ],
        'delicious' => [ 'title' => 'Delicious', 'icon' => 'delicious' ],
        'deviantart' => [ 'title' => 'DeviantArt', 'icon' => 'deviantart' ],
        'digg' => [ 'title' => 'Digg', 'icon' => 'digg' ],
        'dribbble' => [ 'title' => 'Dribbble', 'icon' => 'dribbble' ],
        'dropbox' => [ 'title' => 'Dropbox', 'icon' => 'dropbox' ],
        'etsy' => [ 'title' => 'Etsy', 'icon' => 'etsy' ],
        'flickr' => [ 'title' => 'Flickr', 'icon' => 'flickr' ],
        'foursquare' => [ 'title' => 'Foursquare', 'icon' => 'foursquare' ],
        'github' => [ 'title' => 'GitHub', 'icon' => 'github' ],
        'imdb' => [ 'title' => 'IMDb', 'icon' => 'imdb' ],
        'lastfm' => [ 'title' => 'LastFM', 'icon' => 'lastfm' ],
        'meetup' => [ 'title' => 'Meetup', 'icon' => 'meetup' ],
        'paypal' => [ 'title' => 'PayPal', 'icon' => 'paypal' ],
        'quora' => [ 'title' => 'Quora', 'icon' => 'quora' ],
        'rss-2' => [ 'title' => 'RSS', 'icon' => 'rss' ],
        'scribd' => [ 'title' => 'Scribd', 'icon' => 'scribd' ],
        'skype' => [ 'title' => 'Skype', 'icon' => 'skype' ],
        'slack' => [ 'title' => 'Slack', 'icon' => 'slack' ],
        'slideshare' => [ 'title' => 'SlideShare', 'icon' => 'slideshare' ],
        'stack-exchange' => [ 'title' => 'Stack Exchange', 'icon' => 'stack-exchange' ],
        'stackoverflow' => [ 'title' => 'Stack Overflow', 'icon' => 'stack-overflow' ],
        'steam' => [ 'title' => 'Steam', 'icon' => 'steam' ],
        'wordpress' => [ 'title' => 'WordPress', 'icon' => 'wordpress' ],
        'wordpress-com' => [ 'title' => 'WordPress.com', 'icon' => 'wordpress' ],
        'yahoo' => [ 'title' => 'Yahoo!', 'icon' => 'yahoo' ],
        'stumbleupon' => [ 'title' => 'StumbleUpon', 'icon' => 'stumbleupon' ],
        'amazon' => [ 'title' => 'Amazon', 'icon' => 'amazon' ],
        'vine' => [ 'title' => 'Vine', 'icon' => 'vine' ],
        '500px' => [ 'title' => '500px', 'icon' => '500px' ],
        'vero' => [ 'title' => 'Vero', 'icon' => 'vero' ],
        'weibo' => [ 'title' => 'Weibo', 'icon' => 'weibo' ],
    ];
    
    return apply_filters( 'fox_social_data', $dt );
}

if ( ! function_exists( 'foxfw3_user_social_support' ) ) :
    function foxfw3_user_social_support() {
        
        return [
            'facebook',
            'youtube',
            'twitter',
            'instagram',
            'tiktok',
            'pinterest',
            'linkedin',
            'tumblr',
            'snapchat',
            'vimeo',
            'soundcloud',
            'flickr',
            'vkontakte',
            'spotify',
            'reddit',
            'whatsapp',
            'wechat',
            'weibo',
            'telegram',
        ];
        
    }
endif;

/* SHARE
------------------------------------------------------------------------ */
if ( ! function_exists( 'foxfw3_share_icon_list' ) ) :
    function foxfw3_share_icon_list( $args = [] ) {
        extract( wp_parse_args( $args, [
            'share_icons' => [],
            'url' => '',
            'via' => '',
            'title' => '',
            'image' => '',
        ]));
        ?>
        <ul>
            
            <?php foreach ( $share_icons as $icon ) :
        
                $href = '#';
        
                if ( 'facebook' == $icon ) {
                    
                    $href = 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode( $url );
                    if ( $image ) {
                        $href .= '&amp;p[images][0]=' . urlencode( $image );
                    }
                    
                } elseif ( 'twitter' == $icon ) {
                    
                    $href = 'https://twitter.com/intent/tweet?url=' . urlencode($url) .'&amp;text=' . urlencode( html_entity_decode( $title ) );
                    
                    if ( $via ) {
                        $href .= '&amp;via=' . urlencode( $via );
                    }
                    
                } elseif ( 'pinterest' == $icon ) {
                    
                    $href = 'https://pinterest.com/pin/create/button/?url=' . urlencode($url) . '&amp;description=' . urlencode( html_entity_decode( $title ) );
                    if ( $image ) {
                        $href .= '&amp;media=' . urlencode($image);
                    }
                    
                } elseif ( 'linkedin' == $icon ) {
                    
                    $href = 'https://www.linkedin.com/shareArticle?mini=true&url=' . urlencode( $url ) . '&amp;title=' . urlencode( html_entity_decode( $title ) );
                
                } elseif ( 'whatsapp' == $icon ) {
                
                    $href = 'https://api.whatsapp.com/send?phone=&text=' . urlencode( $url );
                    
                } elseif ( 'reddit' == $icon ) {
                
                    $href = 'https://www.reddit.com/submit?url=' . urlencode( $url ) . '&title=' . urlencode( html_entity_decode( $title ) );
                
                } elseif ( 'email' == $icon ) {
                
                    $href = 'mailto:?subject=' . rawurlencode( html_entity_decode( $title ) )  . '&amp;body=' . rawurlencode($url);
                
                } else {
                    continue;
                }
        
                $icon_map = [
                    'facebook' => 'fab fa-facebook-f',
                    'messenger' => 'fab fa-facebook-messenger',
                    'twitter'   => 'fab fa-twitter',
                    'pinterest' => 'fab fa-pinterest-p',
                    'linkedin' => 'fab fa-linkedin-in',
                    'whatsapp' => 'fab fa-whatsapp',
                    'reddit'   => 'fab fa-reddit-alien',
                    'email' => 'fa fa-envelope',
                ];
        
                if ( 'email' == $icon ) {
                    $a_class = 'email-share';
                } else {
                    $a_class = 'share share-' . $icon;
                }
                $ic = $icon_map[ $icon ];
                $li_class = 'li-share-' . $icon;
                $label = ucfirst( $icon );
                ?>
            
            <li class="<?php echo esc_attr( $li_class ); ?>">
                
                <a href="<?php echo esc_url( $href ); ?>" title="<?php echo esc_attr( $label ); ?>" class="<?php echo esc_attr( $a_class ); ?>">
                    
                    <i class="<?php echo esc_attr( $ic ); ?>"></i>
                    <span><?php echo esc_html( $label ); ?></span>
                    
                </a>
                
            </li>
            
            <?php endforeach; ?>
            
        </ul>
        <?php
    }
endif;

/* THUMBNAIL
------------------------------------------------------------------------ */
function foxfw3_elementor_thumbnail( $settings ) {
    
    $settings = wp_parse_args( $settings, [
        
        'thumbnail_type' => 'simple',
        
        'thumbnail_shape' => 'acute',
        'thumbnail_extra_class' => '',
        
        'thumbnail' => 'landscape',
        'thumbnail_custom' => '',
        'thumbnail_placeholder' => '',
        'thumbnail_placeholder_id' => '',
        'thumbnail_hover_effect' => '',
        'thumbnail_hover_logo' => '',
        
        'thumbnail_showing_effect' => '',
        
        'format_indicator' => '',
        'thumbnail_view' => '',
        'thumbnail_index' => '',
        'thumbnail_review_score' => '',
        
        'count' => '',
        
        'thumbnail_extra_css' => '',
        
        // since 4.6.7
        'thumbnail_caption' => '',
        
    ]);
    
    /**
     * post format video problem
     * @since FOX Framework 1.8
     */
    $youtube_id = null;
    if ( 'video' == get_post_format() ) {
        $video_code = get_post_meta( get_the_ID(), '_format_video_embed', true );
        $self_hosted_video_code = trim( get_post_meta( get_the_ID(), '_format_video', true ) );
        if ( ! $self_hosted_video_code ) {
            if ( strpos( $video_code, 'youtube.com' ) !== false || strpos( $video_code, 'youtu.be' ) !== false ) {
                
                // first, we convert things into iframe
                // if it's an iframe already
                if ( strpos( $video_code, 'iframe' ) !== false ) {
                    
                    if ( preg_match('/src="([^"]+)"/', $iframe, $match) ) {
                        $url = $match[1];
                    }
                    
                } else {
                    
                    $url = $video_code;
                    
                }
                
                // https://gist.github.com/ghalusa/6c7f3a00fd2383e5ef33
                if ( preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match2 ) );
                $youtube_id = $match2[1];
                
                
            }
        }
        
    } 
    
    $class = [
        
        'wi-thumbnail',
        'fox-thumbnail',
        'post-item-thumbnail',
        'fox-figure',
        
    ];
    
    $data_youtube_id = '';
    if ( $youtube_id && isset( $settings[ 'thumbnail_youtube_player' ] ) && 'yes' == $settings[ 'thumbnail_youtube_player' ] ) {
        $class[] = 'thumbnail-youtube-player';
        $data_youtube_id = ' data-youtubeid="' . esc_attr( $youtube_id ) . '"';
        
        /**
         * IMPORTANT - for youtube posts, we force thumbnail ratio to be 16:9
         */
        $settings[ 'thumbnail' ] = 'custom';
        $settings[ 'thumbnail_custom' ] = '1280x720';
        
        // disable thumbnail link
        $settings[ 'thumbnail_link' ] = false;
    }
    
    /**
     * @since 4.4.1
     */
    $settings = apply_filters( 'fox_thumbnail_final_params', $settings );
    
    $extra_class = '';
    if ( isset( $settings['thumbnail_extra_class'] ) ) {
        $extra_class = $settings['thumbnail_extra_class'];
    }
    if ( $extra_class ) {
        $class[] = $extra_class;
    }
    
    if ( isset( $settings[ 'thumbnail_type'] ) && 'advanced' == $settings[ 'thumbnail_type'] ) {
        
        foxfw3_advanced_thumbnail([ 'extra_class' => $extra_class ]);
        return;
        
    }
    
    
    
    if ( $settings[ 'thumbnail_review_score' ] ) {
        $settings[ 'thumbnail_index' ] = false;
    }
    
    /**
     * shape
     */
    $shape = $settings[ 'thumbnail_shape' ];
    if ( 'circle' != $shape && 'round' != $shape ) {
        $shape = 'acute';
    }
    $class[] = 'thumbnail-' . $shape;
    
    /**
     * thumbnail
     */
    $name_to_size_adapter = [
        'landscape' => 'thumbnail-medium',
        'square' => 'thumbnail-square',
        'portrait' => 'thumbnail-portrait',
        'original' => 'large',
        'original_fixed' => 'large',
    ];
    $size = '';
    $thumbnail = $settings[ 'thumbnail' ];
    if ( isset( $name_to_size_adapter[ $thumbnail ] ) ) {
        $size = $name_to_size_adapter[ $thumbnail ];
    } else {
        $size = $thumbnail;
    }
    
    /**
     * custom size
     */
    $height_element = '';
    if ( 'custom' == $thumbnail ) {
        
        $thumbnail_custom = $settings[ 'thumbnail_custom' ];
        
        $size = '';
        $thumbnail_custom = strtolower( $thumbnail_custom );
        $explode = explode( 'x', $thumbnail_custom );
        if ( count( $explode ) < 2 ) $explode = explode( ':', $thumbnail_custom ); // another attempt
        if ( count( $explode ) < 2 ) $explode = [ 600, 600 ]; // just a random default number

        $w = absint( $explode[0] ); $h = absint( $explode[1] );
        if ( $w < 1 || $h < 1 ) $w = $h = 600; // default fallback value

        $padding = $h/$w * 100;
        if ( $padding < 10 || $padding > 1000 ) $padding = 100; // in case wrong value

        if ( $w < 120 ) {
            if ( $h < 150 ) {
                $size = 'thumbnail';
            } else {
                $size = 'medium';
            }
        } elseif ( $w < 300 ) {
            $size = 'medium';
        } elseif ( $w < 440 ) {
            if ( $h < 380 ) {
                $size = 'thumbnail-medium';
            } elseif ( $h < 440 ) {
                $size = 'thumbnail-square';
            } else {
                $size = 'thumbnail-portrait';
            }
        } elseif ( $w < 720 ) {
            if ( $h < 440 ) {
                $size = 'thumbnail-large';
            } else {
                $size = 'large';
            }
        } elseif ( $w < 900 ) {
            $size = 'large';
        } else {
            $size = 'full';
        }
        
        $class[] = 'custom-thumbnail thumbnail-custom';
        $height_element = '<span class="height-element" style="padding-bottom:' . $padding . '%;"></span>';
        
    }
    
    /**
     * original fixed
     */
    if ( 'original_fixed' == $thumbnail ) {
        $padding = 100;
        $class[] = 'custom-thumbnail thumbnail-custom custom-thumbnail-contain';
        $height_element = '<span class="height-element" style="padding-bottom:' . $padding . '%;"></span>';
    }
    
    $img_html = '';
    /**
     * get the img_html
     */
    
    // first attempt: custom blog thumbnail
    $custom_blog_thumbnail_id = get_post_meta( get_the_ID(), '_wi_blog_thumbnail', true );
    if ( $custom_blog_thumbnail_id ) {
        $img_html = wp_get_attachment_image( $custom_blog_thumbnail_id, $size );
    }
    
    // second attempt: the post thumbnail
    if ( ! $img_html && has_post_thumbnail() ) {
        $img_html = wp_get_attachment_image( get_post_thumbnail_id(), $size );
    }
    
    if ( ! $img_html ) {
        // third attempt: attachments attached to the post
        $attachments = get_posts( array(
            'post_type' => 'attachment',
            'posts_per_page' => 1,
            'post_parent' => get_the_ID(),
            'post_status' => 'publish',
            'now_found_row' => true,
        ) );
        if ( ! empty( $attachments ) ) {
            $img_html = wp_get_attachment_image( $attachments[0]->ID, $size );
        }
    }
    
    // forth attempt: in case we use placeholder
    if ( ! $img_html && $settings[ 'thumbnail_placeholder' ] ) {
        
        $thumbnail_placeholder_img_html = '';
        $thumbnail_placeholder_id = isset( $settings[ 'thumbnail_placeholder_id' ] ) ? $settings[ 'thumbnail_placeholder_id' ] : null;
        if ( $thumbnail_placeholder_id ) {
            if ( ! is_numeric( $thumbnail_placeholder_id ) ) {
                $get_id = attachment_url_to_postid( $thumbnail_placeholder_id );
                if ( $get_id ) {
                    $thumbnail_placeholder_img_html = wp_get_attachment_image( $get_id, $size );
                } else {
                    $thumbnail_placeholder_img_html = '<img src="' . esc_url( $thumbnail_placeholder_id ) . '" alt="Placeholder Photo" />';
                }
            } else {
                $thumbnail_placeholder_img_html = wp_get_attachment_image( $thumbnail_placeholder_id, $size );
            }
            
        }
        if ( ! $thumbnail_placeholder_img_html ) {
            $thumbnail_placeholder_img_html = '<img src="' . get_template_directory_uri() . '/images/placeholder.jpg' . '" alt="Placeholder Photo" />';
        }
        
        $img_html = $thumbnail_placeholder_img_html;
        
    }
    
    // no image found, render nothing
    if ( ! $img_html ) return;
    
    // @todo, get width, height by WP function
    $array = array();
    // $img_html = str_replace( 'width', 'foo', $img_html );
    preg_match( '/width="([^"]*)"/i', $img_html, $array ) ;
    $w = isset( $array[1] ) ? $array[1] : 0;
    preg_match( '/height="([^"]*)"/i', $img_html, $array ) ;
    $h = isset( $array[1] ) ? $array[1] : 0;
    $w = absint( $w ) + 1;
    $h = absint( $h ) + 1;
    
    if ( ( $w / $h ) > 0.9 ) {
        $class[] = 'ratio-landscape';
    } else {
        $class[] = 'ratio-portrait';
    }
    
    /**
     * hover effect
     */
    $hover_markup = '';
    $hover_effect = $settings[ 'thumbnail_hover_effect' ];
    if ( ! in_array( $hover_effect, [ 'fade', 'dark', 'grayscale', 'sepia', 'letter', 'zoomin', 'logo' ] ) ) {
        $hover_effect = 'none';
    }
    $class[] = 'hover-' . $hover_effect;
    
    if ( 'dark' == $hover_effect || 'letter' == $hover_effect || 'logo' == $hover_effect ) {
        $class[] = ' hover-dark';
        $hover_markup .= '<span class="image-overlay"></span>';
    }
    if ( 'letter' == $hover_effect ) {
        
        $title = strip_tags( get_the_title() );
        $letter = substr( $title, 0, 1 );

        if ( '' != $letter ) {
            $hover_markup .= '<span class="image-letter font-heading"><span class="main-letter">' . $letter . '</span><span class="l-cross l-left"></span><span class="l-cross l-right"></span></span>';
        }

    } elseif ( 'logo' == $hover_effect ) {
        
        $logo = $settings[ 'thumbnail_hover_logo' ]; // logo ID
        $logo_html = '';
        
        if ( ! empty( $logo[ 'id' ] ) ) {
            ob_start();
            \Elementor\Group_Control_Image_Size::print_attachment_image_html([ 'image' => $logo, 'image_size' => $settings[ 'thumbnail_hover_logo_size' ] ]);
            
            $logo_html = ob_get_clean();
        }
        
        if ( $logo_html ) {
            $hover_markup .= '<span class="image-logo">' . $logo_html . '</span>';
        }

    }
    
    /**
     * Thumbnail Showing Effect
     * @since 4.3
     */
    $showing_effect = $settings[ 'thumbnail_showing_effect' ];
    if ( in_array( $showing_effect, [ 'fade', 'slide', 'popup', 'zoomin' ] ) ) {
        $class[] = 'thumbnail-loading';
        $class[] = 'effect-' . $showing_effect;
    }
    
    $css = [];
    
    /**
     * thumbnail width
     *
    $thumbnail_width = isset( $settings[ 'thumbnail_width' ] ) ? trim( $settings[ 'thumbnail_width' ] ) : null;
    if ( $thumbnail_width ) {
        if ( is_numeric( $thumbnail_width ) ) $thumbnail_width .= 'px';
        if ( $thumbnail_width ) {
            $settings[ 'thumbnail_extra_css' ] = 'width:' . $thumbnail_width;
        }
    }
    */
    
    /**
     * extra CSS
     */
    $extra_css = isset( $settings[ 'thumbnail_extra_css' ] ) ? $settings[ 'thumbnail_extra_css' ] : '';
    if ( ! empty( $extra_css ) ) {
        if ( is_array( $extra_css ) ) $css = $extra_css;
        else $css[] = $extra_css;
    }
    $css = join( ';', $css );
    if ( ! empty( $css ) ) {
        $css = ' style="' . esc_attr( $css ) . '"';
    }
    
    /**
     * $target_attr
     * since 4.7.3
     */
    $target_attr = '';
    if ( 'link' == get_post_format() ) {
        
        $target = get_post_meta( get_the_ID(), '_format_link_target', true );
        if ( ! $target ) {
            $target = get_theme_mod( 'wi_single_format_link_target', '_self' );
        }
        
        if ( '_blank' == $target ) {
            $target_attr = ' target="' . esc_attr( $target ) . '"';
        }
        
    }
    
    ?>
    
<figure class="<?php echo esc_attr( join( ' ', $class ) ); ?>" itemscope itemtype="https://schema.org/ImageObject"<?php echo $css; ?><?php echo $data_youtube_id; ?>>
    
    <div class="thumbnail-inner">
    
        <?php if ( ! isset( $settings[ 'thumbnail_link' ] ) || $settings[ 'thumbnail_link' ] ) { ?>
        
        <a href="<?php echo foxfw3_permalink(); ?>" class="post-link"<?php echo $target_attr; ?>>
            
        <?php } ?>

            <span class="image-element">

                <?php echo $img_html . $height_element; ?>

            </span><!-- .image-element -->

            <?php echo $hover_markup; ?>

            <?php /* other HTML stuffs inside thumbnail */ 
            if ( $settings[ 'thumbnail_index' ] ) {
                echo '<span class="thumbnail-index">' . sprintf( '%02d' , $settings[ 'count' ] ) . '</span>';
            }

            if ( $settings[ 'format_indicator' ] ) {
                echo foxfw3_format_indicator();
            }

            if ( 'yes' == $settings[ 'thumbnail_view' ] ) {
                $viewcount = foxfw3_get_view();
                if ( $viewcount > 0 ) {
                    echo '<span class="thumbnail-view">' . sprintf( foxfw3_word( 'views' ), fox_number( $viewcount ) ) . '</span>';
                }
            }

            if ( $settings[ 'thumbnail_review_score' ] ) {
                if ( foxfw3_get_review_score_number() ) {
                    $score = foxfw3_get_review_score();
                    echo '<span class="thumbnail-score">' . $score . '</span>';
                }
            }

            ?>

        <?php if ( ! isset( $settings[ 'thumbnail_link' ] ) || $settings[ 'thumbnail_link' ] ) { ?>
            
        </a>
        
        <?php } ?>
        
    </div><!-- .thumbnail-inner -->
    
    <?php if ( 'yes' == $settings[ 'thumbnail_caption' ] && $the_caption = get_the_post_thumbnail_caption() ) {
    ?>
    
    <figcaption class="wp-caption-text fox-figcaption">
        <?php echo $the_caption; ?>
    </figcaption>
    
    <?php } ?>

</figure><!-- .fox-thumbnail -->

<?php
    
}

function foxfw3_permalink() {
    if ( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() && function_exists( 'amp_loop_permalink' ) ) {
        $permalink = amp_loop_permalink();
    } else {
        $permalink = get_permalink();
    }
    
    return $permalink;
}

function foxfw3_format_indicator( $postid = 0 ) {
    
    if ( ! $postid ) $postid = get_the_ID();
    
    $format = get_post_format( $postid );
    
    if ( 'video' === $format ) {
        $video_format_indicator_style = get_theme_mod( 'wi_video_indicator_style', 'outline' );
        
        $cl = [ 'video-format-indicator' ];
        $cl[] = 'video-indicator-' . $video_format_indicator_style;
        
        return '<span class="' . esc_attr( join( ' ', $cl )). '"><i class="fa fa-play"></i></span>';
    }
    
    if ( 'gallery' === $format ) {
        return '<span class="post-format-indicator gallery-format-indicator"><i class="fa fa-clone"></i></span>';
    }
    
    if ( 'link' === $format ) {
        return '<span class="post-format-indicator link-format-indicator"><i class="fa fa-share"></i></span>';
    }
    
    if ( 'audio' === $format ) {
        return '<span class="post-format-indicator audio-format-indicator"><i class="fa fa-music"></i></span>';
    }
    
    return '';
    
}

/**
 * Review
 * ------------------------------------------------------------------ */
function foxfw3_get_review_score_number() {
    return get_post_meta( get_the_ID(), '_wi_review_average', true );
}

function foxfw3_get_review_score() {
    $average = foxfw3_get_review_score_number();
    return number_format( ( float ) $average, 1, '.', '' );
}

/**
 * View
 * ------------------------------------------------------------------ */
function foxfw3_get_view( $post_id = null ) {
    
    if ( ! function_exists( 'pvc_get_post_views' ) ) return null;
    
    if ( ! $post_id ) {
        global $post;
        $post_id =  $post->ID;
    }
    
    return pvc_get_post_views( $post_id );
    
}

function foxfw3_post_view() {
    
    $count = foxfw3_get_view();
    if ( is_null( $count ) ) return;
    
    echo '<div class="fox-view-count wi-view-count entry-view-count" title="' . sprintf( foxfw3_word( 'views' ), $count ) . '"><span>' . sprintf( foxfw3_word( 'views' ), foxfw3_number( $count ) ) . '</span></div>';
    
}

/**
 * View
 * ------------------------------------------------------------------ */
function foxfw3_advanced_thumbnail() {
    if ( is_engine_v6() ) {
        if ( function_exists( 'fox56_single_thumbnail' ) ) {
            fox56_single_thumbnail();
        }
    } else {
        if ( function_exists( 'fox_advanced_thumbnail' ) ) {
            fox_advanced_thumbnail();
        }
    } 
}

/* POST BODY
------------------------------------------------------------------------ */
function fox_elementor_post_body( $settings ) {

    // we need the fox theme installed
    if ( ! defined( 'FOX_VERSION' ) ) {
        return;
    }
    
    $is_live = fox_is_live();
    
    $header_class = [
        'post-item-header',
    ];
    
    /**
     * item template
     */
    $item_template = absint( $settings[ 'item_template' ] );
    if ( $item_template < 1 || $item_template > 5 ) $item_template = 1;
    
    /**
     * LIVE
     * @since 4.3
     */
    $live_html = '';
    if ( ! isset( $settings[ 'live_indicator' ] ) || 'yes' == $settings[ 'live_indicator' ] ) {
        ob_start();
        fox_live_indicator();
        $live_html = ob_get_clean();
    }
    
    /**
     * title html
     */
    $title_html = '';
    
    if ( $settings[ 'show_title' ] ) {
            
        ob_start();

        $settings[ 'title_color' ] = '';
        fox_post_title( $settings );

        $title_html = ob_get_clean();
        
    }
    
    /**
     * excerpt html
     */
    $excerpt_html = '';
    
    if ( $settings[ 'show_excerpt' ] ) {
        
        ob_start();

        fox_post_excerpt( $settings );

        $excerpt_html = ob_get_clean();
        
    }
    
    /**
     * meta html
     */
    if ( 4 == $item_template || 5 == $item_template ) {
        
        ob_start();
        
        $settings_copy = $settings;
        $settings_copy[ 'show_category' ] = false;
        
        fox_post_meta( $settings_copy );
        
        $meta_html = ob_get_clean();
        
        $cat_html = '';
        
        if ( $settings[ 'show_category' ] ) {
            
            ob_start();
            
            fox_post_categories([ 
                'extra_class' => 'standalone-categories post-header-section',
                'style' => get_theme_mod( 'wi_standalone_category_style', 'plain' ),
            ]);
            
            $cat_html = ob_get_clean();
            
        }
        
    } else {
        
        ob_start();
        $meta_html = fox_post_meta( $settings );
        $meta_html = ob_get_clean();
        
    }
    
    /**
     * CASES
     */
    
    switch( $item_template ) {
            
        // title > meta > excerpt
        case 1 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $live_html . $title_html . $meta_html;
            echo '</div>';

            echo  $excerpt_html;
            
            break;
            
        // meta > title > excerpt
        case 2 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $meta_html . $title_html . $live_html;
            echo '</div>';

            echo  $excerpt_html;
            
            break;
            
        // title > excerpt > meta    
        case 3:
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $live_html . $title_html;
            echo '</div>';

            echo  $excerpt_html . $meta_html;
            
            break;
        
        // cateogry > title > meta > excerpt
        case 4 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $cat_html . $live_html . $title_html . $meta_html;
            echo '</div>';

            echo $excerpt_html;
            
            break;
          
        // cateogry > title > excerpt > meta
        case 5 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $cat_html . $live_html . $title_html;
            echo '</div>';

            echo $excerpt_html . $meta_html;
            
            break;
            
        default :
            break;
            
    }

}

function foxfw3_elementor_post_body( $settings ) {
    
    $is_live = fox56_is_live();
    $meta_items = foxfw3_meta_items_from_settings( $settings );
    
    $header_class = [
        'post-item-header',
    ];
    
    /**
     * item template
     */
    $item_template = absint( $settings[ 'item_template' ] );
    if ( $item_template < 1 || $item_template > 5 ) {
        $item_template = 1;
    }
    
    /**
     * LIVE, only for 3 or 5
     * @since 4.3
     */
    $live_html = '';
    if ( ! isset( $settings[ 'live_indicator' ] ) || 'yes' == $settings[ 'live_indicator' ] ) {
        if ( $item_template == 3 || $item_template == 5 ) {
            ob_start();
            fox56_meta([
                'meta_items' => [ 'live' ]
            ]);
            $live_html = ob_get_clean();
        }
    }
    
    /**
     * title html
     */
    $title_html = '';
    
    if ( $settings[ 'show_title' ] ) {
            
        ob_start();

        $settings[ 'title_color' ] = '';

        $title_extra_class = [];
        if ( isset( $settings['title_size'] ) && $settings['title_size'] ) {
            $title_extra_class[] = 'size-' . $settings['title_size'];
        }
        if ( isset( $settings['title_weight'] ) && $settings['title_weight'] ) {
            $title_extra_class[] = 'weight-' . $settings['title_weight'];
        }
        if ( isset( $settings['title_text_transform'] ) && $settings['title_text_transform'] ) {
            $title_extra_class[] = 'text-' . $settings['title_text_transform'];
        }
        if ( ! empty( $title_extra_class) ) {
            $settings[ 'title_extra_class' ] = join( ' ', $title_extra_class );
        }

        fox56_title( $settings );

        $title_html = ob_get_clean();
        
    }
    
    /**
     * excerpt html
     */
    $excerpt_html = '';
    
    if ( $settings[ 'show_excerpt' ] ) {
        
        ob_start();
        foxfw3_elementor_excerpt( $settings );
        $excerpt_html = ob_get_clean();
        
    }

    /**
     * get meta_html
     */
    ob_start();
    $settings_copy = $settings;
    $settings_copy[ 'meta_items' ] = $meta_items;
    $settings_copy[ 'author_avatar' ] = $settings[ 'show_author_avatar' ];
    fox56_meta( $settings_copy );
    $meta_html = ob_get_clean();

    /**
     * fancy_html
     */
    $cat_html = '';
    if ( 4 == $item_template || 5 == $item_template ) {
        ob_start();
        $settings_copy = $settings;
        $settings_copy[ 'meta_items' ] = [];
        if ( $settings['show_category'] ) {
            $settings_copy[ 'meta_items' ][] = 'standalone_category';
        }
        fox56_meta( $settings_copy );
        $cat_html = ob_get_clean();
    }
    
    /**
     * CASES
     */
    
    switch( $item_template ) {
            
        // title > meta > excerpt
        case 1 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $title_html . $meta_html;
            echo '</div>';

            echo  $excerpt_html;
            
            break;
            
        // meta > title > excerpt
        case 2 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $meta_html . $title_html;
            echo '</div>';

            echo  $excerpt_html;
            
            break;
            
        // title > excerpt > meta    
        case 3:
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $live_html . $title_html;
            echo '</div>';

            echo  $excerpt_html . $meta_html;
            
            break;
        
        // category > title > meta > excerpt
        case 4 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $cat_html . $title_html . $meta_html;
            echo '</div>';

            echo $excerpt_html;
            
            break;
          
        // category > title > excerpt > meta
        case 5 :
            
            echo '<div class="' . esc_attr( join( ' ', $header_class ) ) . '">';
            echo $cat_html . $title_html . $live_html;
            echo '</div>';

            echo $excerpt_html . $meta_html;
            
            break;
            
        default :
            break;
            
    }

}

/**
 * convert settings --> meta_items list of The Fox 6
 * 1: title > meta > excerpt
 * 2: meta > title > excerpt
 * 3: title > excerpt > meta
 * 4: category > title > meta > excerpt
 * 5: category > title > excerpt > meta
 */
function foxfw3_meta_items_from_settings( $settings ) {
    $item_template = absint( $settings[ 'item_template' ] );
    if ( $item_template < 1 || $item_template > 5 ) {
        $item_template = 1;
    }

    $meta_items = [];
    if ( ! isset( $settings[ 'live_indicator' ] ) || 'yes' == $settings[ 'live_indicator' ] ) {
        if ( $item_template != 3 && $item_template != 5 ) {
            $meta_items[] = 'live';
        }
    }
    if ( $settings[ 'show_author' ] ) {
        $meta_items[] = 'author';
    }
    if ( $settings[ 'show_date' ] ) {
        $meta_items[] = 'date';
    }
    if ( $settings[ 'show_category' ] && in_array( $item_template, [ 1, 2, 3 ] ) ) {
        $meta_items[] = 'category';
    }
    if ( $settings[ 'show_view' ] ) {
        $meta_items[] = 'view';
    }
    if ( $settings[ 'show_reading_time' ] ) {
        $meta_items[] = 'reading_time';
    }
    if ( $settings[ 'show_comment_link' ] ) {
        $meta_items[] = 'comment';
    }

    return $meta_items;
}

function foxfw3_elementor_excerpt( $settings ) {

    /*
    'excerpt_length' => 22,
    'excerpt_size' => '',
    'excerpt_extra_class' => '',
    'excerpt_exclude_class' => [],
    'excerpt_base' => '',
    'excerpt_more' => false,
    'excerpt_more_style' => 'simple',
    'excerpt_more_text' => '', // custom text
    */

    $args = [
        'excerpt_length' => $settings[ 'excerpt_length' ]
    ];
    if ( isset( $settings[ 'excerpt_size' ] ) && $settings[ 'excerpt_size' ] ) {
        $args[ 'excerpt_extra_class' ] = 'excerpt-size-' . $settings[ 'excerpt_size' ];
    }

    fox56_excerpt( $args );

    $style_map = [
        'simple' => 'plain',
        'simple-btn' => 'minimal',
        'btn' => 'fill',
        'btn-black' => 'black',
        'btn-primary' => 'primary',
    ];
    if ( isset( $settings[ 'excerpt_more' ] ) && $settings[ 'excerpt_more' ] ) {
        $style = isset( $style_map[ $settings[ 'excerpt_more_style' ] ] ) ? $style_map[ $settings[ 'excerpt_more_style' ] ] : 'fill';
        fox56_readmore([
            'more_style' => $style
        ]);
    }

}

/* Post Date
------------------------------------------------------------ */
if ( ! function_exists( 'fox_elementor_post_date' ) ) :
    function fox_elementor_post_date( $args ) {
        
        $format = isset( $args[ 'format' ] ) ? $args[ 'format' ] : get_option( 'date_format' );
        
        $time_string = '<time class="published" itemprop="datePublished" datetime="%1$s">%2$s</time>';
        $time_string = sprintf( $time_string,
            get_the_date( DATE_W3C ),
            get_the_date( $format ),
            get_the_modified_date( DATE_W3C ),
            get_the_modified_date( $format )
        );
        
        echo '<div class="entry-date meta-time">' . $time_string . '</div>';
        
    }
endif;

/* PAGINATION
------------------------------------------------------------------------ */
function foxfw3_pagination( $query = false ) {
        
    if ( ! $query ) {
        global $wp_query;
        $query = $wp_query;
    }
    
    $prev_label = fox_word( 'previous' );
    $next_label = fox_word( 'next' );
    
    $big = 9999; // need an unlikely integer
    
    $paged = ( is_front_page() && ! is_home() ) ? get_query_var( 'page' ) : get_query_var( 'paged' );
    
    $pagination = paginate_links( array(
        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format' => '?paged=%#%',
        'current' => max( 1, $paged ),
        'total' => $query->max_num_pages,
        'type'			=> 'plain',
        'before_page_number'	=>	'<span>',
        'after_page_number'	=>	'</span>',
        'prev_text'    => '<span>' . $prev_label . '</span>',
        'next_text'    => '<span>' . $next_label . '</span>',
    ) );
    
    /**
     * since 4.6.2
     */
    $cl = [ 'el-pagination' ];
    
    if ( $pagination ) {
        
        echo '<div class="' . esc_attr( join( ' ', $cl ) ) .'"><div class="pagination-inner">' . $pagination  . '</div></div>';
        
    }
    
}
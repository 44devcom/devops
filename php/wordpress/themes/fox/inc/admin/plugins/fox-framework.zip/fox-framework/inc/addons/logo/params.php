<?php
$params[ 'type' ] = array(
    'type' => 'select',
    'options' => [
        'text' => 'Text only',
        'image' => 'Image only',
        'mix' => 'Text + Image',
    ],
    'std' => 'text',
    'title' => 'Logo type',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'layout' ] = array(
    'type' => 'select',
    'options' => [
        '1' => 'Image left',
        '2' => 'Image right',
        '3' => 'Image top',
        '4' => 'Image bottom',
    ],
    'std' => '1',
    'title' => 'Image position',
    
    'condition' => array( 'type[value]' => 'mix' ),
);

$params[ 'align' ] = array(
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'center',
    'title' => 'Alignment',
);

$params[ 'custom_url' ] = array(
    'type' => 'url',
    'title' => 'Custom URL',
);

$params[ 'text_custom_enable' ] = array(
    'type' => 'switcher',
    'title' => 'Custom text',
    'std'   => 'no',
    'desc'  => 'If not enabled, it displays your site title',
    
    'section' => 'text',
    'section_title' => 'Text',
);

$params[ 'text_custom' ] = array(
    'type' => 'text',
    'title' => 'Custom text',
    'std' => 'My Site Name',
    'placeholder' => 'My Site Name',
    'condition' => array( 'text_custom_enable[value]' => 'yes' ),
);

$params[ 'text_color' ] = array(
    'type' => 'color',
    'title' => 'Color',
    'selectors' => [
        '{{WRAPPER}} .site-logo-text' => 'color: {{VALUE}};',    
    ],
);

$params[ 'text_typography' ] = array(
    'type' => 'typography',
    'title' => 'Typography',
    'selector' => '{{WRAPPER}} .site-logo-text',
);

$params[ 'image' ] = array(
    'type' => 'media',
    'title' => 'Upload image logo',
    
    'section' => 'image',
    'section_title' => 'Image',
);

$params[ 'image_size' ] = array(
    'type' => 'image_size',
    'title' => 'Image size',
    'name' => 'image',
);

$params[ 'width' ] = array(
    'type' => 'size',
    'title' => 'Image size',
    
    'std_size' => 100,
    'std_unit' => 'px',
    'px_min' => 20,
    'px_max' => 2000,
    
    'selectors' => array(
        '{{WRAPPER}} .site-logo-image img' => 'width: {{SIZE}}{{UNIT}};' 
    )
);
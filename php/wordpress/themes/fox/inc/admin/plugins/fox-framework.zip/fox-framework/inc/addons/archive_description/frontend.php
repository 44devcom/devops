<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    'disable_on_author_page' => 'no',
]) );

$cl = [ 'el-archive-description' ];

/**
 * final
 */
$cl = join( ' ', $cl );

if ( fox_is_edit() ) {
    $result = '<p>This is sample archive description placeholder used for design purpose. When you visit the archive, it shows the real description.</p>';
} else {
    
    if ( 'yes' == $disable_on_author_page && is_author() ) {
        $result = '';
    } else {

        $desc = '';
        if ( is_category() || is_tag() ) {
            $term = get_queried_object();
            if ( $term ) {
                $desc = $term->description;
            }
        }

        return $desc;

    }
    
}

if ( empty( $result ) ) {
    return;
}
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    <?php echo $result; ?>
</div>
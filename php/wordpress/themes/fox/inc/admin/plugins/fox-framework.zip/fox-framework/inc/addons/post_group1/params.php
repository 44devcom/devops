<?php
/* query params
------------------------------------ */
$params = foxfw3_query_params();
    
/* Essential
------------------------------------ */
$params[ 'bigpost_ratio' ] = array(
    'type' => 'select',
    'title' => 'Big post ratio',
    'options' => array(
        '2/3' => '2/3',
        '3/4' => '3/4',
        '1/2' => '1/2',
    ),
    'std' => '2/3',

    'section' => 'layout',
    'section_title' => 'Layout',
);

$params[ 'bigpost_position' ] = array(
    'type' => 'select',
    'title' => 'Big post position',
    'options' => array(
        'left'  => 'Left',
        'right' => 'Right',
    ),
    'std' => 'left',
);

$params[ 'group1_big_number' ] = [
    'title' => 'Number of big posts',
    'type'      => 'text',
    'std' => '1',
];

$params[ 'group1_small_display' ] = [
    'title'      => 'Small posts displayed as:',
    'type'      => 'select',
    'options'   => [
        'grid' => 'Grid',
        'list' => 'List',
    ],
    'std'       => 'list',
];

$params[ 'group1_small_column' ] = [
    'title'      => 'Small posts column (if Grid)',
    'type'      => 'select',
    'options'   => [
        1 => '1 column',
        2 => '2 columns',
    ],
    'std'       => 1,
];

/* Spacing
------------------------------------ */
$params[ 'group1_spacing_type' ] = [
    'title' => 'Column spacing type',
    'type' => 'select',
    'options' => [
        'predefined' => 'Predefined',
        'custom' => 'Custom',
    ],
    'std' => 'predefined',
];

$params[ 'group1_spacing' ] = [
    'title' => 'Column spacing',
    'type' => 'select',
    'options' => [
        'tiny' => 'Tiny',
        'small' => 'Small',
        'normal' => 'Normal',
    ],
    'std' => 'normal',
    
    'condition' => [
        'group1_spacing_type[value]' => 'predefined',
    ],
];

$params[ 'group1_hspacing' ] = [
    'title' => 'Column custom spacing',
    'type' => 'size',

    'std_size' => 20,
    'std_unit' => 'px',
    'px_max' => 100,
    'px_min' => 0,
    
    'selectors' => [
        '{{WRAPPER}} .post-group-spacing-custom .post-group-col' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-group-spacing-custom.post-group-row' => 'margin-left:-{{SIZE}}{{UNIT}};margin-right:-{{SIZE}}{{UNIT}};',
    ],

    'condition' => [
        'group1_spacing_type[value]' => 'custom',
    ],
];

$params[ 'text_color' ] = array(
    'type' => 'color',
    'title' => 'Custom Text Color',
    
    'selectors' => [
        '{{WRAPPER}} .wi-blog' => 'color:{{VALUE}};'
    ],
);

$params[ 'sep_border' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Border between big posts & small posts',
);

$params[ 'sep_border_color' ] = array(
    'type' => 'color',
    'title' => 'Border color',
    
    'selectors' => [
        '{{WRAPPER}} .has-border .sep-border' => 'color:{{VALUE}};'
    ],
);

$cols = [
    'big' => [
        'prefix' => 'bigpost_',
        'name' => 'Big post',
        'base_selector' => '.article-big',
    ],
    'small' => [
        'prefix' => 'small_posts_',
        'name' => 'Small post',
        'base_selector' => '.article-small',
    ],
];

foreach ( $cols as $col => $coldata ) {
    
    $prefix = $coldata['prefix'];
    $base_selector = $coldata['base_selector'];
    $name = $coldata['name'];
    
    if ( 'big' == $col ) {
        $std = 'center';
    } else {
        $std = 'left';
    }
    
    $params[ $prefix . 'item_align' ] = array(
        'title' => 'Item alignment',
        'type' => 'select',
        'options' => [
            'left' => 'Left',
            'center' => 'Center',
            'right' => 'Right',
        ],
        'std' => $std,
        
        'section' => $prefix . 'settings',
        'section_title' => $name,
    );
    
    if ( 'small' == $col ) {
        
        $params[ $prefix . 'grid_vspacing' ] = array(
            'title' => 'Vertical spacing between items',
            'type' => 'size',
            
            'selectors' => [
                '{{WRAPPER}} .post-group-col-small .column-1 .post-grid + .post-grid' => 'padding-top:{{SIZE}}{{UNIT}};margin-top:{{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .post-group-col-small .column-2 .post-grid' => 'padding-top:{{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .post-group-col-small .column-2' => 'margin-top:-{{SIZE}}{{UNIT}};',
            ],

            'std_unit' => 'px',
            'std_size' => 10,
            'px_max' => 100,
            'px_min' => 0,
            
            'condition' => [
                'group1_small_display[value]' => 'grid',
            ],
        );
        
        $params[ $prefix . 'grid_hsep' ] = array(
            'title' => 'Horizontal sep between items',
            'desc' => 'Please only use for 1-column only',
            'type' => 'size',
            
            'selectors' => [
                '{{WRAPPER}} .post-group-col-small .post-grid + .post-grid' => 'border-top-width:{{SIZE}}{{UNIT}};',
            ],

            'std_unit' => 'px',
            'std_size' => 0,
            'px_max' => 10,
            'px_min' => 0,
            
            'condition' => [
                'group1_small_display[value]' => 'grid',
            ],
        );
        
        $params[ $prefix . 'grid_hsep_color' ] = array(
            'title' => 'Horizontal sep color',
            'type' => 'color',
            
            'selectors' => [
                '{{WRAPPER}} .post-group-col-small .post-grid + .post-grid' => 'border-top-color:{{VALUE}};',
            ],
            
            'condition' => [
                'group1_small_display[value]' => 'grid',
            ],
        );
        
        $params[ $prefix . 'list_vspacing' ] = array(
            'title' => 'Spacing between items',
            'type' => 'size',
            
            'selectors' => [
                '{{WRAPPER}} ' . $base_selector . '.post-list + .post-list' => 'margin-top:{{SIZE}}{{UNIT}};',
                '{{WRAPPER}} ' . $base_selector . ' .post-list-sep' => 'padding-top:{{SIZE}}{{UNIT}};',
            ],

            'std_unit' => 'px',
            'std_size' => 20,
            'px_max' => 100,
            'px_min' => 0,
            
            'condition' => [
                'group1_small_display[value]' => 'list',
            ],
        );
    
        $params[ $prefix . 'list_sep' ] = array(
            'title' => 'Border between items?',
            'type' => 'switcher',
            'std' => 'no',
            'title' => 'Border between items?',
            'condition' => [
                'group1_small_display[value]' => 'list',
            ],
        );
        
        $params[ $prefix . 'list_sep_color' ] = array(
            'title' => 'Separator color',
            'type' => 'color',
            'selectors' => [
                '{{WRAPPER}} .article-small .post-list-sep' => 'border-color:{{VALUE}};',
            ],
            
            'condition' => [
                'group1_small_display[value]' => 'list',
            ],
        );
        
    }

    $params[ $prefix . 'item_template' ] = array(
        'title' => 'Elements order',
        'type' => 'select',
        'options' => [
            '1' => 'Title > Meta > Excerpt',
            '2' => 'Meta > Title > Excerpt',
            '3' => 'Title > Excerpt > Meta',
    
            '4' => 'Category > Title > Meta > Excerpt',
            '5' => 'Category > Title > Excerpt > Meta',
        ],
        'std' => '1',
    );
    
    // new, since 5.4
    $params[ $prefix . 'item_background' ] = array(
        'title' => 'Item background',
        'type' => 'color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-inner' => 'background-color:{{VALUE}};',
        ],
    );

    // new, since 5.0
    $params[ $prefix . 'text_color' ] = array(
        'title' => 'Custom Text Color',
        'type' => 'color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector => 'color:{{VALUE}};',
        ],
    );

    if ( 'big' == $col ) {
    
        $params[ $prefix . 'thumbnail_spacing' ] = array(
            'title' => 'Thumbnail - Text Spacing',
            'type' => 'size',
            'selectors' => [
                '{{WRAPPER}} ' . $base_selector . ' .grid-thumbnail + .grid-body' => 'margin-top:{{SIZE}}{{UNIT}};',
            ],
            'std_unit' => 'px',
            'std_size' => 16,
            'px_max' => 60,
            'px_min' => 0,
        );
        
    } else {
        
        $params[ $prefix . 'thumbnail_spacing' ] = array(
            'title' => 'Thumbnail - Text Spacing',
            'type' => 'size',
            'selectors' => [
                '{{WRAPPER}} .article-small-grid .grid-thumbnail + .grid-body' => 'margin-top:{{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .article-small-list.post-thumbnail-align-left .list-thumbnail + .post-body' => 'padding-left:{{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .article-small-list.post-thumbnail-align-right .list-thumbnail + .post-body' => 'padding-right:{{SIZE}}{{UNIT}};',
            ],
            'std_unit' => 'px',
            'std_size' => 16,
            'px_max' => 60,
            'px_min' => 0,
        );
        
    }

    $params[ $prefix . 'title_meta_spacing' ] = array(
        'title' => 'Upper Meta - Title Spacing',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-header-section + .post-header-section.post-item-title' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} ' . $base_selector . ' .component56 + .component56.title56' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 6,
        'px_max' => 60,
        'px_min' => 0,
    );

    $params[ $prefix . 'excerpt_spacing' ] = array(
        'title' => 'Title - Excerpt Spacing',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-header+.post-item-excerpt' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} ' . $base_selector . ' .component56+.excerpt56' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 16,
        'px_max' => 60,
        'px_min' => 0,
    );

    $params[ $prefix .'bottom_meta_spacing' ] = array(
        'title' => 'Excerpt - Bottom Meta Spacing',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-excerpt+.post-item-meta' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} ' . $base_selector . ' .excerpt56+.meta56' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 22,
        'px_max' => 60,
        'px_min' => 0,
    );

    /* thumbnail
    ----------------------------------- */
    $params[ $prefix . 'thumbnail_heading' ] = [
        'type' => 'heading',
        'title' => 'Thumbnail',
    ];

    $params[ $prefix . 'show_thumbnail' ] = array(
        'type' => 'switcher',
        'std' => 'yes',
        'title' => 'Show thumbnail',
    );
    
    if ( 'small' == $col ) {
        $params[ $prefix . 'disable_thumbnail_after_first' ] = array(
            'type' => 'switcher',
            'std' => 'no',
            'title' => 'Disable thumbnail from 2nd post',
        );
    }
    
    if ( 'big' == $col ) {
        $params[ $prefix . 'thumbnail_type' ] = [
            'title' => 'Thumbnail Type',
            'type' => 'select',
            'options' => [
                'advanced' => 'Full slider, video etc',
                'simple' => 'Just simple image thumbnail',
            ],
            'std' => 'simple',
        ];
        
        $params[ $prefix . 'thumbnail_caption' ] = [
            'title' => 'Thumbnail caption',
            'type' => 'switcher',
            'std' => 'no',
        ];
        
    }
    
    if ( 'big' == $col ) {
        $std = 'thumbnail-large';
    } else {
        $std = 'landscape';
    }

    $params[ $prefix . 'thumbnail' ] = array(
        'type' => 'select',
        'options' => [
            'thumbnail' => 'Thumbnail (150x150)',
            
            'landscape' => 'Medium crop (480x384)',
            'square' => 'Square crop (480x480)',
            'portrait' => 'Portrait crop (480x600)',
            'thumbnail-large' => 'Large crop (720x480)',
            
            'medium' => 'Medium (no crop)',
            'large' => 'Large (no crop)',
    
            'original' => 'Original ratio (Fullwidth)',
            'original_fixed' => 'Original ratio (Fixed height)',
            'custom' => 'Custom',
        ],
        'std' => $std,
        'title' => 'Thumbnail',
    );
    
    $params[ $prefix . 'thumbnail_custom' ] = array(
        'type' => 'text',
        'title' => 'Custom Size (Eg. 425x360)',

        'condition' => [
            $prefix . 'thumbnail[value]' => 'custom',
        ]
    );

    $params[ $prefix . 'thumbnail_placeholder' ] = array(
        'type' => 'switcher',
        'std' => 'yes',
        'title' => 'Placeholder thumbnail',
        'desc' => 'For posts dont have a thumbnail'
    );
    
    $params[ $prefix . 'thumbnail_youtube_player' ] = [
        'title' => 'YouTube plays when click thumbnail',
        'desc' => 'This applies to video post format with YouTube thumbnail',
        'type' => 'switcher',
        'std' => 'no',
    ];
    
    if ( 'small' == $col ) {
        
        $params[ $prefix . 'thumbnail_width' ] = array(
            'type' => 'size',
            'std_unit' => 'px',
            'std_size' => 120,
            'px_max' => 200,
            'px_min' => 40,
            
            'selectors' => [
                '{{WRAPPER}} .article-small-list .list-thumbnail' => 'width:{{SIZE}}{{UNIT}};',
            ],

            'title' => 'Thumbnail width',
            'condition' => [
                'group1_small_display[value]' => 'list',
            ],
        );
        
        $params[ $prefix . 'thumbnail_position' ] = array(
            'type' => 'select',
            'title' => 'Thumbnail position',
            'options' => [
                'left' => 'Left',
                'right' => 'Right',
                'alternative' => 'Alternative',
            ],
            'std' => 'left',
            
            'condition' => [
                'group1_small_display[value]' => 'list',
            ],
        );
    
    }

    $params[ $prefix . 'thumbnail_padding' ] = array(
        'title' => 'Thumbnail padding',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-thumbnail' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 0,
        'px_max' => 200,
        'px_min' => 0,
    );

    $params[ $prefix . 'thumbnail_padding_top' ] = array(
        'title' => 'Thumbnail padding top/bottom',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-thumbnail' => 'padding-top:{{SIZE}}{{UNIT}};padding-bottom:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 0,
        'px_max' => 100,
        'px_min' => 0,
    );

    $params[ $prefix . 'thumbnail_border' ] = array(
        'title' => 'Thumbnail border width',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-thumbnail' => 'border-width:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 0,
        'px_max' => 20,
        'px_min' => 0,
    );

    $params[ $prefix . 'thumbnail_border_color' ] = array(
        'title' => 'Thumbnail border color',
        'type' => 'color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-thumbnail' => 'border-color:{{VALUE}};',
        ],
    );

    // @todo: more shape
    $params[ $prefix . 'thumbnail_shape' ] = array(
        'type'  => 'select',
        'std'   => 'acute',
        'options' => [
            'acute'     => 'Acute',
            'round'     => 'Round',
            'circle'    => 'Circle',
        ],
        'title' => 'Thumbnail shape',
    );

    $params[ $prefix . 'thumbnail_hover_effect' ] = array(
        'type'  => 'select',
        'std'   => 'none',
        'options' => [
            'none'      => 'None',
            'fade'      => 'Image Fade',
            'grayscale' => 'Grayscale',
            'sepia'     => 'Sepia',
            'dark'      => 'Dark',
            'letter'    => 'Title First Letter',
            'zoomin'    => 'Image Zoom In',
            'logo'      => 'Custom Logo',
        ],
        'title' => 'Thumbnail hover effect',
    );

    $params[ $prefix . 'thumbnail_hover_logo' ] = array(
        'type'  => 'image',
        'title' => 'Thumbnail hover logo',

        'condition' => [
            $prefix . 'thumbnail_hover_effect[value]' => 'logo',
        ]
    );
    $params[ $prefix . 'thumbnail_hover_logo_size' ] = array(
        'type'  => 'image_size',
        'name' => $prefix . 'thumbnail_hover_logo',
        'title' => 'Thumbnail logo size',

        'condition' => [
            $prefix . 'thumbnail_hover_effect[value]' => 'logo',
        ]
    );

    $params[ $prefix . 'thumbnail_hover_logo_width' ] = array(
        'type'  => 'size',

        'std_unit' => '%',
        'std_size' => 40,

        'title' => 'Logo width',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .image-logo' => 'width:{{SIZE}}{{UNIT}};',
        ],

        'condition' => [
            $prefix . 'thumbnail_hover_effect[value]' => 'logo',
        ]
    );

    $params[ $prefix . 'thumbnail_showing_effect' ] = array(
        'type'  => 'select',
        'std'   => 'none',
        'options' => [
            'none'      => 'None',
            'fade'      => 'Image Fade',
            'slide'     => 'Slide',
            'popup'     => 'Pop up',
            'zoomin'    => 'Zoom In',
        ],
        'title' => 'Thumbnail showing effect',
    );

    $params[ $prefix . 'format_indicator' ] = array(
        'type'  => 'switcher',
        'std'   => 'yes',
        'title' => 'Show format indicator',
    );

    $params[ $prefix . 'thumbnail_index' ] = array(
        'type'  => 'switcher',
        'std'   => '',
        'title' => 'Index 01, 02.. on thumbnail',
    );

    $params[ $prefix . 'thumbnail_view' ] = array(
        'type'  => 'switcher',
        'std'   => '',
        'title' => 'Display view count',
    );

    /* text + components
    ----------------------------------- */
    $params[ $prefix . 'title_heading' ] = [
        'type' => 'heading',
        'title' => 'Title',
    ];

    $params[ $prefix . 'show_title' ] = array(
        'type' => 'switcher',
        'std' => 'yes',
        'title' => 'Show title',
    );

    $params[ $prefix . 'title_tag' ] = array(
        'type' => 'select',
        'options' => [
            'h2' => 'H2',
            'h3' => 'H3',
            'h4' => 'H4',
        ],
        'std' => 'h2',
        'title' => 'Title tag',

        'condition' => [
            $prefix. 'show_title[value]' => 'yes',
        ],
    );

    /* Excerpt
     * ------------------------ */
    $params[ $prefix . 'excerpt_heading' ] = [
        'type' => 'heading',
        'title' => 'Excerpt',
    ];
    
    if ( 'smal' == $col ) {
        $std = '';
    } else {
        $std = 'yes';
    }

    $params[ $prefix . 'show_excerpt' ] = array(
        'type' => 'switcher',
        'std' => $std,
        'title' => 'Display excerpt?',
    );
    
    if ( 'big' == $col ) {
        $std = 22;
    } else {
        $std = 12;
    }

    $params[ $prefix . 'excerpt_length' ] = array(
        'type' => 'text',
        'std' => $std,
        'title' => 'Excerpt length',

        'condition' => [
            $prefix . 'show_excerpt[value]' => 'yes',
        ],
    );
    
    if ( 'small' == $col ) {
        $std = '';
    } else {
        $std = 'yes';
    }

    $params[ $prefix . 'excerpt_more' ] = array(
        'type' => 'switcher',
        'std' => $std,
        'title' => 'More Link',
    );
    
    if ( 'big' == $col ) {
        $std = 'btn';
    } else {
        $std = 'simple';
    }

    $params[ $prefix . 'excerpt_more_style' ] = array(
        'type' => 'select',
        'options' => [
            'simple' => 'Plain Link',
            'simple-btn' => 'Minimal Link', // simple button
            'btn' => 'Fill Button', // default btn
            'btn-black' => 'Solid Black Button',
            'btn-primary' => 'Primary Button',
        ],
        'std' => $std,
        'title' => 'More text style',

        'condition' => [
            $prefix . 'excerpt_more[value]' => 'yes',
        ],
    );

    $params[ $prefix . 'excerpt_more_text' ] = array(
        'type' => 'text',
        'placeholder' => 'More',
        'title' => 'Custom More Text',

        'condition' => [
            $prefix . 'excerpt_more[value]' => 'yes',
        ],
    );

    /* Date
     * ------------------------ */
    $params[ $prefix . 'date_heading' ] = [
        'type' => 'heading',
        'title' => 'Date',
    ];

    $params[ $prefix . 'show_date' ] = array(
        'type' => 'switcher',
        'std' => 'yes',
        'title' => 'Show post date',
    );
    
    $params[ $prefix. 'live_indicator' ] = [
        'title' => 'Live Indicator (for LIVE posts)',
        'type' => 'switcher',
        'std' => 'yes',
    ];
    
    $params[ $prefix . 'live_indicator_color' ] = [
        'title' => 'Live Indicator Color',
        'type' => 'color',
        'std' => '#d0022c',

        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .live-indicator' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .live-circle' => 'background:{{VALUE}};',
        ],
    ];

    /* Category
     * ------------------------ */
    $params[ $prefix . 'category_heading' ] = [
        'type' => 'heading',
        'title' => 'Category',
    ];
    
    if ( 'medium' == $col || 'small' == $col ) {
        $std = '';
    } else {
        $std = 'yes';
    }

    $params[ $prefix . 'show_category' ] = array(
        'type' => 'switcher',
        'std' => $std,
        'title' => 'Show post categories',
    );

    /* Author
     * ------------------------ */
    $params[ $prefix . 'author_heading' ] = [
        'type' => 'heading',
        'title' => 'Author',
    ];

    $params[ $prefix . 'show_author' ] = array(
        'type' => 'switcher',
        'std' => '',
        'title' => 'Show post author',
    );

    $params[ $prefix . 'show_author_avatar' ] = array(
        'type' => 'switcher',
        'std' => '',
        'title' => 'Show author avatar',
    );

    $params[ $prefix . 'author_avatar_size' ] = array(
        'type' => 'size',
        'title' => 'Author avatar size',

        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .meta-author-avatar' => 'width:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} ' . $base_selector . ' .meta56__author a img' => 'width:{{SIZE}}{{UNIT}};',
        ],

        'condition' => array(
            $prefix . 'show_author_avatar[value]' => 'yes' 
        ),

        'std_unit' => 'px',
        'std_size' => 32,
        'px_max' => 80,
        'px_min' => 10,
    );

    /* View count
     * ------------------------ */
    $params[ $prefix . 'view_count_heading' ] = [
        'type' => 'heading',
        'title' => 'View Count',
    ];

    $params[ $prefix . 'show_view' ] = array(
        'type' => 'switcher',
        'std' => '',
        'title' => 'Show view count',
    );

    /* Comment link
     * ------------------------ */
    $params[ $prefix . 'comment_link_heading' ] = [
        'type' => 'heading',
        'title' => 'Comment Link',
    ];

    $params[ $prefix . 'show_comment_link' ] = [
        'type' => 'switcher',
        'std' => '',
        'title' => 'Show comment link',
    ];

    /* Reading Time
     * ------------------------ */
    $params[ $prefix . 'reading_time_heading' ] = [
        'type' => 'heading',
        'title' => 'Reading Time',
    ];

    $params[ $prefix . 'show_reading_time' ] = array(
        'type' => 'switcher',
        'std' => '',
        'title' => 'Show reading time',
    );
    
    $params[ $prefix . 'code_before' ] = array(
        'title' => 'HTML code beginning of column',
        'type' => 'textarea',
        'desc' => 'Enter HTML code here, it will appear before posts of the column',
    );
    
    $params[ $prefix . 'code_after' ] = array(
        'title' => 'HTML code end of column',
        'type' => 'textarea',
        'desc' => 'Enter HTML code here, it will appear after posts of the column',
    );

    /* ----------------------------------------------------------------------
    // STYLE
    ---------------------------------------------------------------------- */

    /* title
    ----------------------------------- */
    // legacy
    
    if ( 'big' == $col ) {
        $std = 'medium';
    } elseif ( 'small' == $col ) {
        $std = 'tiny';
    } else {
        $std = 'normal';
    }
    $params[ $prefix . 'title_size' ] = array(
        'type'  => 'select',
        'std'   => $std,
        'options' => [
            'supertiny' => 'Super Tiny',
            'tiny' => 'Tiny',
            'small' => 'Small',
            'normal' => 'Normal',
            'medium' => 'Medium',
            'large' => 'Large',
        ],
        'title' => 'Title size',
        'desc' => 'Legacy option for compatibility, you can use Title Typography option',

        'condition' => [
            $prefix . 'show_title[value]' => 'yes',
        ],

        'section' => $prefix . 'post_item_style',
        'section_title' => $name . ' item style',
        'section_tab' => 'style',
    );

    // legacy
    $params[ $prefix . 'title_weight' ] = array(
        'type'  => 'select',
        'std'   => '',
        'options' => [
            '' => 'Default',
            '300' => 'Light',
            '400' => 'Normal',
            '700' => 'Bold',
            '900' => 'Heavy',
        ],
        'title' => 'Title weight',
        'desc' => 'Legacy option for compatibility, you can use Title Typography option',

        'condition' => [
            $prefix . 'show_title[value]' => 'yes',
        ],
    );

    $params[ $prefix . 'title_typography' ] = array(
        'type' => 'typography',
        'title' => 'Title typography',
        'selector' => '{{WRAPPER}} ' . $base_selector . ' .post-item-title, {{WRAPPER}} ' . $base_selector . ' .title56',
    );

    $params[ $prefix . 'title_color' ] = array(
        'type' => 'color',
        'title' => 'Title color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-title a' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .title56 a' => 'color:{{VALUE}};',
        ],
    );

    $params[ $prefix . 'title_hover_color' ] = array(
        'type' => 'color',
        'title' => 'Title hover color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-title a:hover' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .title56 a:hover' => 'color:{{VALUE}};',
        ],
    );

    $params[ $prefix . 'title_hover_effect' ] = array(
        'type' => 'select',
        'title' => 'Title hover effect',
        'options' => [
            'none' => 'None',
            'underline' => 'Underline',
            'line-through' => 'Line through',
        ],
        'std' => 'none',
    );

    $params[ $prefix . 'title_hover_underline_color' ] = array(
        'type' => 'color',
        'title' => 'Title hover underline color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . '.style-title-hover-underline .post-item-title a:hover' => 'text-decoration-color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . '.style-title-hover-line-through .post-item-title a:hover' => 'text-decoration-color:{{VALUE}};',

            '{{WRAPPER}} ' . $base_selector . '.style-title-hover-underline .title56 a:hover' => 'text-decoration-color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . '.style-title-hover-line-through .title56 a:hover' => 'text-decoration-color:{{VALUE}};',
        ],
    );

    /* excerpt
    ----------------------------------- */
    $params[ $prefix . 'excerpt_style_heading' ] = array(
        'type' => 'heading',
        'title' => 'Excerpt',
    );

    $params[ $prefix . 'excerpt_size' ] = array(
        'type' => 'select',
        'options' => [
            'small' => 'Small',
            'normal' => 'Normal',
            'medium' => 'Medium',
        ],
        'title' => 'Excerpt font size',
        'std'   => 'normal',

        'condition' => [
            $prefix . 'show_excerpt[value]' => 'yes',
        ],

        'desc' => 'Legacy option for compatibility, you can use Title Typography option',
    );

    $params[ $prefix . 'excerpt_typography' ] = array(
        'type' => 'typography',
        'title' => 'Excerpt typography',
        'selector' => '{{WRAPPER}} ' . $base_selector . ' .post-item-excerpt, {{WRAPPER}} ' . $base_selector . ' .excerpt56',
    );

    $params[ $prefix . 'excerpt_color' ] = array(
        'type' => 'color',
        'title' => 'Excerpt color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-excerpt' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .excerpt56' => 'color:{{VALUE}};',
        ],
    );

    /* meta
    ----------------------------------- */
    $params[ $prefix . 'meta_style_heading' ] = array(
        'type' => 'heading',
        'title' => 'Post meta',
    );

    $params[ $prefix . 'meta_typography' ] = array(
        'type' => 'typography',
        'title' => 'Meta typography',
        'selector' => '{{WRAPPER}} ' . $base_selector . ' .post-item-meta, {{WRAPPER}} ' . $base_selector . ' .meta56',
    );

    $params[ $prefix . 'meta_color' ] = array(
        'type' => 'color',
        'title' => 'Meta color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-meta' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .meta56' => 'color:{{VALUE}};',
        ],
    );

    $params[ $prefix . 'meta_link_color' ] = array(
        'type' => 'color',
        'title' => 'Meta link color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-meta a' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .meta56 a' => 'color:{{VALUE}};'
        ],
    );

    $params[ $prefix . 'meta_link_hover_color' ] = array(
        'type' => 'color',
        'title' => 'Meta link hover color',
        'selectors' => [
            '{{WRAPPER}} ' . $base_selector . ' .post-item-meta a:hover' => 'color:{{VALUE}};',
            '{{WRAPPER}} ' . $base_selector . ' .meta56 a:hover' => 'color:{{VALUE}};',
        ],
    );

    /* standalone categories
    ----------------------------------- */
    $params[ $prefix . 'standalone_cats_style_heading' ] = array(
        'type' => 'heading',
        'title' => 'Standalone Category',
    );

    $params[ $prefix . 'standalone_categories_typography' ] = array(
        'type' => 'typography',
        'title' => 'Standalone Category typography',
        'selector' => '{{WRAPPER}} ' . $base_selector . ' .standalone-categories, {{WRAPPER}} ' . $base_selector . ' .meta56__category--fancy',
    );
    
}
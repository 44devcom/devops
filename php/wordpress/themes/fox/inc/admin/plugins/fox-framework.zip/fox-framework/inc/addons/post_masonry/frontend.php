<?php
$settings = $this->get_settings_for_display();
$settings[ 'layout' ] = 'masonry';

$query = foxfw3_query( $settings );
$fn_params = foxfw3_fn_params( $settings );

foxfw3_blog( $fn_params, $query );
<?php
$settings = $this->get_settings_for_display();        
$settings[ 'layout' ] = 'grid';

extract( wp_parse_args( $settings, [
    
    'first_standard' => 'no', // this is a big option
    'first_double' => 'no',
    
    'pagination' => '',
    'layout' => 'grid',
    'column' => '3',
    'item_card' => '',
    'item_border' => 'no',
    'item_spacing_type' => 'predefined',
    'item_spacing' => 'normal',
    'item_template' => '1',
    
    // component params
    'show_thumbnail' => '',
    'show_title' => '',
    'show_date' => '',
    'show_category' => '',
    'show_author' => '',
    'show_author_avatar' => '',
    'show_excerpt' => '',
    'show_excerpt_more' => '',
    'show_view' => '',
    'show_reading_time' => '',
    'show_comment_link' => '',

    // thumbnail options
    'thumbnail' => 'landscape',
    'thumbnail_custom' => '',
    'thumbnail_placeholder' => true,
    'thumbnail_placeholder_id' => '',
    'thumbnail_shape' => '',
    'thumbnail_hover' => '',
    'thumbnail_hover_logo' => '',
    'thumbnail_showing_effect' => '',

    'thumbnail_format_indicator' => '',
    'thumbnail_index' => '',
    'thumbnail_view' => '',
    'thumbnail_review_score' => '',

    'thumbnail_extra_class' => '',

    // since 4.6.7
    'thumbnail_order' => '', // if 'after' then display the thumbnail after post content

    // title options
    'title_tag' => '',
    'title_size' => '', // legacy
    'title_weight' => '', // legacy

    // excerpt options
    'excerpt_length' => 22,
    'excerpt_size' => '', // legacy
    'excerpt_hellip' => '',
    'excerpt_more' => '',
    'excerpt_more_style' => '',
    'excerpt_more_text' => '',

    // extra
    'extra_class' => '', // legacy
    
    // misc
    'thumbnail_youtube_player' => 'no',
]) );

$backup_settings = $settings;

// no posts found
// don't waste my time
$query = foxfw3_query( $settings );
if ( ! $query ) {
    return;
}

if ( isset( $settings[ 'source' ] ) && 'archive' == $settings[ 'source' ] ) {
    $pagination = 'yes';
}

if ( ! $query->have_posts() ) {
    wp_reset_query();
    return;
}

$container_cl = [ 'blog-container', 'blog-container-grid' ];
$cl = [ 'wi-blog', 'fox-blog', 'blog-grid', 'fox-grid' ];
$grid_line_class = [ 'fox-grid', 'grid-lines' ];
    
/* first standard
this is a big option
-------------------------------------- */
if ( $first_standard == 'yes' ) {
    $cl[] = 'has-standard-first';
}

if ( 'yes' == $first_double ) {
    $cl[] = 'has-first-double';
}

/* extra class
-------------------------------------- */
if ( $extra_class ) {
    $cl[] = $extra_class;
}

/* card layout
-------------------------------------- */
if ( strpos( $item_card, 'no_shadow' ) === false ) {
    $cl[] = 'blog-card-has-shadow';
} else {
    $cl[] = 'blog-card-no-shadow';
}
$the_item_card = str_replace( '_no_shadow', '', $item_card );
if ( in_array( $the_item_card, [ 'normal', 'overlap' ] ) ) {
    $cl[] = 'blog-card-' . $the_item_card;
}

/* border
-------------------------------------- */
if ( 'yes' == $item_border ) {
    $container_cl[] = 'blog-container-has-border';
}

/* column
-------------------------------------- */
$cl[] = 'column-' . $column;
$grid_line_class[] = 'column-' . $column;

/* item spacing
-------------------------------------- */
if ( 'predefined' == $item_spacing_type ) {
    $cl[] = 'spacing-predefined';
    if ( ! in_array( $item_spacing, [ 'none', 'tiny', 'small', 'normal', 'medium', 'wide', 'wider' ] ) ) {
        $item_spacing = 'normal';
    }
    $cl[] = 'spacing-' . $item_spacing;
} else {
    $cl[] = 'spacing-custom';
}

/* youtube player
-------------------------------------- */
if ( 'yes' == $thumbnail_youtube_player ) {
    $cl[] = 'behavior-thumbnail-youtube-player';
}

?>

<div class="<?php echo esc_attr( join( ' ', $container_cl ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $cl ) ); ?>">
    
    <?php 
    $count = 0;
        // backup settings
        $copy_settings = $settings;
        
    while ( $query->have_posts() ) {
        
        $query->the_post();
        $count++;
        
        $settings[ 'count' ] = $count;
        
        if ( 'yes' == $first_standard && 1 == $count ) {
            
            foreach ( $copy_settings as $k => $v ) {
                if ( false !== strpos( $k, 'standard_' ) ) {
                    $k_without_standard = str_replace( 'standard_', '', $k );
                    $settings[ $k_without_standard ] = $v;
                }
            }
            require FOX_FRAMEWORK_PATH . 'content/post-standard.php';
            
            // now restore it
            $settings = $copy_settings;
            
        } else {
            
            // since 5.4
            // disable thumbnail from 2nd post
            if( isset( $settings[ 'disable_thumbnail_after_first' ] ) && 'yes' == $settings[ 'disable_thumbnail_after_first' ] && $count >= 2 ) {
                $settings[ 'show_thumbnail' ] = false;
            }
            
            // disable excerpt of the 1st post
            if ( isset( $settings[ 'disable_excerpt_first' ] ) && 'yes' == $settings[ 'disable_excerpt_first' ] && $count == 1 ) {
                $settings[ 'show_excerpt' ] = false;
            } else {
                $settings[ 'show_excerpt' ] = $backup_settings[ 'show_excerpt' ];
            }
            
            if ( isset( $settings[ 'first_thumbnail' ] ) && '' != $settings[ 'first_thumbnail' ] && 1 == $count ) {
                $settings[ 'thumbnail' ] = $settings[ 'first_thumbnail' ];
                if ( isset( $settings[ 'first_thumbnail_custom' ] ) && 'custom' == $settings[ 'thumbnail' ] ) {
                    $settings[ 'thumbnail_custom' ] = $settings[ 'first_thumbnail_custom' ];
                }
            }
            
            include FOX_FRAMEWORK_PATH . 'content/post-grid.php';
            
            // now restore it
            $settings = $copy_settings;
            
        }
        
        do_action( 'fox_after_render_post' );
        
    } ?>
        
    <?php if ( 'yes' == $item_border ) { ?>

    <div class="<?php echo esc_attr( join( ' ', $grid_line_class ) ); ?>">

        <?php for ( $i = 1; $i <= $column; $i++ ) { ?>
        <div class="grid-line fox-grid-item">
            <div class="grid-line-inner"></div>
        </div>
        <?php } ?>

    </div><!-- .grid-lines -->

    <?php } ?>
    
    </div><!-- .fox-blog -->
    
    <?php if ( 'yes' == $pagination ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->

    <?php

wp_reset_query();
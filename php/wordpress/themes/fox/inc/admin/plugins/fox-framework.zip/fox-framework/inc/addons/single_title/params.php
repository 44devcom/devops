<?php
$params[ 'align' ] = array(
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'left',
    'title' => 'Alignment',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'title_preview_text' ] = array(
    'type' => 'text',
    'title' => 'Preview text',
    'desc' => 'In your actual post, this will be replaced by your post title. However, you can enter custom text here to imagine it.',
);

$params[ 'title_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-title .el-title-tag',
    'title' => 'Typography',
);

$params[ 'title_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-title .el-title-tag' => 'color:{{VALUE}};',
    ],
    'title' => 'Color',
);
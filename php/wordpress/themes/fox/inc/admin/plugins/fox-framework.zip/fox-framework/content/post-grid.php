<?php
/**
 * post class
 */
$post_class = [ 'wi-post', 'post-item', 'post-grid', 'fox-grid-item' ];

if ( isset( $settings[ 'post_extra_class' ] ) ) {
    $post_class[] = $settings[ 'post_extra_class' ];
}

/**
 * Post Body Class
 */
$post_body_class = [ 'post-body', 'post-item-body' ];
$post_body_class[] = 'grid-body';
$post_body_class[] = 'post-grid-body';

/**
 * title_hover_effect
 */
if ( isset( $settings[ 'title_hover_effect' ] ) ) {
    $post_class[] = 'style-title-hover-' . $settings[ 'title_hover_effect' ];
}

/**
 * extra thumbnail css
 */
$thumbnail_args = $settings;
$thumbnail_args[ 'thumbnail_extra_class' ] = 'grid-thumbnail';

/**
 * thumbnail order
 * @todo
 */
ob_start();

// thumbnail_index
if ( isset( $settings['count']) ) {
    $count = $settings['count'];
}
if ( isset( $settings[ 'thumbnail_index' ] ) && 'yes' == $settings[ 'thumbnail_index' ] ) {
    $thumbnail_args[ 'count' ] = $count;
}

if ( isset( $settings[ 'show_thumbnail' ] ) && $settings[ 'show_thumbnail' ] == 'yes' ) {
    foxfw3_elementor_thumbnail( $thumbnail_args );
}
$thumbnail_final_html = ob_get_clean();

ob_start(); ?>

<div class="<?php echo esc_attr( join( ' ', $post_body_class ) ); ?>">
    <div class="post-body-inner">
        <?php
        if ( is_engine_v6() ) {
            foxfw3_elementor_post_body( $settings );
        } elseif ( defined( 'FOX_VERSION' ) ) {
            fox_elementor_post_body( $settings );
        }
        ?>
    </div>
</div><!-- .post-item-body -->

<?php $text_final_html = ob_get_clean(); ?>

<article <?php post_class( $post_class ); ?> itemscope itemtype="https://schema.org/CreativeWork">

    <div class="post-item-inner grid-inner post-grid-inner">

        <?php echo $thumbnail_final_html . $text_final_html ; ?>

    </div><!-- .post-item-inner -->

</article><!-- .post-item -->
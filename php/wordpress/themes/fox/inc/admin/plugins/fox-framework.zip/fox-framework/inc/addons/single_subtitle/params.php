<?php
$params[ 'align' ] = array(
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'left',
    'title' => 'Alignment',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'subtitle_preview_text' ] = array(
    'type' => 'textarea',
    'title' => 'Preview text',
    'desc' => 'In your actual post, this will be replaced by your post subtitle. However, you can enter custom text here to imagine it.',
);

$params[ 'subtitle_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-single-subtitle',
    'title' => 'Typography',
);

$params[ 'subtitle_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-single-subtitle' => 'color:{{VALUE}};',
    ],
    'title' => 'Color',
);
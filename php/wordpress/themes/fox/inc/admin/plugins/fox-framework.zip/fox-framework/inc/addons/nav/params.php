<?php
/**
 * SELECTORS
 */
$container = '{{WRAPPER}} > .elementor-widget-container ';
$w = '{{WRAPPER}} > .elementor-widget-container > .el-nav ';
$h = '{{WRAPPER}} > .elementor-widget-container > .hnav ';
$v = '{{WRAPPER}} > .elementor-widget-container > .vnav ';

$w_menu = $w . '> .nav-inner > div > ul.menu ';
$h_menu = $h . '> .nav-inner > div > ul.menu ';
$v_menu = $v . '> .nav-inner > div > ul.menu ';

$params[ 'source' ] = array(
    'type' => 'select',
    'options' => [
        'menu' => 'Menu',
        'category' => 'Categories',
        'post_tag' => 'Tags',
        'tax' => 'Custom taxonomies',
    ],
    'std' => 'menu',
    'title' => 'Source',
    
    'section' => 'general',
    'section_title' => 'General',
);

$menulist = [ '' => 'Choose your menu' ];

$all = wp_get_nav_menus();

foreach ( $all as $nav_obj ) {
    $menulist[ $nav_obj->slug ] = $nav_obj->name;
}

$params[ 'menu' ] = array(
    'type' => 'select',
    'options' => $menulist,
    'std' => '',
    'title' => 'Menu list',
    
    'condition' => [
        'source[value]' => 'menu',
    ]
);

$params[ 'taxonomy' ] = array(
    'type' => 'text',
    'placeholder' => 'Eg. product_cat',
    'title' => 'Taxonomy Slug',
    
    'condition' => [
        'source[value]' => 'tax',
    ],
);

$params[ 'number' ] = array(
    'type' => 'text',
    'title' => 'Number of items',
    'std' => '',
    'desc' => 'Leave empty to display all',
    
    'condition' => [
        'source[value]' => [ 'tax', 'category', 'post_tag' ],
    ],
);

$params[ 'orderby' ] = array(
    'type' => 'select',
    'options' => [
        'name' => 'Name',
        'slug' => 'Slug',
        'count' => 'Post count',
    ],
    'std' => 'slug',
    'title' => 'Order by',
    
    'condition' => [
        'source[value]' => [ 'tax', 'category', 'post_tag' ],
    ],
);

$params[ 'order' ] = array(
    'type' => 'select',
    'options' => [
        'asc' => 'Ascending',
        'desc' => 'Descending',
    ],
    'std' => 'asc',
    'title' => 'Order',
    
    'condition' => [
        'source[value]' => [ 'tax', 'category', 'post_tag' ],
    ],
);

/*
@todo
$params[ 'item_count' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Display item count?',
    
    'condition' => [
        'source[value]' => [ 'tax', 'category', 'post_tag' ],
    ],
);
*/

$params[ 'dir' ] = array(
    'type' => 'select',
    'options' => [
        'horizontal' => 'Horizontal',
        'vertical' => 'Vertical',
    ],
    'std' => 'horizontal',
    'title' => 'Direction',
);

$params[ 'align' ] = array(
    'type' => 'align',
    'options' => [ 'left', 'center', 'right' ],
    'title' => 'Alignment',
);

$params[ 'has_dropdown_indicator' ] = array(
    'type' => 'select',
    'options' => [
        '' => 'None',
        'angle-down' => 'Angle down',
        'caret-down' => 'Caret down',
        'plus' => 'Plus sign (+)',
    ],
    'std' => '',
    'title' => 'Dropdown indicator',
);

$params[ 'dropdown_indicator_size' ] = array(
    'type' => 'size',
    'selectors' => [
        $w_menu . '> li.menu-item-has-children > a:after' => 'font-size:{{SIZE}}{{UNIT}};',
        $w_menu . '> li.mega > a:after' => 'font-size:{{SIZE}}{{UNIT}};',
    ],
    'title' => 'Dropdown indicator size',
    
    'std_unit' => 'px',
    'std_size' => 14,
    'px_max' => 20,
    'px_min' => 9,
);

$params[ 'dropdown_indicator_color' ] = array(
    'type' => 'color',
    'selectors' => [
        $w_menu . ' > li.menu-item-has-children > a:after' => 'color:{{VALUE}};',
        $w_menu . '> li.mega > a:after' => 'color:{{VALUE}};',
    ],
    'title' => 'Dropdown indicator color',
);


$params[ 'item_hover_effect' ] = array(
    'type' => 'select',
    'options' => [
        '' => 'None',
        'border_top' => 'Border top',
        'border_bottom' => 'Border bottom',
    ],
    'std' => '',
    'title' => 'Item Hover Effect',
    'condition' => [
        'dir[value]' => 'horizontal',
    ],
);

$params[ 'item_hover_effect_border_width' ] = array(
    'type' => 'size',
    'title' => 'Hover border thickness',
    
    'std_unit' => 'px',
    'std_size' => 3,
    'px_max' => 30,
    'px_min' => 1,
    
    'selectors' => [
        $container . '> .style-hover-border_top.hnav > .nav-inner > div > ul.menu > li > a:before' => 'height:{{SIZE}}{{UNIT}};',
        $container . '> .style-hover-border_bottom.hnav > .nav-inner > div > ul.menu > li > a:before' => 'height:{{SIZE}}{{UNIT}};',
    ],
    
    'condition' => [
        'dir[value]' => 'horizontal',
        'item_hover_effect' => [ 'border_top', 'border_bottom' ]
    ],
);

$params[ 'item_hover_effect_border_color' ] = array(
    'type' => 'color',
    'title' => 'Hover border color',
    
    'selectors' => [
        $container . '> .style-hover-border_top.hnav > .nav-inner > div > ul.menu > li > a:before' => 'background:{{VALUE}};',
        $container . '> .style-hover-border_bottom.hnav > .nav-inner > div > ul.menu > li > a:before' => 'background:{{VALUE}};',
    ],
    
    'condition' => [
        'dir[value]' => 'horizontal',
        'item_hover_effect' => [ 'border_top', 'border_bottom' ]
    ],
);

/* Item
------------------------ */
$params[ 'item_typography' ] = array(
    'type' => 'typography',
    'title' => 'Item Typography',
    'selector' => $w_menu . '> li > a',
    
    'section' => 'item',
    'section_title' => 'Menu Item',
    'section_tab' => 'style',
    
    'tabs' => 'item',
    'tab' => 'item_normal',
    'tab_title' => 'Normal',
);

$params[ 'item_spacing' ] = array(
    'type' => 'size',
    'title' => 'Item Spacing',
    'std_unit' => 'px',
    'std_size' => 5,
    'px_max' => 50,
    'px_min' => 0,
    'selectors' => [
        $w_menu . '> li > a' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
    ]
);

$params[ 'hnav_item_sep_between' ] = array(
    'type' => 'switcher',
    'title' => 'Separator between items',
    'std' => 'no',
    'condition' => [
        'dir[value]' => 'horizontal',
    ]
);

$params[ 'hnav_item_sep_color' ] = array(
    'type' => 'color',
    'title' => 'Separator color',
    'selectors' => [
        $container . '> .hnav.style-has-sep-between > .nav-inner > div > ul.menu > li + li > a > .mk' => 'border-color:{{VALUE}};',    
    ],
    'condition' => [
        'dir[value]' => 'horizontal',
    ]
);

$params[ 'item_color' ] = array(
    'type' => 'color',
    'title' => 'Item Color',
    'selectors' => [
        $w_menu . '> li > a' => 'color: {{VALUE}};',    
    ],
);

$params[ 'item_background' ] = array(
    'type' => 'color',
    'title' => 'Item background',
    'selectors' => [
        $w_menu . '> li > a' => 'background: {{VALUE}};',    
    ],
);

$params[ 'item_border_width' ] = array(
    'type' => 'size',
    'title' => 'Item border width',
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 5,
    'px_min' => 0,
    'selectors' => [
        $w_menu . '> li > a' => 'border-width: {{SIZE}}{{UNIT}};',
        $v_menu . '> li + li' => 'margin-top: -{{SIZE}}{{UNIT}};',
        // $h_menu . '> li + li' => 'margin-left: -{{SIZE}}{{UNIT}};',
        
    ],
);

$params[ 'item_border_color' ] = array(
    'type' => 'color',
    'title' => 'Item border color',
    'selectors' => [
        $w_menu . '> li > a' => 'border-color: {{VALUE}};',
    ],
);

$params[ 'item_sep_width' ] = array(
    'type' => 'size',
    'title' => 'Item seperator width',
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 5,
    'px_min' => 0,
    
    'selectors' => [
        $v_menu . '> li + li' => 'border-width: {{SIZE}}{{UNIT}};',
    ],
    'condition' => [
        'dir[value]' => 'vertical',
    ]
);

$params[ 'item_sep_color' ] = array(
    'type' => 'color',
    'title' => 'Item seperator color',
    'selectors' => [
        $v_menu . '> li + li' => 'border-color: {{VALUE}};',
    ],
    'condition' => [
        'dir[value]' => 'vertical',
    ]
);

$params[] = [
    'type' => 'tab_close',
];

// hover
$params[ 'item_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Item Hover Color',
    'selectors' => [
        $w_menu . '> li:hover > a' => 'color: {{VALUE}};',    
    ],
    
    'tab' => 'item_hover',
    'tab_title' => 'Hover',
);

$params[ 'item_hover_bg' ] = array(
    'type' => 'color',
    'title' => 'Item hover background',
    'selectors' => [
        $w_menu . '> li:hover > a' => 'background: {{VALUE}};',    
    ],
);

$params[ 'item_hover_border_color' ] = array(
    'type' => 'color',
    'title' => 'Item hover border',
    'selectors' => [
        $w_menu . '> li:hover > a' => 'border-color: {{VALUE}};',    
    ],
);

$params[] = [
    'type' => 'tab_close',
];

// current
$params[ 'item_current_color' ] = array(
    'type' => 'color',
    'title' => 'Current item color',
    'selectors' => [
        $w_menu . '> li.current-menu-item > a' => 'color: {{VALUE}};',    
    ],
    
    'tab' => 'current',
    'tab_title' => 'Current',
);

$params[ 'item_current_bg' ] = array(
    'type' => 'color',
    'title' => 'Current item background',
    'selectors' => [
        $w_menu . '> li.current-menu-item > a' => 'background: {{VALUE}};',
    ],
);

$params[ 'item_current_border_color' ] = array(
    'type' => 'color',
    'title' => 'Current item border',
    'selectors' => [
        $w_menu . '> li.current-menu-item > a' => 'border-color: {{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[] = [
    'type' => 'tabs_close',
];

// dropdown
$params[ 'dropdown_position' ] = array(
    'type' => 'align',
    'title' => 'Dropdown position',
    'condition' => [
        'dir[value]' => 'horizontal',
    ],
    
    'options' => [ 'left', 'right' ],
    'prefix_class' => 'dropdown-align-',
    'std' => 'left',
    
    'section' => 'dropdown',
    'section_title' => 'Dropdown',
    'section_tab' => 'style',
);

// dropdown
$params[ 'dropdown_width' ] = array(
    'type' => 'size',
    'title' => 'Dropdown Width',
    'std_unit' => 'px',
    'std_size' => 180,
    'selectors' => [
        $h_menu . '> li > ul' => 'width: {{SIZE}}{{UNIT}};',
        $h_menu . '> li > ul > li > ul' => 'width: {{SIZE}}{{UNIT}};',
        $h_menu . '> li > ul > li > ul > li > ul' => 'width: {{SIZE}}{{UNIT}};',
    ],
    
    'condition' => [
        'dir[value]' => 'horizontal',
    ],
);

$params[ 'dropdown_align' ] = array(
    'type' => 'select',
    'title' => 'Dropdown Alignment',
    'options' => [
        'left' => 'Left',
        'center' => 'Center',
        'right' => 'Right',
    ],
    'std' => 'left',
);

$params[ 'dropdown_padding' ] = array(
    'type' => 'size',
    'title' => 'Dropdown padding',
    'std_unit' => 'px',
    'std_size' => 10,
    
    'px_min' => 0,
    'px_max' => 30,
    
    'selectors' => [
        $h_menu . '> li > ul' => 'padding: {{SIZE}}{{UNIT}};',
        $h_menu . '> li > ul > li > ul' => 'padding: {{SIZE}}{{UNIT}};',
        $h_menu . '> li > ul > li > ul > li > ul' => 'padding: {{SIZE}}{{UNIT}};',
    ],
);

$params[ 'dropdown_background' ] = array(
    'type'  => 'color',
    'title' => 'Dropdown background',
    'std'   => '#ffffff',
    'selectors' => [
        $w_menu . '> li > ul' => 'background: {{VALUE}};',
        $w_menu . '> li > ul > li > ul' => 'background: {{VALUE}};',
        $w_menu . '> li > ul > li > ul > li > ul' => 'background: {{VALUE}};',
    ],
);

$params[ 'dropdown_border_width' ] = array(
    'type'  => 'size',
    'title' => 'Dropdown border width',
    'selectors' => [
        $h_menu . '> li > ul' => 'border-width:{{SIZE}}{{UNIT}};',
        $h_menu . '> li > ul > li > ul' => 'border-width:{{SIZE}}{{UNIT}};',
        $h_menu . '> li > ul > li > ul > li > ul' => 'border-width:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 6,
    'px_min' => 0,
    
    'condition' => [
        'dir[value]' => 'horizontal',
    ],
);

$params[ 'dropdown_border_color' ] = array(
    'type'  => 'color',
    'title' => 'Dropdown border color',
    'std'   => '#ffffff',
    'selectors' => [
        $h_menu . '> li > ul' => 'border-color:{{VALUE}};',
        $h_menu . '> li > ul > li > ul' => 'border-color:{{VALUE}};',
        $h_menu . '> li > ul > li > ul > li > ul' => 'border-color:{{VALUE}};',
    ],
    
    'condition' => [
        'dir[value]' => 'horizontal',
    ],
);

$params[ 'dropdown_item_padding' ] = array(
    'type' => 'size',
    'title' => 'Item Padding',
    'std_unit' => 'px',
    'std_size' => 10,
    'px_max' => 50,
    'px_min' => 0,
    'selectors' => [
        $w_menu . '>li > ul > li > a' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
        $w_menu . '>li > ul > li > ul > li > a' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
    ],
    
    'tabs' => 'dropdown',
    'tab' => 'dropdown_item',
    'tab_title' => 'Normal',
);

$params[ 'dropdown_item_typography' ] = array(
    'type' => 'typography',
    'title' => 'Dropdown item typography',
    'selector' => $w_menu . '>li > ul > li > a, ' . $w_menu . '>li > ul > li > ul > li > a, ' . $w_menu . '>li > ul > li > article .post-nav-item-title',
);

$params[ 'dropdown_item_color' ] = array(
    'type' => 'color',
    'title' => 'Dropdown item color',
    'selectors' => [
        $w_menu . '>li > ul > li > a, ' . $w_menu . '>li > ul > li > ul > li > a, ' . $w_menu . '>li > ul > li > article .post-nav-item-title' => 'color: {{VALUE}};'
    ],
);

// separator
// dropdown
$params[ 'dropdown_item_sep_size' ] = array(
    'type' => 'size',
    'title' => 'Item sep size',
    'std_unit'  => 'px',
    'std_size'  => 0,
    'px_min'    => 0,
    'px_max'    => 5,
    'selectors' => [
        $w_menu . '>li > ul > li + li' => 'border-top-width: {{SIZE}}{{UNIT}};',
        $w_menu . '>li > ul > li > ul > li + li' => 'border-top-width: {{SIZE}}{{UNIT}};',
    ],
);

$params[ 'dropdown_item_sep_color' ] = array(
    'type' => 'color',
    'title' => 'Item sep color',
    'selectors' => [
        $w_menu . '>li > ul > li + li' => 'border-top-color: {{COLOR}};',
        $w_menu . '>li > ul > li > ul > li + li' => 'border-top-color: {{COLOR}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

// hover
$params[ 'dropdown_item_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Dropdown item hover color',
    'selectors' => [
        $w_menu . '>li > ul > li > a:hover' => 'color:{{VALUE}};',
        $w_menu . '>li > ul > li > ul > li > a:hover' => 'color:{{VALUE}};',
    ],
    
    'tab' => 'dropdown_item_hover',
    'tab_title' => 'Hover',
);

$params[ 'dropdown_item_hover_bg' ] = array(
    'type' => 'color',
    'title' => 'Dropdown item hover background',
    'selectors' => [
        $w_menu . '>li > ul > li > a:hover' => 'background:{{VALUE}};',
        $w_menu . '>li > ul > li > ul > li > a:hover' => 'background:{{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

// current
$params[ 'dropdown_item_current_color' ] = array(
    'type' => 'color',
    'title' => 'Dropdown current item color',
    'selectors' => [
        $w_menu . '>li > ul > li.current-menu-item > a' => 'color:{{VALUE}};',
        $w_menu . '>li > ul > li > ul > li.current-menu-item > a' => 'color:{{VALUE}};',
    ],
    
    'tab' => 'dropdown_item_current',
    'tab_title' => 'Current',
);

$params[ 'dropdown_item_current_bg' ] = array(
    'type' => 'color',
    'title' => 'Dropdown current item background',
    'selectors' => [
        $w_menu . '>li > ul > li.current-menu-item > a' => 'background:{{VALUE}};',
        $w_menu . '>li > ul > li > ul > li.current-menu-item > a' => 'background:{{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[] = [
    'type' => 'tabs_close',
];
<?php
$settings = $this->get_settings_for_display();        
$settings[ 'layout' ] = 'list';

extract( wp_parse_args( $settings, [
    
    'column' => '1',
    'first_standard' => 'no', // this is a big option
    
    'pagination' => '',
    'layout' => 'list',
    'item_template' => '1',
    
    // spacing
    'list_spacing_type' => 'predefined',
    'list_spacing' => 'normal',
    
    // component params
    'show_thumbnail' => '',
    'show_title' => '',
    'show_date' => '',
    'show_category' => '',
    'show_author' => '',
    'show_author_avatar' => '',
    'show_excerpt' => '',
    'show_excerpt_more' => '',
    'show_view' => '',
    'show_reading_time' => '',
    'show_comment_link' => '',

    // thumbnail options
    'thumbnail' => 'landscape',
    'thumbnail_custom' => '',
    'thumbnail_placeholder' => true,
    'thumbnail_placeholder_id' => '',
    'thumbnail_shape' => '',
    'thumbnail_hover' => '',
    'thumbnail_hover_logo' => '',
    'thumbnail_showing_effect' => '',

    'thumbnail_format_indicator' => '',
    'thumbnail_index' => '',
    'thumbnail_view' => '',
    'thumbnail_review_score' => '',

    'thumbnail_extra_class' => '',

    // since 4.6.7
    'thumbnail_caption' => '', // show caption or not in case the thumbnail has caption
    'thumbnail_order' => '', // if 'after' then display the thumbnail after post content

    // title options
    'title_tag' => '',
    'title_size' => '', // legacy
    'title_weight' => '', // legacy

    // excerpt options
    'excerpt_length' => 22,
    'excerpt_size' => '', // legacy
    'excerpt_hellip' => '',
    'excerpt_more' => '',
    'excerpt_more_style' => '',
    'excerpt_more_text' => '',

    // extra
    'extra_class' => '', // legacy
    
    // misc
    'thumbnail_youtube_player' => 'no',
    
]) );

// no posts found
// don't waste my time
$query = foxfw3_query( $settings );
if ( ! $query ) {
    return;
}

if ( isset( $settings[ 'source' ] ) && 'archive' == $settings[ 'source' ] ) {
    $pagination = 'yes';
}

if ( ! $query->have_posts() ) {
    wp_reset_query();
    return;
}

$container_cl = [ 'blog-container', 'blog-container-list' ];
$cl = [ 'wi-blog', 'fox-blog', 'blog-list' ];

/* column
-------------------------------------- */
$column = absint( $column );
if ( $column < 1 || $column > 4 ) {
    $column = 1;
}
$cl[] = 'column-'. $column;
if ( $column > 1 ) {
    $cl[] = 'columnized';
} else {
    $cl[] = 'nocolumn';
}
    
/* first standard
-------------------------------------- */
if ( $first_standard == 'yes' ) {
    $cl[] = 'has-standard-first';
}

/* extra class
-------------------------------------- */
if ( $extra_class ) {
    $cl[] = $extra_class;
}

/* item spacing
-------------------------------------- */
if ( 'predefined' == $list_spacing_type ) {
    $cl[] = 'spacing-predefined';
    if ( ! in_array( $list_spacing, [ 'none', 'tiny', 'small', 'normal', 'medium', 'wide', 'wider' ] ) ) {
        $item_spacing = 'normal';
    }
    $cl[] = 'v-spacing-' . $list_spacing;
} else {
    $cl[] = 'v-spacing-custom';
}

/* youtube player
-------------------------------------- */
if ( 'yes' == $thumbnail_youtube_player ) {
    $cl[] = 'behavior-thumbnail-youtube-player';
}
?>

<div class="<?php echo esc_attr( join( ' ', $container_cl ) ); ?>">
    
    <div class="<?php echo esc_attr( join( ' ', $cl ) ); ?>">
    
    <?php 
    $count = 0;
    while ( $query->have_posts() ) {
        
        $query->the_post();
        $count++;
        
        $settings[ 'count' ] = $count;
        
        if ( 'yes' == $first_standard && 1 == $count ) {
            
            $copy_settings = $settings;
            foreach ( $copy_settings as $k => $v ) {
                if ( false !== strpos( $k, 'standard_' ) ) {
                    $k_without_standard = str_replace( 'standard_', '', $k );
                    $settings[ $k_without_standard ] = $v;
                }
            }
            include FOX_FRAMEWORK_PATH . 'content/post-standard.php';
            
            // now restore it
            $settings = $copy_settings;
            
        } else {
            
            // since 5.4
            if( isset( $settings[ 'disable_thumbnail_after_first' ] ) && 'yes' == $settings[ 'disable_thumbnail_after_first' ] && $count >= 2 ) {
                $settings[ 'show_thumbnail' ] = false;
            }

            include FOX_FRAMEWORK_PATH . 'content/post-list.php';
        }
        
        do_action( 'fox_after_render_post' );
        
    } ?>
        
    </div><!-- .fox-blog -->
    
    <?php if ( 'yes' == $pagination ) { foxfw3_pagination( $query ); } ?>
    
</div><!-- .fox-blog-container -->

    <?php

wp_reset_query();
<?php
$text_types = [
    'text', 'email', 'password', 'search', 'number', 'date', 'tel', 'url',
];
$input = [];
$input_focus = [];
foreach ( $text_types as $text_type ) {
    $input[] = '{{WRAPPER}} input[type="' . $text_type . '"]';
    $input_focus[] = '{{WRAPPER}} input[type="' . $text_type . '"]:focus';
}

$input_withoutarea = join( ',', $input );
$input = $input_withoutarea . ',{{WRAPPER}} textarea';
$input_focus = join( ',', $input_focus );

$button = '{{WRAPPER}} button,{{WRAPPER}} input[type="submit"]';
$button_hover = '{{WRAPPER}} button:hover,{{WRAPPER}} input[type="submit"]:hover';

/* GENERAL
------------------------------------------------------------------------ */
$params[ 'type' ] = array(
    'type' => 'select',
    'title' => 'Which form?',
    'options'    => [
        'wpcf7'         => 'Contact Form 7',
        'mc4wp'     => 'Mailchimp Newsletter',
        'custom'        => 'Custom form',
    ],
    'std' => 'wpcf7',
    
    'section' => 'general',
    'section_title' => 'General',
);

/* Contact Form 7
--------------------------- */
$form_list = [ 0 => 'Choose Contact Form' ];
if ( post_type_exists( 'wpcf7_contact_form' ) ) {
    
    $form_posts = get_posts(array(
        'post_type'     => 'wpcf7_contact_form',
        'numberposts'   => 100,
    ));
    foreach ( $form_posts as $p ) {
        $form_list[$p->ID] = $p->post_title . ' (' . $p->ID . ')';
    }
    
} else {
    
    $form_list[ '' ] = 'You must install Contact Form 7 first';
    
}

$params[ 'wpcf7_id' ] = array(
    'type' => 'select',
    'title' => 'Choose the contact form',
    'options' => $form_list,
    'std' => 0,
    
    'condition' => [
        'type[value]' => 'wpcf7',
    ],
);

/* Mailchimp
--------------------------- */
$form_list = [ 0 => 'Choose Mailchimp Form' ];
$get_forms = get_posts( [
    'post_type' => 'mc4wp-form',
    'posts_per_page' => 100,
] );

foreach ( $get_forms as $p ) {
    $form_list[$p->ID] = $p->post_title . ' (' . $p->ID . ')';
}

$params[ 'mc4wp_id' ] = array(
    'type' => 'select',
    'title' => 'Choose the newsletter form',
    'options' => $form_list,
    'std' => 0,
    
    'condition' => [
        'type[value]' => 'mc4wp',
    ],
);

$params[ 'mc4wp_layout' ] = array(
    'type' => 'select',
    'title' => 'Layout',
    'options' => [
        'stack' => 'Stack',
        'inline' => 'Inline',
    ],
    'std' => 'stack',
    
    'condition' => [
        'type[value]' => 'mc4wp',
    ],
);

$params[ 'mc4wp_input_width' ] = array(
    'type' => 'size',
    'title' => 'Input width',
    
    'px_min' => 100,
    'px_max' => 800,
    
    'std_unit' => 'px',
    'std_size' => 320,
    
    'selectors' => [
        '.el-form-inline .mc4wp-form-fields input[type="text"], .el-form-inline .mc4wp-form-fields input[type="email"], .el-form-inline .mc4wp-form-fields input[type="url"], .el-form-inline .mc4wp-form-fields input[type="tel"]' => 'width: {{SIZE}}{{UNIT}};',
    ],
    
    'condition' => [
        'type[value]' => 'mc4wp',
        'mc4wp_layout[value]' => 'inline',
    ],
);

$params[ 'mc4wp_inline_spacing' ] = array(
    'type' => 'size',
    'title' => 'Spacing',
    
    'px_min' => 0,
    'px_max' => 100,
    
    'std_unit' => 'px',
    'std_size' => 10,
    
    'selectors' => [
        '.el-form-inline .mc4wp-form-fields p' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};',
    ],
    
    'condition' => [
        'type[value]' => 'mc4wp',
        'mc4wp_layout[value]' => 'inline',
    ],
);

/* Custom Form Shortcode
--------------------------- */
$params[ 'custom_form_shortcode' ] = array(
    'type' => 'textarea',
    'title' => 'Enter the shortcode of your custom form',
    
    'condition' => [
        'type[value]' => 'custom',
    ],
);

/* INPUT
------------------------------------------------------------------------ */
$params[ 'input_typography' ] = array(
    'type' => 'typography',
    'title' => 'Input typography',
    'selector' => $input,
    
    // style
    'section' => 'input',
    'section_title' => 'Input Style',
    'section_tab' => 'style',
);

$params[ 'input_height' ] = array(
    'type' => 'size',
    'title' => 'Input height',
    
    'px_min' => 10,
    'px_max' => 100,
    
    'std_unit' => 'px',
    'std_size' => 40,
    
    'selectors' => [
        $input_withoutarea => 'height: {{SIZE}}{{UNIT}};'
    ],
);

$params[ 'input_color' ] = array(
    'type' => 'color',
    'title' => 'Input text color',
    'selectors' => [
        $input => 'color: {{VALUE}};',
    ],
    
    // tab
    'tab' => 'input_normal',
    'tab_title' => 'Normal',
    'tabs'     => 'input',
);

$params[ 'input_bg' ] = array(
    'type' => 'color',
    'title' => 'Input background color',
    'selectors' => [
        $input => 'background-color: {{VALUE}};',
    ],
);

$params[ 'input_border_color' ] = array(
    'type' => 'color',
    'title' => 'Input border color',
    'selectors' => [
        $input => 'border-color: {{VALUE}};',
    ],
);

$params[ 'input_border_width' ] = array(
    'type' => 'size',
    'title' => 'Input border size',
    'px_min' => 0,
    'px_max' => 10,
    
    'std_unit' => 'px',
    'std_size' => 1,
    
    'selectors' => [
        $input => 'border-width: {{SIZE}}{{UNIT}};',
    ],
);

$params[ 'input_border_radius' ] = array(
    'type' => 'size',
    'title' => 'Input border radius',
    'px_min' => 0,
    'px_max' => 50,
    
    'std_unit' => 'px',
    'std_size' => 0,
    
    'selectors' => [
        $input => 'border-radius: {{SIZE}}{{UNIT}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[ 'input_fucus_color' ] = array(
    'type' => 'color',
    'title' => 'Input focus text color',
    'selectors' => [
        $input_focus => 'color: {{VALUE}};',
    ],
    
    // tab
    'tab' => 'input_focus',
    'tab_title' => 'Focus',
);

$params[ 'input_focus_bg' ] = array(
    'type' => 'color',
    'title' => 'Input focus background color',
    'selectors' => [
        $input_focus => 'background-color: {{VALUE}};',
    ],
);

$params[ 'input_focus_border_color' ] = array(
    'type' => 'color',
    'title' => 'Input focus border color',
    'selectors' => [
        $input_focus => 'border-color: {{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[] = [
    'type' => 'tabs_close',
];

/* BUTTON
------------------------------------------------------------------------ */
$params[ 'btn_typography' ] = array(
    'type' => 'typography',
    'title' => 'Button typography',
    'selector' => $button,
    
    // style
    'section' => 'button',
    'section_title' => 'Button Style',
    'section_tab' => 'style',
);

$params[ 'btn_color' ] = array(
    'type' => 'color',
    'title' => 'Button text color',
    'selectors' => [
        $button => 'color:{{VALUE}};',
    ],
    
    // tab
    'tab' => 'button_normal',
    'tab_title' => 'Normal',
    'tabs'     => 'button',
);

$params[ 'btn_bg' ] = array(
    'type' => 'color',
    'title' => 'Button background',
    'selectors' => [
        $button => 'background:{{VALUE}};',
    ],
);

$params[ 'btn_border_color' ] = array(
    'type' => 'color',
    'title' => 'Button border color',
    'selectors' => [
        $button => 'border-color:{{VALUE}};',
    ],
);

$params[ 'btn_padding' ] = array(
    'type' => 'size',
    'title' => 'Button padding',
    'px_min' => 0,
    'px_max' => 150,
    
    'std_unit' => 'px',
    'std_size' => 20,
    
    'selectors' => [
        $button => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};',
    ],
);

$params[ 'btn_border_width' ] = array(
    'type' => 'size',
    'title' => 'Button border size',
    'px_min' => 0,
    'px_max' => 10,
    
    'std_unit' => 'px',
    'std_size' => 0,
    
    'selectors' => [
        $button => 'border-width: {{SIZE}}{{UNIT}};',
    ],
);

$params[ 'btn_border_radius' ] = array(
    'type' => 'size',
    'title' => 'Button border radius',
    'px_min' => 0,
    'px_max' => 50,
    
    'std_unit' => 'px',
    'std_size' => 0,
    
    'selectors' => [
        $button => 'border-radius: {{SIZE}}{{UNIT}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[ 'btn_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Button hover color',
    'selectors' => [
        $button_hover => 'color: {{VALUE}};',
    ],
    
    // tab
    'tab' => 'button_hover',
    'tab_title' => 'Hover',
);

$params[ 'btn_hover_bg' ] = array(
    'type' => 'color',
    'title' => 'Button hover background',
    'selectors' => [
        $button_hover => 'background: {{VALUE}};',
    ],
);

$params[ 'btn_hover_border_color' ] = array(
    'type' => 'color',
    'title' => 'Button hover border color',
    'selectors' => [
        $button_hover => 'border-color: {{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[] = [
    'type' => 'tabs_close',
];

/* FORM
------------------------------------------------------------------------ */
$params[ 'label_typography' ] = array(
    'type' => 'typography',
    'title' => 'Label typography',
    'selector' => '{{WRAPPER}} label',
    
    // style
    'section' => 'form',
    'section_title' => 'Form Style',
    'section_tab' => 'style',
);

$params[ 'label_color' ] = array(
    'type' => 'color',
    'title' => 'Label color',
    'selectors' => [
        '{{WRAPPER}} label' => 'color: {{VALUE}};',
    ],
);

$params[ 'legend_typography' ] = array(
    'type' => 'typography',
    'title' => 'Heading typography',
    'selector' => '{{WRAPPER}} legend',
);

$params[ 'legend_color' ] = array(
    'type' => 'color',
    'title' => 'Heading color',
    'selectors' => [
        '{{WRAPPER}} legend' => 'color: {{VALUE}};',
    ],
);

// we exclude for wpcf7 because we can remove ourself label/placeholder of the form
$params[ 'label' ] = array(
    'type' => 'switcher',
    'title' => 'Label',
    'std' => 'yes',
    
    'condition' => [
        'type[value]' => [ 'reservation', 'custom' ],
    ],
);

$params[ 'placeholder' ] = array(
    'type' => 'switcher',
    'title' => 'Placeholder',
    'std' => 'yes',
    
    'condition' => [
        'type[value]' => [ 'reservation', 'custom' ],
    ],
);
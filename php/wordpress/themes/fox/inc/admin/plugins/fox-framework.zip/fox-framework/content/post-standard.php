<?php
// since 4.4.4 we have fox-grid-item for 1st standard post
$post_class = [
    'wi-post',
    'post-item',
    'post-standard',
    'fox-grid-item'
];

/* Drop cap
-------------------------- *
$drop_cap = get_post_meta( get_the_ID(), '_wi_blog_dropcap', true );
if ( ! $drop_cap ) {
    $drop_cap = $settings[ 'standard_dropcap' ] ? 'true' : 'false';
}
if ( 'true' == $drop_cap ) {
    $post_class[] = 'enable-dropcap';
} else {
    $post_class[] = 'disable-dropcap';
}

/* Column
-------------------------- *
$text_column = $settings[ 'standard_column_layout' ];
if ( 2 == $text_column ) {
    $post_class[] = 'enable-2-columns';
}

/**
 * more align
 *
$more_align = get_theme_mod( 'wi_standard_excerpt_more_align', 'center' );
$post_class[] = 'standard-more-align-' . $more_align;

/* Order
-------------------------- */
$thumbnail_header_order = isset( $settings[ 'thumbnail_header_order' ] ) ? $settings[ 'thumbnail_header_order' ] : 'thumbnail';
if ( 'thumbnail' != $thumbnail_header_order ) {
    $thumbnail_header_order = 'header';
}

/* Header HTML
------------------------------------------------ */
ob_start();
/**
 * header align
 */
$h_align = isset( $settings[ 'header_align' ] ) ? $settings[ 'header_align' ] : '';
if ( 'right' != $h_align && 'center' != $h_align ) {
    $h_align = 'left';
}
$post_class[] = 'post-header-align-' . $h_align;
$header_class = [ 'post-header', 'align-' . $h_align ];

/**
 * custom args
 */
$header_args = $settings;
$header_args[ 'date_fashion' ] = 'long';
$header_args[ 'title_extra_class' ] = 'post-title';
$header_args[ 'meta_extra_class' ] = 'post-header-meta post-standard-meta';
$header_args[ 'show_excerpt' ] = false; // disable excerpt here so that we can add it manually here
// $header_args[ 'excerpt_more' ] = $settings[ 'standard_excerpt_more' ];
// $header_args[ 'excerpt_more_style' ] = $settings[ 'standard_excerpt_more_style' ];
// $header_args[ 'excerpt_length' ] = $settings[ 'standard_excerpt_length' ];
?>
<header class="<?php echo esc_attr( join( ' ', $header_class ) ); ?>">
    
    <?php
    if ( is_engine_v6() ) {
        foxfw3_elementor_post_body( $header_args );
    } else {
        fox_elementor_post_body( $header_args );
    }
    ?>
    
</header><!-- .post-header -->
<?php
$header_html = ob_get_clean();

/* Thumbnail HTML
------------------------------------------------ */
ob_start();
$thumbnail_args = $settings;

$thumbnail_args[ 'thumbnail_extra_class' ] = ' post-thumbnail';
$thumbnail_args[ 'thumbnail' ] = 'original'; // thumbnail must be original
$thumbnail_args[ 'thumbnail_placeholder' ] = false; // and no placeholder
$thumbnail_args[ 'thumbnail_width' ] = ''; // make it safe

if ( isset( $settings[ 'show_thumbnail' ] ) && 'yes' == $settings[ 'show_thumbnail' ] ) {
    foxfw3_elementor_thumbnail( $thumbnail_args );
}
$thumbnail_html = ob_get_clean();

/* Content HTML
------------------------------------------------ */
ob_start();
if ( isset( $settings[ 'display_excerpt' ] ) && 'yes' == $settings[ 'display_excerpt' ] ) {
    if ( isset( $settings[ 'content_excerpt' ] ) && 'excerpt' == $settings[ 'content_excerpt' ] ) { ?>

        <div class="entry-excerpt">

            <?php
                if ( is_engine_v6() ) {
                    fox56_excerpt( $settings );
                } else {
                    if ( function_exists('fox_post_excerpt' ) ) {
                        fox_post_excerpt( $settings ); 
                    }
                }
                ?>

        </div><!-- .entry-excerpt -->

    <?php } else { ?>

        <div class="entry-content dropcap-content columnable-content" itemprop="text">

            <?php 
                // .post-more class is just a legacy
                if ( function_exists( 'fox_word' ) ) {
                    $more_text = fox_word( 'more_link' );
                } else {
                    $more_text = 'Continue Reading';
                }
                the_content( '<span class="post-more">' . $more_text . '</span>' );

                if ( is_engine_v6() ) {
                    fox56_page_links();
                } else {
                    if ( function_exists( 'fox_page_links' ) ) {
                        fox_page_links();
                    }
                }
            ?>

        </div><!-- .entry-content -->

    <?php }
}
$content_html = ob_get_clean();
?>

<article <?php post_class( $post_class ); ?> itemscope itemtype="https://schema.org/CreativeWork">
    
    <?php if ( isset( $settings[ 'sep' ] ) && 'yes' == $settings[ 'sep' ] ) { ?>
    <div class="post-sep"></div>
    <?php } ?>
    
    <div class="post-body post-item-inner post-standard-inner">
        
        <?php
    
            if ( 'header' == $thumbnail_header_order ) {
                echo $header_html . $thumbnail_html;
            } else {
                echo $thumbnail_html;
            } ?>
        
        <div class="post-standard-text-outer">
        
            <div class="post-standard-text">

                <?php 
                if ( 'header' != $thumbnail_header_order ) {
                    echo $header_html;
                } ?>

                <div class="post-content">

                <?php echo $content_html; ?>

                </div><!-- .post-content -->

                <?php if ( 'yes' == $settings[ 'show_share' ] ) {
                    if ( is_engine_v6() ) {
                        fox56_share();
                    } else {
                        if ( function_exists( 'fox_share' ) ) {
                            fox_share();
                        }
                    }
                } ?>
                <?php if ( 'yes' == $settings[ 'show_related' ] ) {
                    if ( is_engine_v6() ) {
                        // do nothing here
                    } else {
                        if ( function_exists( 'fox_blog_related' ) ) {
                            fox_blog_related( 'standard', [ 'number' => 3 ]);
                        }
                    }
                } ?>

            </div><!-- .post-standard-text -->
            
        </div><!-- .post-standard-text-outer -->
        
    </div><!-- .post-body -->

</article><!-- .post-standard -->
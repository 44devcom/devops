<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'link_style' => '',
]) );

$cl = [ 'el-single-content', 'allow-stretch-full', 'allow-stretch-bigger' ];

/* link style
------------------------ */
if ( $link_style ) {
    $link_style = absint( $link_style );
    if ( $link_style < 1 || $link_style > 4 ) {
        $link_style = 1;
    }
    $cl[] = 'style--link-' . $link_style;
}

/* final
------------------------ */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <div class="article-content">
    
        <?php if ( fox_is_edit() || ( is_singular( 'elementor_library' ) ) ) { ?>

        <p>Mavik Banner: physician; scientist. Searching for a way to tap into the hidden strengths that all humans have… then an accidental overdose of gamma radiation alters his body chemistry. <a href="#">And now when</a> David Banner grows angry or outraged, a startling metamorphosis occurs. The creature is driven by rage and pursued by an investigative reporter. The creature is wanted for a murder he didn’t commit. <a href="#">David Banner</a> is believed to be dead, and he must let the world think that he is dead, until he can find a way to control the raging spirit that dwells within him.</p>

        <blockquote class="wp-block-quote">
            <p>Moore’s law is the observation that the number of transistors in a dense integrated circuit (IC) doubles about every two years. Moore’s law is an observation and projection of a historical trend. Rather than a law of physics, it is an empirical relationship linked to gains from experience in production.</p>
            <cite>Wikipedia</cite>
        </blockquote>

        <h2>Being evil has a price</h2>

        <div class="wp-block-image">
            <figure class="alignleft size-medium">
                <img src="<?php echo FOX_ELEMENTOR_URL; ?>images/content-image1.jpg" alt="Content image" width="300" />
            </figure>
        </div>

        <p>I bet we been together for a million years, And I bet we’ll be together for a million more. Oh, It’s like I started breathing on the night <a href="#">we kissed</a>, and I can’t remember what I ever did before. What would we do baby, without us? What would we do baby, without us? And there ain’t no nothing we can’t love each other through. What would we do baby, without us? <a href="#">Sha la la la</a>.</p>

        <p>
            Here’s the story of a lovely lady, who was bringing up three very lovely girls. All of them had hair of gold, like their mother, the youngest one in curls. <a href="#">Here’s the store</a>, of a man named Brady, who was busy with three boys of his own. They were four men, yet they were all alone. ‘Til the one day when the lady met this fellow. And they knew it was much more than a hunch, that this group would somehow form a family. That’s the way we all became the Brady Bunch, the Brady Bunch. That’s the way we all became the <a href="#">Brady Bunch</a>.

        </p>

        <h3>Who can turn the world on with her smile</h3>

        <div class="wp-block-image">
            <figure class="alignright size-medium">
                <a href="<?php echo FOX_ELEMENTOR_URL; ?>images/content-image2.jpg">
                    <img src="<?php echo FOX_ELEMENTOR_URL; ?>images/content-image2.jpg" alt="Content image" width="300" />
                </a>
                <figcaption class="wp-element-caption">Here’s the story of a lovely lady</figcaption>
            </figure>
        </div>

        <p>
            Here’s the story of a lovely lady, who was bringing up three very lovely girls. All of them had hair of gold, like their mother, the youngest one in curls. <a href="#">Here’s the store</a>, of a man named Brady, who was busy with three boys of his own. They were four men, yet they were all alone. ‘Til the one day when the lady met this fellow. And they knew it was much more than a hunch, that this group would somehow form a family. That’s the way we all became the Brady Bunch, the Brady Bunch. That’s the way we all became the <a href="#">Brady Bunch</a>.

        </p>

        <ul>
            <li>I hear a lot of little secre</li>
            <li>The Brady Bunch!</li>
            <li>Living all together</li>
            <li>That’s the way we alle</li>
        </ul>

        <p>Mavik Banner: physician; scientist. Searching for a way to tap into the hidden strengths that all humans have… then an accidental overdose of gamma radiation alters his body chemistry. <a href="#">And now when</a> David Banner grows angry or outraged, a startling metamorphosis occurs. The creature is driven by rage and pursued by an investigative reporter. The creature is wanted for a murder he didn’t commit. <a href="#">David Banner</a> is believed to be dead, and he must let the world think that he is dead, until he can find a way to control the raging spirit that dwells within him.</p>

        <ol>
            <li>I hear a lot of little secre</li>
            <li>The Brady Bunch!</li>
            <li>Living all together</li>
            <li>That’s the way we alle</li>
        </ol>

        <?php } else { ?>

        <?php the_content(); ?>

        <?php } ?>
        
    </div><!-- .article-content -->    
</div>
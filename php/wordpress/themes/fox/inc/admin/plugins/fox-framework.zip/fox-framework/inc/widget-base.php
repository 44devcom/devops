<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.0.0
 */
abstract class Fox_Widget_Base extends Widget_Base {
    
    // in extended class, we must return the folder name
    function _base() {
    }
    
    /**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'fox' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
        
		return [ 'fox-elementor' ];
        
	}
    
    function has_section( $slug ) {
        if ( ! property_exists( $this, 'sectionlist' ) ) {
            $this->sectionlist = [];
        }
        return in_array( $slug, $this->sectionlist );
    }
    function add_section( $slug ) {
        if ( ! property_exists( $this, 'sectionlist' ) ) {
            $this->sectionlist = [];
        }
        $this->sectionlist[] = $slug;
    }
    
    function register_each( $id, $param, $first = false ) {

        /* section title
        ---------------------------- */
        if ( isset( $param[ 'section' ] ) && isset( $param[ 'section_title' ] ) ) {

            if ( ! $first ) {
                // if not start, end of previous setting before
                $this->end_controls_section();
            }

            $section_setting = array( 'label' => $param[ 'section_title' ] );
            if ( isset( $param[ 'section_tab' ] ) ) {

                $tab = '';
                switch( $param[ 'section_tab' ] ) {
                    case 'content':
                        $tab = Controls_Manager::TAB_CONTENT;
                        break;
                        
                    case 'style' :
                        $tab = Controls_Manager::TAB_STYLE;
                        break;
                }

                $section_setting[ 'tab' ] = $tab;
                
            }

            if ( ! $this->has_section( $param[ 'section' ] ) ) {
                
                $this->start_controls_section(
                    'section_' . $param[ 'section' ],
                    $section_setting
                );
                $this->add_section( $param[ 'section' ] );
                
            }

        }
        
        /* tab
        ---------------------------- */
        if ( isset( $param['tabs'] ) ) {
            $this->start_controls_tabs( $param['tabs'] );
        }

        if ( isset( $param['tab'] ) ) {
            $tab = $param['tab'];
            $tab_title = isset( $param['tab_title'] ) ? $param['tab_title'] : 'Untitle';

            $this->start_controls_tab( $tab, array(
                'label' => $tab_title,
            ) );
            
        }
        
        /* other type
        ---------------------------- */
        $type = isset( $param[ 'type' ] ) ? $param[ 'type' ] : '';
        switch( $type ) {

            case 'text' :
            $type = Controls_Manager::TEXT;
            break;
            case 'textarea' :
            $type = Controls_Manager::TEXTAREA;
            break;
                case 'media' :
                case 'image' :
                $type = Controls_Manager::MEDIA;
                
            break;
            case 'code' :
            $type = Controls_Manager::CODE;
            break;
            case 'select' :
            $type = Controls_Manager::SELECT;
            break;
            case 'select2' :
            $type = Controls_Manager::SELECT2;
            break;
            case 'color' :
            $type = Controls_Manager::COLOR;
            break;
            case 'icon' :
            $type = Controls_Manager::ICONS;
            break;
            case 'gallery' :
            $type = Controls_Manager::GALLERY;
            break;
            case 'font' :
            $type = Controls_Manager::FONT;
            break;
            case 'switcher' :
            $type = Controls_Manager::SWITCHER;
            break;
            case 'url' :
            $type = Controls_Manager::URL;
            break;
            case 'heading' :
            $type = Controls_Manager::HEADING;
            break;
            case 'repeater' :
            $type = Controls_Manager::REPEATER;
            break;
            default:
            break;
        }

        $control_setting = $param;

        // remove section/tab
        if ( isset( $control_setting[ 'section' ] ) ) unset( $control_setting[ 'section' ] );
        if ( isset( $control_setting[ 'section_tab' ] ) ) unset( $control_setting[ 'section_tab' ] );
        if ( isset( $control_setting[ 'tab' ] ) ) unset( $control_setting[ 'tab' ] );

        // type
        $control_setting[ 'type' ] = $type;

        // label
        $control_setting[ 'label' ] = isset( $param[ 'title' ] ) ? $param[ 'title' ] : '';

        if ( isset( $param[ 'std' ] ) ) {
            $control_setting[ 'default' ] = $param[ 'std' ];
        }

        if ( isset( $param[ 'desc' ] ) ) {
            $control_setting[ 'description' ] = $param[ 'desc' ];
        }

        if ( isset( $param[ 'selector' ] ) ) {
            $control_setting[ 'selector' ] = $param[ 'selector' ];
        }
        if ( isset( $param[ 'selectors' ] ) ) {
            $control_setting[ 'selectors' ] = $param[ 'selectors' ];
        }
        
        if ( 'tab_close' == $type ) {
            
            $this->end_controls_tab();
            
        } elseif ( 'tabs_close' == $type ) {
            
            $this->end_controls_tabs();

        } elseif ( 'typography' == $type ) {

            $control_setting[ 'name' ] = str_replace( '_typography', '', $id );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                $control_setting
            );
            
        } elseif ( 'image_size' == $type ) {
            
            $this->add_group_control( \Elementor\Group_Control_Image_Size::get_type(), $param );
            
        } elseif ( 'align' == $type ) {
            
            $options = isset( $param[ 'options' ] ) ? $param[ 'options' ] : [ 'left', 'center', 'right' ];
            $actual_options = [];
            foreach ( $options as $k ) {
                $actual_options[ $k ] = [
                    'title' => ucfirst( $k ),
                    'icon' => 'eicon-text-align-' . $k
                ];
            }
            
            $control_setting[ 'options' ] = $actual_options;
            $control_setting[ 'type' ] = \Elementor\Controls_Manager::CHOOSE;
            $control_setting[ 'prefix_class' ] = isset( $param[ 'prefix_class' ] ) ? $param[ 'prefix_class' ] : 'align-';
            if ( isset( $param[ 'std' ] ) ) {
                $control_setting[ 'default' ] = $param[ 'std' ];
            }
            
            $this->add_responsive_control( $id, $control_setting );
            
        } elseif ( 'size' == $type ) {
            
            $control_setting[ 'type' ] =\Elementor\Controls_Manager::SLIDER;
            $control_setting[ 'default' ] = [
                'unit' => isset( $param[ 'std_unit' ] ) ? $param[ 'std_unit' ] : 'px',
                'size' => isset( $param[ 'std_size' ] ) ? $param[ 'std_size' ] : 100,
            ];
            $control_setting = array_merge( $control_setting, array(
                'tablet_default' => array( 'unit' => 'px' ),
                'mobile_default' => array( 'unit' => 'px' ),
                'size_units' => array( '%', 'px', 'vw' ),
                'range' => array(
                    '%' => array( 'min' => 1, 'max' => 100 ),
                    'px' => array(
                        'min' => isset( $param[ 'px_min' ] ) ? $param[ 'px_min' ] : 0,
                        'max' => isset( $param[ 'px_max' ] ) ? $param[ 'px_max' ] : 1000 
                    ),
                    'vw' => array( 'min' => 1, 'max' => 100 )
                ),
            ) );
            
            $this->add_responsive_control( $id, $control_setting );

        } elseif ( 'repeater' == $type ) {

            $repeater = new \Elementor\Repeater();
            $fields = isset( $param[ 'fields' ] ) ? $param[ 'fields' ] : [];
            foreach ( $fields as $field_id => $field ) {

                $field_type = '';
                if ( 'text' == $field['type'] ) {
                    $field_type = Controls_Manager::TEXT;
                } elseif ( 'textarea' == $field['type'] ) {
                    $field_type = Controls_Manager::TEXTAREA;
                } elseif ( 'media' == $field['type'] ) {
                    $field_type = Controls_Manager::MEDIA;
                } elseif ( 'switcher' == $field['type'] ) {
                    $field_type = Controls_Manager::SWITCHER;
                } elseif ( 'color' == $field['type'] ) {
                    $field_type = Controls_Manager::COLOR;
                } elseif ( 'url' == $field['type'] ) {
                    $field_type = Controls_Manager::URL;
                } elseif ( 'select' == $field['type'] ) {
                    $field_type = Controls_Manager::SELECT;
                }
                
                $field_settings = $field;
                $field_settings[ 'label' ] = isset( $field[ 'title' ] ) ? $field[ 'title' ] : '';
                $field_settings[ 'type' ] = $field_type;
                $field_settings[ 'default' ] = isset( $field[ 'std' ] ) ? $field[ 'std' ] : null;
                
                if ( isset( $field[ 'desc' ] ) ) {
                    $field_settings[ 'description' ] = $field[ 'desc' ];
                }
                
                if ( 'image_size' == $field['type'] ) {
                    
                    $repeater->add_group_control( \Elementor\Group_Control_Image_Size::get_type(), array(
                        'name' => str_replace( '_size', '', $field_id ),
                        'default' => 'thumbnail',
                        'separator' => 'none',
                    ) );
                    
                } else {
                    
                    $repeater->add_control( $field_id, $field_settings  );
                    
                }

            }
            
            $title_field = isset( $param[ 'title_field' ] ) ? $param[ 'title_field' ] : 'name';

            $this->add_control(
                $id,
                [
                    'label' => $param[ 'title' ],
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => isset( $param['std'] ) ? $param['std'] : [],
                    'title_field' => '{{{ ' . $title_field . ' }}}',
                ]
            );

        } else {

            $this->add_control(
                $id,
                $control_setting
            );

        }
        
    }

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	function register_controls() {
        
        $params = array();
        
        include FOX_ELEMENTOR_PATH . 'inc/addons/' . $this->_base() . '/params.php';
        
        $first = true;
        foreach ( $params as $id => $param ) {
            
            $this->register_each( $id, $param, $first );
            $first = false;
            
        }
        
        // at least 1 section ultilized
        if ( ! $first ) {
            $this->end_controls_section();
        }

        $this->sectionlist = [];
        
	}
    
    /**
     * @since Fox 4.2
     * to prevent some content from being rendered when we have pager
     */
    function print_content() {
        
        $render = true;
        $settings = $this->get_settings_for_display();
        if ( isset( $settings[ 'paged_disable' ] ) ) {
            
            if ( 'true' == $settings[ 'paged_disable' ] || 'yes' == $settings[ 'paged_disable' ] ) {
                
                if ( is_front_page() && ! is_home() ) {
                    $paged = get_query_var( 'page' );
                } else {
                    $paged = get_query_var( 'paged' );
                }
                
                if ( $paged ) {

                    $render = false;

                }
                
            }
            
        }
        
        if ( $render ) {
            $this->render_content();
        }
        
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	function render() {
        
        include FOX_ELEMENTOR_PATH . 'inc/addons/' . $this->_base() . '/frontend.php';
        
	}
    
}
<?php
$settings = $this->get_settings_for_display();

if ( ! defined( 'SBIVER' ) ) {
    echo '<div class="fox-error">Please install the plugin <strong>Smash Balloon Social Photo Feed</strong> to insert your Instagram Feed. To install, please go to your Dashboard &raquo; Fox Magazine &raquo; Install Plugins.</div>';
    return;
}

extract( wp_parse_args( $settings, [
    'shortcode' => '',
]) );

if ( $shortcode ) {
    echo do_shortcode( $shortcode );
}
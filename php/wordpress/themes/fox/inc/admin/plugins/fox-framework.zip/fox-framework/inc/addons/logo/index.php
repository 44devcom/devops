<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Logo extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_logo';
	}
    
    public function _base() {
        return 'logo';
    }

	public function get_title() {
		return 'FOX Logo';
	}
    
    public function get_keywords() {
		return [ 'site logo', 'logo', 'branding', 'header logo' ];
	}

	public function get_icon() {
        return 'eicon-site-logo';
	}
    
}
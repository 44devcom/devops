<?php
$params = [];
    
$forms = array( '' => 'Select Form' );
$std = '';
$args = array(
    'post_type' => 'mc4wp-form',
    'posts_per_page' => 100,
    'ignore_sticky_posts' => true,
);
$get_forms = get_posts( $args );
foreach ( $get_forms as $form ) {
    if ( ! $std ) $std = strval($form->ID);
    $forms[ strval($form->ID) ] = $form->post_title;
}

// FORM
$params[ 'form' ] = array(
    'type' => 'select',
    'title' => 'Select form',
    'std' => $std,
    'options' => $forms,
    'desc' => 'The premium version allows you to have more than one form.',

    'section' => 'form',
    'section_title' => 'Form',
);

$params[ 'layout' ] = array(
    'type' => 'select',
    'title' => 'Layout',
    'std' => 'inline',
    'options' => [
        'inline' => 'Inline',
        'stack' => 'Stack',
    ],
);

$params[ 'align' ] = array(
    'title' => 'Align',
    'type' => 'select',
    'options' => array(
        'left' => 'Left',
        'center' => 'Center',
        'right' => 'Right',
    ),
    'std' => 'center',
);

// INPUT STYLE
$params[ 'heading_input_style' ] = array(
    'title' => 'Input Style',
    'type' => 'heading',

    'section' => 'input_style',
    'section_title' => 'Input Style',
);

$params[ 'input_border_width' ] = array(
    'title' => 'Input border width',
    'type' => 'text',
    'placeholder' => 'Eg. 1px',
);

$params[ 'input_border_radius' ] = array(
    'title' => 'Input border radius',
    'type' => 'text',
    'placeholder' => 'Eg. 3px',
);

$params[ 'input_text_color' ] = array(
    'title' => 'Input text color',
    'type' => 'color',
);

$params[ 'input_background' ] = array(
    'title' => 'Input background',
    'type' => 'color',
);

$params[ 'input_border_color' ] = array(
    'title' => 'Input border color',
    'type' => 'color',
);

$params[ 'input_focus_text_color' ] = array(
    'title' => 'Input focus text color',
    'type' => 'color',
);

$params[ 'input_focus_background' ] = array(
    'title' => 'Input focus background',
    'type' => 'color',
);

$params[ 'input_focus_border_color' ] = array(
    'title' => 'Input focus border color',
    'type' => 'color',
);

$params[ 'input_text_size' ] = array(
    'title' => 'Input text size',
    'type' => 'text',
    'placeholder' => 'Eg. 12px',
);

// BUTTON STYLE
$params[ 'heading_button_style' ] = array(
    'title' => 'Button Style',
    'type' => 'heading',

    'section' => 'button_style',
    'section_title' => 'Button Style',
);

$params[ 'button_color' ] = array(
    'title' => 'Button text color',
    'type' => 'color',
);

$params[ 'button_background' ] = array(
    'title' => 'Button background',
    'type' => 'color',
);

$params[ 'button_hover_color' ] = array(
    'title' => 'Button hover text color',
    'type' => 'color',
);

$params[ 'button_hover_background' ] = array(
    'title' => 'Button hover background',
    'type' => 'color',
);

$params[ 'button_text_size' ] = array(
    'title' => 'Button text size',
    'type' => 'text',
    'placeholder' => 'Eg. 12px',
);

$params[ 'button_border_radius' ] = array(
    'title' => 'Button border radius',
    'type' => 'text',
    'placeholder' => 'Eg. 3px',
);
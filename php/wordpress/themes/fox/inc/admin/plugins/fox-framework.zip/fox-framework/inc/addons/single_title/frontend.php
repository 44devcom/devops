<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'title_preview_text'
]) );

$cl = [ 'el-single-title' ];

/* preview text
------------------------------ */
if ( ! $title_preview_text ) {
    $title_preview_text = 'Post Title Placeholder';
}

/**
 * final
 */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    <?php if ( fox_is_edit() || is_singular( 'elementor_library' ) || is_singular( 'fox_block' ) ) { ?>
    
    <h1 class="el-title-tag"><?php echo esc_html( $title_preview_text ); ?></h1>
    
    <?php } else { ?>
    
    <h1 class="el-title-tag"><?php echo get_the_title(); ?></h1>
    
    <?php } ?>
</div>
<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
]) );

$cl = [ 'el-single-comments' ];

/**
 * final
 */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    <?php if ( fox_is_edit() ) { ?>
    
    <div id="comments" class="comments-area">

        <h2 class="comments-title single-heading">
            <span>3 Comments</span>
        </h2><!-- .comments-title -->

        <ol class="commentlist">
            <?php echo fox_elementor_fake_comment([
                    'image' => FOX_ELEMENTOR_URL . 'images/avatar.jpg',
                    'name' => 'John Doe',
                    'content' => 'Duo dolorum mandamus mnesarchum te. Sit ridens persius ex. Vel noluisse perpetua consequat ex, has nostro antiopam eu. Nec esse meis eu.',
                    'children' => fox_elementor_fake_comment([
                        'image' => FOX_ELEMENTOR_URL . 'images/avatar.jpg',
                        'name' => 'John Doe',
                        'content' => 'Duo dolorum mandamus mnesarchum te. Sit ridens persius ex. Vel noluisse perpetua consequat ex, has nostro antiopam eu. Nec esse meis eu. Dico legendos sed an, eu sed meis ferri assentior. Usu tantas omittantur ut'
                    ]),
                ]); ?>
            
            <?php echo fox_elementor_fake_comment([
                    'image' => FOX_ELEMENTOR_URL . 'images/avatar.jpg',
                    'name' => 'John Doe',
                    'content' => 'Has no sale fierent, libris audire voluptua sit et. Vis assum iriure mnesarchum in, novum invenire reprimique cum id. Mazim reprehendunt at vel'
                ]); ?>
            
        </ol>
        
        <div id="respond" class="comment-respond">
            
            <h3 id="reply-title" class="comment-reply-title single-heading">
              <span>Leave a Reply</span> 
              <small>
                  <a rel="nofollow" id="cancel-comment-reply-link" href="#respond" style="display:none;">Cancel reply</a>
              </small>
            </h3>
            
            <form action="#" method="post" id="commentform" class="comment-form" novalidate="">
                
                <p class="comment-notes">Your email address will not be published.</p>
                <p class="comment-form-comment">
                    <textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" placeholder="Write your comment..."></textarea>
                </p>
                
                <p class="comment-form-author">
                    <input id="author" name="author" type="text" value="" size="30" placeholder="Name">
                </p>
                <p class="comment-form-email">
                    <input id="email" name="email" type="email" value="" size="30" placeholder="Email">
                </p>
                <p class="comment-form-url">
                    <input id="url" name="url" type="url" value="" size="30" placeholder="Website">
                </p>
                <p class="comment-form-cookies-consent">
                    <input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"> 
                    <label for="wp-comment-cookies-consent">Save my name, email, and website in this browser for the next time I comment.</label>
                </p>
                <p class="form-submit">
                    <input name="submit" type="submit" id="submit" class="submit" value="Post Comment">
                </p>
            </form>
            
        </div><!-- #respond -->
    </div><!-- #comments -->
    
    <?php } else {

        if ( is_engine_v6() ) {
            fox56_comments();
        } elseif ( defined( 'FOX_VERSION' ) ) {
            fox_post_comment();
        }
    
    } ?>
</div>
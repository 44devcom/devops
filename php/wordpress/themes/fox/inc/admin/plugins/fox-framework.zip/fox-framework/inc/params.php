<?php
/* QUERY
------------------------------------------------------------------------------------------------ */
/**
 * Return query params used commonly
 * $exclude is the array of ids to exclude
 *
 *
 * @since 4.0
 */
function foxfw3_query_params( $exclude = array(), $override = [] ) {
    
    $params = array();
    
    $params[ 'source' ] = array(
        
        'title' => 'Posts Source',
        'type' => 'select',
        'std' => '',
        'options' => [
            '' => 'Default',
            'related' => 'Related Posts (only for Single Post Template)',
            'archive' => 'Archive Posts (only for Archive Template)',
        ],
        
        'desc' => 'Sometimes this element will be used for Single Post to display related posts or in Archive to display archive posts. This is purpose of this option.',
        
        'section' => 'query',
        'section_title' => 'Query',
    );
    
        /* RELATED */
        $params[ 'related_criterion' ] = array(
            'title' => 'Criterion',
            'type' => 'select',
            'options' => [
                'tag' => 'Same tags current post',
                'category' => 'Same categories current post',
                'author' => 'Same author with current post',
            ],
            'std' => 'tag',
            
            'condition' => [
                'source[value]' => 'related',
            ],
        );
        
    
    $params[ 'number' ] = array(
        'title' => 'Number of posts:',
        'type' => 'text',
        'std' => '4',
        
        'condition' => [
            'source[value]' => [ 'related', '' ],
        ],
    );
    
    $params[ 'orderby' ] = array(
        'title' => 'Order by',
        'type' => 'select',
        'options' => array(
            'date' => 'Date',
            'modified' => 'Updated Date',
            
            'view' => 'View count',
            'view_week' => 'View count (Weekly)',
            'view_month' => 'View count (Monthly)',
            'view_year' => 'View count (Yearly)',
            
            'title' => 'Post title',
            'rand' => 'Random',
            'comment_count' => 'Comment count',
            
            'review_score' => 'Review Score',
            'review_date' => 'Recent Review',
        ),
        'std' => 'date',
        
        'condition' => [
            'source[value]' => [ 'related', '' ],
        ],
    );
    
    $params[ 'order' ] = array(
        'title' => 'Order?',
        'type' => 'select',
        'options' => array(
            'asc' => 'Ascending',
            'desc' => 'Descending',
        ),
        'std' => 'desc',
        
        'condition' => [
            'source[value]' => [ 'related', '' ],
        ],
    );
    
    $cat_options = array();
    $all_cats = get_terms( array( 'hide_empty' => false, 'taxonomy' => 'category', 'orderby' => 'name', 'order' => 'ASC' ) );
    foreach ( $all_cats as $cat ) {
        $cat_options[ 'cat_' . strval( $cat->slug ) ] = $cat->name;
    }
    
    $author_options = array( 'all' => 'All' );
    
    $all_authors = get_users( array( 'capability' => ['edit_posts'], 'orderby' => 'display_name', 'order' => 'ASC' ) );
    foreach ( $all_authors as $at ) {
        $author_options [ 'author_' . strval( $at->user_nicename ) ] = $at->display_name;
    }
    
    $params[ 'categories' ] = array(
        'title' => 'Only from categories:',
        'type' => 'select2',
        'multiple' => true,
        'options' => $cat_options,
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'exclude_categories' ] = array(
        'title' => 'Exclude categories:',
        'type' => 'select2',
        'multiple' => true,
        'options' => $cat_options,
        
        'condition' => [
            'source[value]' => [ '', 'related' ],
        ],
    );
    
    $params[ 'tags' ] = array(
        'title' => 'Only from tags:',
        'type' => 'text',
        'desc' => 'Enter tag IDs or names, separate them by commas.',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'exclude_tags' ] = array(
        'title' => 'Exclude tags:',
        'type' => 'text',
        'desc' => 'Enter tag IDs or names, separate them by commas.',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'author' ] = array(
        'title' => 'Only posts from author:',
        'type' => 'select',
        'std' => 'all',
        'options' => $author_options,
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'format' ] = array(
        'title' => 'Only post format:',
        'type' => 'select',
        'options' => [
            '' => 'All',
            'video' => 'Video',
            'audio' => 'Audio',
            'gallery' => 'Gallery',
            'link' => 'Link',
        ],
        'std' => '',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'include' ] = array(
        'title' => 'Display only posts from IDs:',
        'desc' => 'Enter post IDs, separated by commas',
        'type' => 'text',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'exclude' ] = array(
        'title' => 'Exclude post IDs:',
        'desc' => 'Enter post IDs, separated by commas',
        'type' => 'text',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    // since 1.4
    $params[ 'offset' ] = array(
        'title' => 'Offset',
        'desc' => 'Number of posts to pass by',
        'type' => 'text',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'featured' ] = array(
        'title' => 'Show only featured posts?',
        'type' => 'switcher',
        'std' => '',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'pagination' ] = array(
        'title' => 'Pagination?',
        'type' => 'switcher',
        'std' => '',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    /* deprecated
    $params[ 'paged_disable' ] = array(
        'title' => 'Disable on page 2, 3..',
        'type' => 'switcher',
        'std' => '',
    );
    */
    
    $params[ 'unique_posts' ] = array(
        'title' => 'Unique posts?',
        'desc' => 'If enabled, it prevents a post appears twice.',
        'type' => 'switcher',
        'std' => '',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    $params[ 'custom_query' ] = array(
        'title' => 'Your Custom Query',
        'type' => 'code',
        'desc' => 'Please make sure you understand what you\'re writing when using this option',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    /**
     * custom post type options
     * @since 1.4
     */
    $params[ 'post_type' ] = array(
        'title' => 'Custom Post Type',
        'type' => 'text',
        'placeholder' => 'Eg. movie',
        'desc' => 'Enter your post type slug, eg. movie. If you have few post types, use commas to separate them. Enter "any" (without quotes) to display any post type.',
        
        'condition' => [
            'source[value]' => '',
        ],
    );
    
    for ( $i = 1; $i <= 2; $i++ ) {
        
        $params[ 'tax_' . $i ] = array(
            'title' => 'Taxonomy ' . $i . ' slug',
            'type' => 'text',
            'placeholder' => 'Eg. genre',
            'desc' => 'If your taxonomy is Genre, the slug is probably genre but sometimes it may have prefix. Make sure you enter correct the taxonomy slug. Otherwise it won\'t work as expected',
            
            'condition' => [
                'source[value]' => '',
            ],
        );
        
        $params[ 'tax_' . $i . '_value' ] = array(
            'title' => 'Taxonomy ' . $i . ' values',
            'type' => 'text',
            'placeholder' => 'Eg. Comedy, Fiction',
            'desc' => 'Enter name values for your taxonomy. Separate them by commas.',
            
            'condition' => [
                'source[value]' => '',
            ],
        );
        
    }
    
    // exclude
    // and set section 'query'
    $first = true;
    foreach ( $params as $id => $param ) {
        if ( in_array( $id, $exclude ) ) {
            unset( $params[ $id ] );
        } elseif ( $first ) {
            $params[ $id ][ 'section' ] = 'query';
            $params[ $id ][ 'section_title' ] = 'Query';
            $first = false;
        }
    }
    
    // OVERRIDE
    if ( ! empty( $override ) ) {
        foreach ( $override as $id => $arr ) {
            if ( isset( $params[ $id ] ) ) $params[ $id ] = $arr;
        }
    }
    
    return apply_filters( 'fox_default_query_params', $params );

}

/* standard parameters (to used in Grid, List.. with 1st standard)
------------------------------------------------------------------------------------------------ */
function foxfw3_elementor_standard_params( $args = [] ) {
    extract( wp_parse_args( $args, [
        'prefix' => '',
        'exclude' => [],
        'include' => [],
        'alter' => [],
    ]) );
    
    $params = [];
    include FOX_ELEMENTOR_PATH . 'inc/addons/post_standard/params.php';
    
    $final_params = [];
    foreach ( $params as $k => $v ) {
        if ( in_array( $k, $exclude ) ) {
            continue;
        }
        if ( ! empty( $include ) && ! in_array( $k, $include ) ) {
            continue;
        }
        
        // alter
        if ( isset( $alter[ $k ] ) ) {
            $v = $alter[ $k ];
        }
        
        $prefixed_k = $prefix . $k ;
        if ( isset( $v[ 'section' ] ) ) {
            $v[ 'section' ] = $prefix . $v[ 'section' ];
        }
        if ( isset( $v[ 'condition' ] ) ) {
            $new_condition = [];
            foreach ( $v[ 'condition' ] as $con => $dition ) {
                $new_condition[ $prefix . $con ] = $dition;
            }
            $v[ 'condition' ] = $new_condition;
        }
        $final_params[ $prefixed_k ] = $v;
    }
    
    return $final_params;
    
}

/* PAGINATION PARAMS
------------------------------------------------------------------------------------------------ */
function foxfw3_pagination_params() {
        
    $params = array();
    
    $params[ 'pagination_align' ] = array(
        
        'title' => 'Pagination align',
        'type' => 'align',
        'options' => [ 'left', 'center', 'right' ],
        'std' => 'center',
        'prefix_class' => 'pagination-align-',
        
        'section' => 'pagination',
        'section_title' => 'Pagination',
        
    );
    
    $params[ 'pagination_margin' ] = array(
        'title' => 'Pagination margin',
        'type' => 'size',
        
        'std_unit' => 'px',
        'std_size' => 60,
        'px_max' => 200,
        'px_min' => 0,

        'selectors' => [
            '{{WRAPPER}} .el-pagination' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],
    );
    
    $params[ 'pagination_item_spacing' ] = array(
        'title' => 'Pagination item spacing',
        'type' => 'size',
        
        'std_unit' => 'px',
        'std_size' => 2,
        'px_max' => 30,
        'px_min' => 0,

        'selectors' => [
            '{{WRAPPER}} .el-pagination .page-numbers + .page-numbers' => 'margin-left:{{SIZE}}{{UNIT}};',
        ],
    );
    
    $params[ 'pagination_item_size' ] = array(
        'title' => 'Pagination item size',
        'type' => 'size',
        
        'std_unit' => 'px',
        'std_size' => 24,
        'px_max' => 80,
        'px_min' => 10,

        'selectors' => [
            '{{WRAPPER}} .el-pagination .page-numbers' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}};',
        ],
    );
    
    $params[ 'pagination_item_typography' ] = array(
        'title' => 'Pagination item typography',
        'type' => 'typography',
        'selector' => '{{WRAPPER}} .el-pagination .page-numbers',
    );
    
    $params[ 'pagination_item_border_radius' ] = array(
        'title' => 'Pagination item border radius',
        'type' => 'size',
        
        'std_unit' => 'px',
        'std_size' => 0,
        'px_max' => 40,
        'px_min' => 0,
        
        'selectors' => [
            '{{WRAPPER}} .el-pagination .page-numbers' => 'border-radius:{{SIZE}}{{UNIT}};',
        ],
    );
    
    $params[ 'pagination_item_border_width' ] = array(
        'title' => 'Pagination item border size',
        'type' => 'size',
        
        'std_unit' => 'px',
        'std_size' => 0,
        'px_max' => 10,
        'px_min' => 0,
        
        'selectors' => [
            '{{WRAPPER}} .el-pagination .page-numbers' => 'border-width:{{SIZE}}{{UNIT}};',
        ],
    );
    
    /**
     * tab normal
     */
    $params[ 'pagination_item_color' ] = array(
        'title' => 'Pagination item color',
        'type' => 'color',
        
        'tabs' => 'pagination_style',
        'tab' => 'normal',
        'tab_title' => 'Normal',
        
        'selectors' => [
            '{{WRAPPER}} .el-pagination a.page-numbers' => 'color:{{VALUE}};',
        ],
    );
    
    $params[ 'pagination_item_background' ] = array(
        'title' => 'Pagination item background',
        'type' => 'color',
        'selectors' => [
            '{{WRAPPER}} .el-pagination a.page-numbers' => 'background:{{VALUE}};',
        ],
    );
    
    $params[ 'pagination_item_border_color' ] = array(
        'title' => 'Pagination item border color',
        'type' => 'color',
        'selectors' => [
            '{{WRAPPER}} .el-pagination a.page-numbers' => 'border-color:{{VALUE}};',
        ],
    );
    
    $params[] = [
        'type' => 'tab_close',
    ];
    
    /**
     * tab hover
     */
    $params[ 'pagination_item_hover_color' ] = array(
        'type' => 'color',
        'title' => 'Pagination item hover color',
        'selectors' => [
            '{{WRAPPER}} .el-pagination a.page-numbers:hover' => 'color:{{VALUE}};',
        ],

        'tab' => 'hover',
        'tab_title' => 'Hover',
    );

    $params[ 'pagination_item_hover_background' ] = array(
        'type' => 'color',
        'title' => 'Pagination item hover background',
        'selectors' => [
            '{{WRAPPER}} .el-pagination a.page-numbers:hover' => 'background:{{VALUE}};',
        ],
    );
    
    $params[ 'pagination_item_hover_border_color' ] = array(
        'type' => 'color',
        'title' => 'Pagination item hover border color',
        'selectors' => [
            '{{WRAPPER}} .el-pagination a.page-numbers:hover' => 'border-color:{{VALUE}};',
        ],
    );
    
    $params[] = [
        'type' => 'tab_close',
    ];
    
    /**
     * tab active
     */
    $params[ 'pagination_item_current_color' ] = array(
        'type' => 'color',
        'title' => 'Pagination current item color',
        'selectors' => [
            '{{WRAPPER}} .el-pagination span.page-numbers' => 'color:{{VALUE}};',
        ],

        'tab' => 'current',
        'tab_title' => 'Current',
    );
    
    $params[ 'pagination_item_current_background' ] = array(
        'type' => 'color',
        'title' => 'Pagination current item background',
        'selectors' => [
            '{{WRAPPER}} .el-pagination span.page-numbers' => 'background:{{VALUE}};',
        ],
    );
    
    $params[ 'pagination_item_current_border_color' ] = array(
        'type' => 'color',
        'title' => 'Pagination current item border color',
        'selectors' => [
            '{{WRAPPER}} .el-pagination span.page-numbers' => 'border-color:{{VALUE}};',
        ],
    );
    
    $params[] = [
        'type' => 'tab_close',
    ];
    
    $params[] = [
        'type' => 'tabs_close',
    ];
    
    return $params;
    
}

/* GENERATE OPTIONS
------------------------------------------------------------------------------------------------ */
function foxfw3_generate_options( $args = [] ) {
    
    extract( wp_parse_args( $args, [
        'base' => '',
        'exclude' => [],
        'override' => [],
        'append' => [],
        'context' => 'customizer',
        'prefix' => '',
        
        // general for all
        'section' => '',
        'section_title' => '',
        'panel' => '',
        
    ] ) );
    
    $params = foxfw3_get_params( $base );
    if ( ! $params ) return [];
    
    // exclude
    if ( ! empty( $exclude ) ) {
        foreach ( $params as $id => $param ) {
            if ( in_array( $id, $exclude ) ) unset( $params[ $id ] );
        }
    }
    
    // override
    if ( ! empty( $override ) ) {
        foreach ( $override as $id => $param ) {
            if ( isset( $params[ $id ] ) ) {
                $params[ $id ] = wp_parse_args( $param, $params[ $id ] );
            } else {
                $params[ $id ] = $param;
            }
        }
    }
    
    // append
    if ( ! empty( $append ) ) {
        
        $append_arr = [];
        $current_after = 'allllll';
        
        // id: thumbnail_type
        foreach ( $append as $id => $param ) {
            
            // after: show_thumbnail
            $after = isset( $param[ 'after' ] ) ? $param[ 'after' ] : '';
            if ( $after ) {
                $current_after = $after;
                if ( ! isset( $append_arr[ $current_after ] ) ) $append_arr[ $current_after ] = [];
            }
            $append_arr[ $current_after ][ $id ] = $param;
        }
        
        $final_params = [];
        foreach ( $params as $id => $param ) {
            $final_params[ $id ] = $param;
            if ( isset( $append_arr[ $id ] ) ) {
                foreach ( $append_arr[ $id ] as $more_id => $more_param ) {
                    $final_params[ $more_id ] = $more_param;
                }
            }
        }
        
        
        if ( isset( $append_arr[ 'allllll' ] ) ) {
            $final_params += $append_arr[ 'allllll' ];
        }
        
        // restore it
        $params = $final_params;
        
    }
    
    /* Return param list for elementor
    ---------------------------------------- */
    if ( 'elementor' == $context ) {
    
        $return = [];
        
        foreach ( $params as $id => $param ) {
            
            extract( wp_parse_args( $param, [
                'name' => '',
                'std' => '',
            ] ) );
            
            /// title becomes name
            if ( $name ) {
                unset( $param[ 'name' ] );
                $param[ 'title' ] = $title;
            }
            
            $final_id = $id;
            if ( is_numeric( $id ) ) {
                $final_id = 'heading_' . $id;
            }
            
            // prefix
            if ( $prefix ) $final_id = $prefix . $final_id;
            
            // section, panel
            if ( $section ) {
                $param[ 'section' ] = $section;
                $section = ''; // elementor is weird while we can't redeclare section
                if ( $section_title ) {
                    $param[ 'section_title' ] = $section_title;
                    $section_title = '';
                }
            }
            
            $return[ $final_id ] = $param;
        
        }
        
        return $return;
        
        
    /* Return param list for customizer
    ---------------------------------------- */
    } elseif ( 'customizer' == $context ) {
        
        $return = [];
        
        foreach ( $params as $id => $param ) {
            
            extract( wp_parse_args( $param, [
                'type' => '',
                'title' => '',
                'std' => '',
            ] ) );
            
            if ( '' == $type ) {
                var_dump( $id );
            }
            
            /// switcher becomes enable shorthand
            if ( 'switcher' == $type ) {
                unset( $param[ 'type' ] );
                $param[ 'shorthand' ] = 'enable';
                if ( 'yes' == $std ) {
                    $param[ 'std' ] = 'true';
                } else {
                    $param[ 'std' ] = 'false';
                }
            }
            
            /// title becomes name
            if ( $title ) {
                unset( $param[ 'title' ] );
                $param[ 'name' ] = $title;
            }
            
            // prefix
            $final_id = $id;
            if ( $prefix ) $final_id = $prefix . $final_id;
            
            // section, panel
            if ( $section ) $param[ 'section' ] = $section;
            if ( $section_title ) $param[ 'section_title' ] = $section_title;
            if ( $panel ) $param[ 'panel' ] = $panel;
            
            $return[ $final_id ] = $param;
        
        }
        
        return $return;
        
    }
       
}

/* Return fn_params from settings
 * convert Elementor params into fn_params system of theme    
 * @since 4.6.6
------------------------------------------------------------------------------------------------ */
function foxfw3_fn_params( $settings ) {
    
    $fn_params = $settings;
    
    $fn_params = wp_parse_args( $fn_params, [
        'layout' => '',
        'text_color' => '',
        'item_align' => '',
        'first_standard' => '',
        'item_border' => '',
        'thumbnail_hover_effect' => '',
        'thumbnail_hover_logo' => '',
        'format_indicator' => '',
        'thumbnail_index' => '',
        'thumbnail_view' => '',
        
        'show_thumbnail' => '',
        'show_title' => '',
        'show_date' => '',
        'show_category' => '',
        'show_author' => '',
        'show_author_avatar' => '',
        'show_excerpt' => '',
        'show_excerpt_more' => '',
        'show_comment_link' => '',
        'show_reading_time' => '',
        'show_view' => '',
        
        // masonry
        'big_first_post' => '',
        
        'pagination' => '',
    ]);
    
    /**
     * color
     */
    $fn_params[ 'color' ] = $fn_params[ 'text_color' ];
    
    /**
     * align
     */
    $fn_params[ 'align' ] = $fn_params[ 'item_align' ];

    /**
     * first standard
     */
    $fn_params[ 'first_standard' ] = ( 'yes' == $fn_params[ 'first_standard' ] );

    /**
     * item border
     */
    $fn_params[ 'item_border' ] = ( 'yes' == $fn_params[ 'item_border' ] );

    /**
     * components
     */
    $components = [];
    $possible_components = [
        'thumbnail',
        'title',
        'date',
        'category',
        'author',
        'author_avatar',
        'excerpt', 
        'excerpt_more', 
        'reading_time',
        'comment_link',
        'view',
    ];
    foreach ( $possible_components as $com ) {

        $key = 'show_' . $com;
        if ( 'excerpt_more' == $com ) {
            $key = 'excerpt_more';
        }

        if ( isset( $settings[ $key ] ) && 'yes' == $fn_params[ $key ] ) {
            $components[] = $com;
        }
    }
    
    /**
     * BIG
     */
    if ( 'big' == $fn_params[ 'layout' ] ) {
        $components[] = 'thumbnail';
        $fn_params[ 'big_meta_background' ] = $fn_params[ 'meta_background' ];
        $fn_params[ 'big_align' ] = $fn_params[ 'item_align' ];
        $fn_params[ 'big_content_excerpt' ] = $fn_params[ 'content_excerpt' ];
    }
    
    /**
     * VERTICAL
     */
    if ( 'vertical' == $fn_params['layout']) {
        $fn_params[ 'vertical_thumbnail_type' ] = $fn_params['thumbnail_type'];
        $fn_params[ 'vertical_thumbnail_position' ] = $fn_params['thumbnail_position'];
        $fn_params[ 'vertical_excerpt_size' ] = $fn_params['excerpt_size'];
    }
    
    /**
     * STANDARD
     */
    if ( 'standard' == $fn_params[ 'layout' ] ) {
        
        $fn_params[ 'standard_header_align' ] = $fn_params[ 'header_align' ];
        $fn_params[ 'standard_content_excerpt' ] = $fn_params[ 'content_excerpt' ];
        $fn_params[ 'standard_thumbnail_type' ] = $fn_params[ 'thumbnail_type' ];
        $fn_params[ 'standard_excerpt_length' ] = $fn_params[ 'excerpt_length' ];
        $fn_params[ 'standard_excerpt_more' ] = $fn_params[ 'excerpt_more' ];
        $fn_params[ 'standard_excerpt_more_style' ] = $fn_params[ 'excerpt_more_style' ];
        
        $components[] = 'excerpt';
        
        if ( isset( $settings[ 'show_share' ] ) && 'yes' == $fn_params[ 'show_share' ] ) {
            $components[] = 'share';
        }
        if ( isset( $settings[ 'show_related' ] ) && 'yes' == $fn_params[ 'show_related' ] ) {
            $components[] = 'related';
        }
        
    }
    
    /**
     * NEWSPAPER
     */
    if ( 'newspaper' == $fn_params[ 'layout' ] ) {
        
        $fn_params[ 'newspaper_header_align' ] = $fn_params[ 'header_align' ];
        $fn_params[ 'newspaper_content_excerpt' ] = $fn_params[ 'content_excerpt' ];
        
        $components[] = 'excerpt';
        
        if ( isset( $settings[ 'show_share' ] ) && 'yes' == $fn_params[ 'show_share' ] ) {
            $components[] = 'share';
        }
        if ( isset( $settings[ 'show_related' ] ) && 'yes' == $fn_params[ 'show_related' ] ) {
            $components[] = 'related';
        }
    }
    
    /**
     * SLIDER
     */
    if ( 'slider' == $fn_params[ 'layout' ] ) {
        
        $fn_params[ 'slider_nav_style' ] = $fn_params[ 'nav_style' ];
        if ( 'arrow' == $fn_params[ 'slider_nav_style' ] ) {
            $fn_params[ 'slider_nav_style' ] = 'square-1';
        }
        $fn_params[ 'slider_title_background' ] = $fn_params[ 'title_background' ];
        $components[] = 'thumbnail';
        
    }

    /**
     * FINAL COMPONENTS
     */
    $fn_params[ 'components' ] = join( ',', $components );

    /**
     * thumbnails
     */
    $fn_params[ 'thumbnail_hover' ] = $fn_params[ 'thumbnail_hover_effect' ];

    $thumbnail_hover_logo = wp_parse_args( $fn_params[ 'thumbnail_hover_logo' ], [
        'id' => ''
    ] );
    $fn_params[ 'thumbnail_hover_logo' ] = $thumbnail_hover_logo[ 'id' ];

    /**
     * thumbnail components
     */
    $thumbnail_components = [];
    if ( 'yes' == $fn_params[ 'format_indicator' ] ) {
        $thumbnail_components[] = 'format_indicator';
    }
    if ( 'yes' == $fn_params[ 'thumbnail_index' ] ) {
        $thumbnail_components[] = 'index';
    }
    if ( 'yes' == $fn_params[ 'thumbnail_view' ] ) {
        $thumbnail_components[] = 'view';
    }
    $fn_params[ 'thumbnail_components' ] = join( ',', $thumbnail_components );
    
    /**
     * masonry
     */
    $fn_params[ 'big_first_post' ] = ( 'yes' == $fn_params[ 'big_first_post' ] );
    
    /**
     * list
     */
    
    // change prefix, just a legacy
    if ( 'group-1' == $fn_params[ 'layout' ] ) {
        
        $fn_params[ 'group1_bigpost_ratio' ] = $fn_params[ 'bigpost_ratio' ];
        $fn_params[ 'group1_bigpost_position' ] = $fn_params[ 'bigpost_position' ];
        $fn_params[ 'group1_sep_border' ] = $fn_params[ 'sep_border' ];
        $fn_params[ 'group1_sep_border_color' ] = $fn_params[ 'sep_border_color' ];
        
        // big copy
        $big_copy = [];
        foreach ( $fn_params as $k => $v ) {
            if ( substr( $k, 0, 8 ) == 'bigpost_' ) {
                $big_copy[ substr( $k, 8 ) ] = $v;
            }
        }
        $big_copy[ 'layout' ] = 'grid';
        $big_copy = foxfw3_fn_params( $big_copy );
        foreach ( $big_copy as $k => $v ) {
            $fn_params[ 'group1_big_' . $k ] = $v;
        }
        
        // small copy
        $small_copy = [];
        foreach ( $fn_params as $k => $v ) {
            if ( substr( $k, 0, 12 ) == 'small_posts_' ) {
                $small_copy[ substr( $k, 12 ) ] = $v;
            }
        }
        $small_copy[ 'layout' ] = 'list';
        $small_copy = foxfw3_fn_params( $small_copy );
        foreach ( $small_copy as $k => $v ) {
            $fn_params[ 'group1_small_' . $k ] = $v;
        }
        
    }
    
    
    // change prefix, just a legacy
    if ( 'group-2' == $fn_params[ 'layout' ] ) {
        
        $fn_params[ 'group2_columns_order' ] = $fn_params[ 'columns_order' ];
        $fn_params[ 'group2_sep_border' ] = $fn_params[ 'sep_border' ];
        $fn_params[ 'group2_sep_border_color' ] = $fn_params[ 'sep_border_color' ];
        
        // big copy
        $big_copy = [];
        foreach ( $fn_params as $k => $v ) {
            if ( substr( $k, 0, 8 ) == 'bigpost_' ) {
                $big_copy[ substr( $k, 8 ) ] = $v;
            }
        }
        $big_copy[ 'layout' ] = 'grid';
        $big_copy = foxfw3_fn_params( $big_copy );
        foreach ( $big_copy as $k => $v ) {
            $fn_params[ 'group2_big_' . $k ] = $v;
        }
        
        // medium copy
        $medium_copy = [];
        foreach ( $fn_params as $k => $v ) {
            if ( substr( $k, 0, 12 ) == 'medium_post_' ) {
                $medium_copy[ substr( $k, 12 ) ] = $v;
            }
        }
        $medium_copy[ 'layout' ] = 'grid';
        $medium_copy = foxfw3_fn_params( $medium_copy );
        foreach ( $medium_copy as $k => $v ) {
            $fn_params[ 'group2_medium_' . $k ] = $v;
        }
        
        // small copy
        $small_copy = [];
        foreach ( $fn_params as $k => $v ) {
            if ( substr( $k, 0, 12 ) == 'small_posts_' ) {
                $small_copy[ substr( $k, 12 ) ] = $v;
            }
        }
        $small_copy[ 'layout' ] = 'grid';
        $small_copy = foxfw3_fn_params( $small_copy );
        foreach ( $small_copy as $k => $v ) {
            $fn_params[ 'group2_small_' . $k ] = $v;
        }
        
    }
    
    return $fn_params;
    
}

function foxfw3_get_params( $base = '' ) {
    
    $params = [];
    
    /* STANDARD
    ------------------------------------------------------------------------------------------------------------------------ */
    if ( 'standard' == $base ) {
    
        $params[] = [
            'type' => 'heading',
            'title' => 'General Layout',
        ];
        
        $params[ 'header_align' ] = array(
            'title' => 'Header text align',
            'type' => 'select',
            'options' => array(
                '' => 'Default',
                'left' => 'Left',
                'center' => 'Center',
                'right' => 'Right',
            ),
            'std' => '',
        );
        
        $params[ 'text_color' ] = array(
            'title' => 'Custom Text Color',
            'type' => 'color',
        );
        
        $params[ 'content_excerpt' ] = array(
            'title' => 'Display content/excerpt',
            'type' => 'select',
            'options' => [
                'content' => 'Full Content',
                'excerpt' => 'Excerpt',
            ],
            'std' => 'excerpt',
        );
        
        $params[ 'thumbnail_type' ] = array (
            'title' => 'Thumbnail type',
            'type' => 'select',
            'options' => [
                'advanced' => 'Full slider, video etc',
                'simple' => 'Just simple image thumbnail',
            ],
            'std' => 'simple',
        );
        
        /* Elements
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Elements',
        ];
        
        $params[ 'show_thumbnail' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show thumbnail',
        );
        
        $params[ 'thumbnail_shape' ] = array(
            'type'  => 'select',
            'std'   => 'acute',
            'options' => [
                'acute'     => 'Acute',
                'round'     => 'Round',
                'circle'    => 'Circle',
            ],
            'title' => 'Thumbnail shape',
        );
        
        $params[ 'show_title' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show title',
        );
        
        $params[ 'excerpt_more' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show excerpt more',
        );
        
        $params[ 'show_date' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show date',
        );
        
        $params[ 'show_category' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show category',
        );
        
        $params[ 'show_author' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show author',
        );
        
        $params[ 'show_author_avatar' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show author avatar',
        );
        
        $params[ 'show_comment_link' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show comment link',
        );
        
        $params[ 'show_view' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show view count',
        );
        
        $params[ 'show_reading_time' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show reading time',
        );
        
        $params[ 'show_share' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show share icons',
        );
        
        $params[ 'show_related' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show related posts',
        );
    
    }
    
    /* GRID
    ------------------------------------------------------------------------------------------------------------------------ */
    if ( 'grid' == $base ) {
        
        /* General Layout
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'General Layout',
        ];
        
        $params[ 'column' ] = array(
            'type' => 'select',
            'options' => [
                '1' => '1 column',
                '2' => '2 columns',
                '3' => '3 columns',
                '4' => '4 columns',
                '5' => '5 columns',
                '6' => '6 columns',
            ],
            'std' => '3',
            'title' => 'Column',
        );
        
        $params[ 'first_standard' ] = array(
            'title' => 'First post is standard layout?',
            'type' => 'switcher',
            'std' => '',
        );
        
        $params[ 'item_card' ] = array(
            'title' => 'Card Style',
            'type' => 'select',
            'std' => 'none',
            'options' => [
                'none' => 'None',
                'normal' => 'Normal',
                'normal_no_shadow' => 'Normal + no shadow',
                'overlap' => 'Text Overlaps Image',
                'overlap_no_shadow' => 'Overlap + no shadow',
            ],
        );
        
        $params[ 'item_card_background' ] = array(
            'title' => 'Card Background',
            'type' => 'color',
        );
        
        $params[ 'item_spacing' ] = array(
            'type' => 'select',
            'options' => [
                'none' => 'No spacing',
                'tiny' => 'Tiny',
                'small' => 'Small',
                'normal' => 'Normal',
                'wide' => 'Wide',
                'wider' => 'Wider',
            ],
            'std' => 'normal',
            'title' => 'Item spacing (Grid/Masonry)',
        );
        
        $params[ 'item_align' ] = array(
            'title' => 'Item alignment (Grid/Masonry)',
            'type' => 'select',
            'options' => array(
                '' => 'Default',
                'left' => 'Left',
                'center' => 'Center',
                'right' => 'Right',
            ),
            'std' => '',
        );
        
        $params[ 'item_template' ] = array(
            'title' => 'Elements order',
            'type' => 'select',
            
            'options' => [
                '1' => 'Title > Meta > Excerpt',
                '2' => 'Meta > Title > Excerpt',
                '3' => 'Title > Excerpt > Meta',
        
                '4' => 'Category > Title > Meta > Excerpt',
                '5' => 'Category > Title > Excerpt > Meta',
            ],
            'std' => '1',
        );
        
        $params[ 'item_border' ] = [
            'title' => 'Vertical border between items',
            'type' => 'switcher',
            'std' => 'no',
        ];

        $params[ 'item_border_color' ] = [
            'title' => 'Border color?',
            'type' => 'color',
        ];
        
        $params[ 'text_color' ] = array(
            'title' => 'Custom Text Color',
            'type' => 'color',
        );
        
        $params[ 'list_sep' ] = array(
            'type' => 'switcher',
            'title' => 'Sep between list items',
            'std' => 'yes',
        );
        
        $params[ 'list_sep_style' ] = array(
            'type' => 'select',
            'options' => [
                'solid' => 'Solid',
                'dashed' => 'Dashed',
                'dotted' => 'Dotted',
            ],
            'std' => 'solid',
            'title' => 'List sep border style',
        );
        
        $params[ 'list_sep_color' ] = array(
            'type' => 'color',
            'title' => 'List separator color',
        );
        
        $params[ 'list_spacing' ] = array(
            'type' => 'select',
            'title' => 'Spacing between list items',
            'std' => 'normal',
            'options' => [
                'none' => 'No Spacing',
                'tiny' => 'Tiny',
                'small' => 'Small',
                'normal' => 'Normal',
                'medium' => 'Medium',
                'large' => 'Large',
            ],
            'std' => 'normal',
        );
        
        $params[ 'list_valign' ] = array(
            'type' => 'select',
            'title' => 'Post list vertical align',
            'std' => 'top',
            'options' => [
                'top' => 'Top',
                'middle' => 'Middle',
                'bottom' => 'Bottom',
            ],
            'std' => 'top',
        );
    
        /* Thumbnail
         * ------------------------ */
        $params[ 'thumbnail_heading' ] = [
            'type' => 'heading',
            'title' => 'Thumbnail',
            
            'section' => 'thumbnail',
            'section_title' => 'Thumbnail',
        ];
        
        $params[ 'show_thumbnail' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show thumbnail',
        );
        
        $params[ 'thumbnail_position' ] = array(
            'type' => 'select',
            'options'   => [
                'left' => 'Left',
                'right' => 'Right',
                'alternative' => 'Alternative',
            ],
            'std' => 'left',
            'title' => 'Thumbnail position (List/Vertical layout)',
        );
        
        $params[ 'thumbnail_width' ] = array(
            'type' => 'text',
            'placeholder' => 'Eg. 320px',
            'title' => 'Thumbnail width (List layout)',
        );
        
        $params[ 'list_mobile_layout' ] = array(
            'type' => 'select',
            'title' => 'Mobile Layout (for List layout)',
            'options' => [
                'list' => 'Still list as desktop',
                'grid' => 'Stack (Image above, content below)',
            ],
            'std'   => 'grid',
        );
        
        $params[ 'thumbnail' ] = array(
            'type' => 'select',
            'options' => [
                'thumbnail' => 'Thumbnail (150x150)',
                
                'landscape' => 'Medium crop (480x384)',
                'square' => 'Square crop (480x480)',
                'portrait' => 'Portrait crop (480x600)',
                'thumbnail-large' => 'Large crop (720x480)',
                
                'medium' => 'Medium (no crop)',
                'large' => 'Large (no crop)',
        
                'original' => 'Original ratio (Fullwidth)',
                'original_fixed' => 'Original ratio (Fixed height)',
                'custom' => 'Custom',
            ],
            'std' => 'landscape',
            'title' => 'Thumbnail',
        );

        $params[ 'thumbnail_custom' ] = array(
            'type' => 'text',
            'title' => 'Custom Size (Eg. 425x360)',
        );

        $params[ 'thumbnail_placeholder' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Placeholder thumbnail',
            'desc' => 'For posts dont have a thumbnail'
        );

        $params[ 'thumbnail_shape' ] = array(
            'type'  => 'select',
            'std'   => 'acute',
            'options' => [
                'acute'     => 'Acute',
                'round'     => 'Round',
                'circle'    => 'Circle',
            ],
            'title' => 'Thumbnail shape',
        );
        
        $params[ 'thumbnail_hover_effect' ] = array(
            'type'  => 'select',
            'std'   => 'none',
            'options' => [
                'none'      => 'None',
                'fade'      => 'Image Fade',
                'grayscale' => 'Grayscale',
                'sepia'     => 'Sepia',
                'dark'      => 'Dark',
                'letter'    => 'Title First Letter',
                'zoomin'    => 'Image Zoom In',
                'logo'      => 'Custom Logo',
            ],
            'title' => 'Thumbnail hover effect',
        );
        
        $params[ 'thumbnail_hover_logo' ] = array(
            'type'  => 'image',
            'title' => 'Thumbnail hover logo',
        );
        
        $params[ 'thumbnail_hover_logo_width' ] = array(
            'type'  => 'text',
            'std'   => '40%',
            'title' => 'Thumbnail hover logo width',
            'desc' => 'Please enter a number in percentage.',
        );
        
        $params[ 'thumbnail_showing_effect' ] = array(
            'type'  => 'select',
            'std'   => 'none',
            'options' => [
                'none'      => 'None',
                'fade'      => 'Image Fade',
                'slide'     => 'Slide',
                'popup'     => 'Pop up',
                'zoomin'    => 'Zoom In',
            ],
            'title' => 'Thumbnail showing effect',
        );
        
        $params[ 'format_indicator' ] = array(
            'type'  => 'switcher',
            'std'   => 'yes',
            'title' => 'Show format indicator',
        );
        
        $params[ 'thumbnail_index' ] = array(
            'type'  => 'switcher',
            'std'   => '',
            'title' => 'Index 01, 02.. on thumbnail',
        );
        
        $params[ 'thumbnail_view' ] = array(
            'type'  => 'switcher',
            'std'   => '',
            'title' => 'Display view count',
        );
        
        /* Title
         * ------------------------ */
        $params[ 'title_heading' ] = [
            'type' => 'heading',
            'title' => 'Title',
            
            'section' => 'text',
            'section_title' => 'Text',
        ];
        
        $params[ 'show_title' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show title',
        );
        
        $params[ 'title_tag' ] = array(
            'type' => 'select',
            'options' => [
                'h2' => 'H2',
                'h3' => 'H3',
                'h4' => 'H4',
            ],
            'std' => 'h2',
            'title' => 'Title tag',
        );
        
        $params[ 'title_size' ] = array(
            'type'  => 'select',
            'std'   => 'normal',
            'options' => [
                'supertiny' => 'Super Tiny',
                'tiny' => 'Tiny',
                'small' => 'Small',
                'normal' => 'Normal',
                'medium' => 'Medium',
                'large' => 'Large',
            ],
            'title' => 'Title size',
        );
        
        $params[ 'title_weight' ] = array(
            'type'  => 'select',
            'std'   => '',
            'options' => [
                '' => 'Default',
                '300' => 'Light',
                '400' => 'Normal',
                '700' => 'Bold',
                '900' => 'Heavy',
            ],
            'title' => 'Title weight',
        );
        
        $params[ 'title_text_transform' ] = array(
            'type'  => 'select',
            'std'   => '',
            'options' => [
                '' => 'Default',
                'none' => 'None',
                'lowercase' => 'lowercase',
                'uppercase' => 'UPPERCASE',
                'capitalize' => 'Capitalize',
            ],
            'title' => 'Title text transform',
        );
        
        $params[ 'title_color' ] = [
            'type' => 'color',
            'title' => 'Title color',
        ];
        
        /* Excerpt
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Excerpt',
        ];
        
        $params[ 'show_excerpt' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Display excerpt?',
        );

        $params[ 'excerpt_length' ] = array(
            'type' => 'text',
            'std' => '22',
            'title' => 'Excerpt length',
        );
        
        $params[ 'excerpt_size' ] = array(
            'type' => 'select',
            'options' => [
                'small' => 'Small',
                'normal' => 'Normal',
                'medium' => 'Medium',
            ],
            'title' => 'Excerpt font size',
            'std'   => 'normal',
        );
        
        $params[ 'excerpt_color' ] = array(
            'type' => 'color',
            'title' => 'Excerpt custom color',
        );

        $params[ 'excerpt_more' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'More Link',
        );
        
        $params[ 'excerpt_more_style' ] = array(
            'type' => 'select',
            'options' => [
                'simple' => 'Plain Link',
                'simple-btn' => 'Minimal Link', // simple button
                'btn' => 'Fill Button', // default btn
                'btn-black' => 'Solid Black Button',
                'btn-primary' => 'Primary Button',
            ],
            'std' => 'simple',
            'title' => 'More text style',
        );
        
        $params[ 'excerpt_more_text' ] = array(
            'type' => 'text',
            'placeholder' => 'More',
            'title' => 'Custom More Text',
        );
        
        /* Date
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Date',
        ];
        
        $params[ 'show_date' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show post date',
        );
        
        /* Category
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Category',
        ];
        
        $params[ 'show_category' ] = array(
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show post categories',
        );

        /* Author
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Author',
        ];
        
        $params[ 'show_author' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show post author',
        );

        $params[ 'show_author_avatar' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show author avatar',
        );

        /* View count
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'View Count',
        ];
        
        $params[ 'show_view' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show view count',
        );

        /* Comment link
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Comment Link',
        ];
        
        $params[ 'show_comment_link' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show comment link',
        );

        /* Reading Time
         * ------------------------ */
        $params[] = [
            'type' => 'heading',
            'title' => 'Reading Time',
        ];
        
        $params[ 'show_reading_time' ] = array(
            'type' => 'switcher',
            'std' => '',
            'title' => 'Show reading time',
        );
    
    }
    
    return $params;

}

/* BUTTON
------------------------------------------------------------------------------------------------ */
if ( ! function_exists( 'foxfw3_btn_params' ) ) :
    /**
     * Button Params
     * This function helps implementing fox button in many places: widget, theme option or page builder
     * @since 4.0
     */
    function foxfw3_btn_params( $args = [] ) {
        
        extract( wp_parse_args( $args, [
            'include' => [],
            'exclude' => [],
            'override' => []
        ] ) );
        
        $params = [];
        
        $params[ 'text' ] = array(
            'type' => 'text',
            'title' => 'Button',
            'std' => 'Click here',
    
            'section' => 'button',
            'section_title' => 'Button',
        );
    
        $params[ 'url' ] = array(
            'type' => 'text',
            'title' => 'URL',
        );
    
        $params[ 'target' ] = array(
            'type' => 'select',
            'title' => 'Open link in',
            'options' => [
                '_self' => 'Current tab',
                '_blank' => 'New tab',
            ],
            'std' => '_self',
        );
    
        $params[ 'icon' ] = array(
            'name' => 'Icon',
            'type' => 'text',
            'desc' => 'Enter fontawesome icon from <a href="https://fontawesome.com/icons/" target="_blank">this list</a>',
        );
        
        $params[ 'size' ] = array(
            'name' => 'Size',
            'type' => 'select',
            'options' => array(
                'tiny' => 'Tiny',
                'small' => 'Small',
                'normal' => 'Normal',
                'medium' => 'Medium',
                'large' => 'Large',
            ),
            'std' => 'normal',
        );
    
        $params[ 'style' ] = array(
            'name' => 'Style',
            'type' => 'select',
            'options' => array(
                'primary' => 'Primary',
                'outline' => 'Outline',
                'fill' => 'Fill',
                'black' => 'Black',
            ),
            'std' => 'black',
        );
        
        $params[ 'border_width' ] = array(
            'name' => 'Border Width',
            'type' => 'select',
            'options' => array(
                '' => 'Default',
                '0' => 'None',
                '1px' => '1px',
                '2px' => '2px',
                '3px' => '3px',
                '4px' => '4px',
                '5px' => '5px',
            ),
            'std' => '',
        );
        
        $params[ 'shape' ] = array(
            'name' => 'Shape',
            'type' => 'select',
            'options' => array(
                'square' => 'Square',
                'round' => 'Round',
                'pill' => 'Pill',
            ),
            'std' => 'square',
        );
    
        $params[ 'align' ] = array(
            'name' => 'Align',
            'type' => 'select',
            'options' => array(
                'inline' => 'Inline',
                'left' => 'Left',
                'center' => 'Center',
                'right' => 'Right',
            ),
            'std' => 'inline',
        );
        
        $params[ 'block' ] = array(
            'name' => 'Block Button',
            'type' => 'select',
            'options' => array(
                'none' => 'None',
                'full' => 'Full-width',
                'half' => 'Half-width',
                'third' => 'Third-width',
            ),
            'std' => 'none',
        );
        
        $params[ 'extra_class' ] = array(
            'name' => 'Extra Class',
            'type' => 'text',
            'desc' => 'Enter your custom CSS class',
        );
        
        $params[ 'attr' ] = array(
            'name' => 'Additional Attributes',
            'type' => 'textarea',
            'desc' => 'Enter your custom attributes here. Make sure you know what you are doing.',
        );
        
        /**
         * Custom Color Options
         */
        $params[ 'text_color' ] = array(
            'name' => 'Text Color',
            'type' => 'color',
            
            'section' => 'color',
            'section_title' => 'Color',
        );
    
        $params[ 'bg_color' ] = array(
            'name' => 'Background Color',
            'type' => 'color',
        );
        
        $params[ 'border_color' ] = array(
            'name' => 'Border Color',
            'type' => 'color',
        );
        
        $params[ 'text_color_hover' ] = array(
            'name' => 'Hover Text Color',
            'type' => 'color',
        );
    
        $params[ 'bg_color_hover' ] = array(
            'name' => 'Hover Background Color',
            'type' => 'color',
        );
        
        $params[ 'border_color_hover' ] = array(
            'name' => 'Hover Border Color',
            'type' => 'color',
        );
        
        // only include
        if ( ! empty( $include ) ) {
            foreach ( $params as $id => $param ) {
                if ( ! in_array( $id, $include ) ) unset( $params[ $id ] );
            }
        }
        
        // exclude
        if ( ! empty( $exclude ) ) {
            foreach ( $params as $id => $param ) {
                if ( in_array( $id, $exclude ) ) unset( $params[ $id ] );
            }
        }
        
        // override
        if ( ! empty( $override ) ) {
            foreach ( $override as $id => $param ) {
                $params[ $id ] = $param;
            }
        }
        
        // name vs title
        // and id
        foreach ( $params as $id => $param ) {
            
            // to use in widget / metabox
            $param[ 'id' ] = $id;
            
            // name vs title
            if ( isset( $param[ 'title' ] ) ) $param[ 'name' ] = $param[ 'title' ];
            elseif ( isset( $param[ 'name' ] ) ) $param[ 'title' ] = $param[ 'name' ];
            
            $params[ $id ] = $param;
            
        }
        
        return apply_filters( 'fox_btn_params', $params );
        
    }
endif;
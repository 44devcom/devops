<?php
/* Query
---------------------------------------------------------------- */ 
$params[ 'source' ] = array(
    'type' => 'select',
    'options' => [
        'post_tag' => 'Tags',
        'category' => 'Categories',
        'tax' => 'Custom Taxonomy',
        'single_post_tag' => 'Post Tags (For Single Templates)',
        'single_category' => 'Post Categories (For Single Templates)',
        'single_tax' => 'Post Taxonomy (For Single Taxonomy)',
    ],
    'std' => 'post_tag',
    'title' => 'Source',
    'desc' => 'If you choose 3 latter options, please use it for Single Template only. It queries post tags, categories.. for only that post instead of general tags, categories.',
    
    'section' => 'query',
    'section_title' => 'Query',
);

$params[ 'tax' ] = array(
    'type' => 'text',
    'title' => 'Enter custom taxonomy',
    
    'condition' => [
        'source[value]' => [ 'tax', 'single_tax' ],
    ]
);

$params[ 'number' ] = array(
    'type' => 'text',
    'title' => 'Number',
    
    'condition' => [
        'source[value]' => [ 'post_tag', 'category', 'tax' ],
    ],
);

$params[ 'orderby' ] = array(
    'type' => 'select',
    'options' => [
        'name' => 'Name',
        'slug' => 'Slug',
        'count' => 'Post Count',
    ],
    'std' => 'name',
    'title' => 'Order by',
    
    'condition' => [
        'source[value]' => [ 'post_tag', 'category', 'tax' ],
    ],
);

$params[ 'order' ] = array(
    'type' => 'select',
    'options' => [
        'ASC' => 'Ascending',
        'DESC' => 'Descending',
    ],
    'std' => 'ASC',
    'title' => 'Order',
    
    'condition' => [
        'source[value]' => [ 'post_tag', 'category', 'tax' ],
    ],
);

$params[ 'include' ] = [
    'type' => 'textarea',
    'title' => 'Include only IDs:',
    'desc' => 'Separate IDs by comma',
    
    'condition' => [
        'source[value]' => [ 'post_tag', 'category', 'tax' ],
    ],
];

$params[ 'exclude' ] = [
    'type' => 'text',
    'title' => 'Exclude IDs:',
    'desc' => 'Separate IDs by comma',
    
    'condition' => [
        'source[value]' => [ 'post_tag', 'category', 'tax' ],
    ],
];

$params[ 'hide_empty' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Hide Empty',
    
    'condition' => [
        'source[value]' => [ 'post_tag', 'category', 'tax' ],
    ],
);

/* Settings
---------------------------------------------------------------- */
$params[ 'align' ] = array(
    'type' => 'align',
    'title' => 'Alignment',
    'options' => [ 'left', 'center', 'right' ],
    'std' => 'left',
    
    'section' => 'settings',
    'section_title' => 'Settings',
);

$params[ 'item_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-tax a',
    'title' => 'Item Typography',
);

$params[ 'item_spacing' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .el-tax li' => 'margin-bottom:{{SIZE}}{{UNIT}};margin-right:{{SIZE}}{{UNIT}};',
    ],
    'title' => 'Item spacing',
    
    'std_size' => 5,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 30,
);

$params[ 'item_padding' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .el-tax a' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
    ],
    'title' => 'Item padding',
    
    'std_size' => 8,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 50,
);

$params[ 'item_border_radius' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .el-tax a' => 'border-radius:{{SIZE}}{{UNIT}};',
    ],
    'title' => 'Item border radius',
    
    'std_size' => 0,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 50,
);

$params[ 'item_border_width' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .el-tax a' => 'border-width:{{SIZE}}{{UNIT}};',
    ],
    'title' => 'Item border thickness',
    
    'std_size' => 0,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 10,
);

/* style
------------------------------ */
$params[ 'item_color' ] = array(
    'type' => 'color',
    'title' => 'Item text color',
    'selectors' => [
        '{{WRAPPER}} .el-tax a' => 'color:{{VALUE}};',    
    ],
    
    'tabs' => 'item_style',
    'tab' => 'normal',
    'tab_title' => 'Normal',
);

$params[ 'item_background' ] = array(
    'type' => 'color',
    'title' => 'Item background',
    'selectors' => [
        '{{WRAPPER}} .el-tax a' => 'background:{{VALUE}};',
    ],
);

$params[ 'item_border_color' ] = array(
    'type' => 'color',
    'title' => 'Item border color',
    'selectors' => [
        '{{WRAPPER}} .el-tax a' => 'border-color:{{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

// hover
$params[ 'item_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Item hover text color',
    'selectors' => [
        '{{WRAPPER}} .el-tax a:hover' => 'color:{{VALUE}};',    
    ],
    
    'tab' => 'hover',
    'tab_title' => 'Hover',
);

$params[ 'item_hover_background' ] = array(
    'type' => 'color',
    'title' => 'Item hover background',
    'selectors' => [
        '{{WRAPPER}} .el-tax a:hover' => 'background:{{VALUE}};',
    ],
);

$params[ 'item_hover_border_color' ] = array(
    'type' => 'color',
    'title' => 'Item hover border color',
    'selectors' => [
        '{{WRAPPER}} .el-tax a:hover' => 'border-color:{{VALUE}};',
    ],
);

$params[] = [
    'type' => 'tab_close',
];

$params[] = [
    'type' => 'tabs_close',
];

/* Heading
---------------------------------------------------------------- */
$params[ 'heading' ] = array(
    'type' => 'text',
    'title' => 'Heading Text',
    'std' => '',
    
    'section' => 'heading',
    'section_title' => 'Heading',
);

$params[ 'heading_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-tax-heading',
    'title' => 'Heading typography',
);

$params[ 'heading_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-tax-heading' => 'color:{{VALUE}};'
    ],
    'title' => 'Heading color',
);

$params[ 'heading_tax_spacing' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .el-tax-heading' => 'margin-bottom:{{SIZE}}{{UNIT}};'
    ],
    'title' => 'Heading spacing',
    
    'std_size' => 10,
    'std_unit' => 'px',
    'px_min' => 0,
    'px_max' => 60,
);

/* Post Count
---------------------------------------------------------------- */
$params[ 'show_count' ] = array(
    'type' => 'switcher',
    'title' => 'Show post count',
    'std' => 'no',
    
    'section' => 'post_count',
    'section_title' => 'Post Count',
);

$params[ 'count_typography' ] = array(
    'type' => 'typography',
    'selector' => '{{WRAPPER}} .el-tax a sup',
    'title' => 'Post Count Typography',
);

$params[ 'count_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-tax a sup' => 'color:{{VALUE}};'
    ],
    'title' => 'Post Count color',
);

$params[ 'count_hover_color' ] = array(
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .el-tax a:hover sup' => 'color:{{VALUE}};'
    ],
    'title' => 'Item hover count color',
);
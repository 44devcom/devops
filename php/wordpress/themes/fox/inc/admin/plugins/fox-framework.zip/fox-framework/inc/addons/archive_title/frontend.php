<?php
$settings = $this->get_settings_for_display();

extract( wp_parse_args( $settings, [
    'disable_on_author_page' => 'no',
]) );

$cl = [ 'el-archive-title' ];

/**
 * final
 */
$cl = join( ' ', $cl );

if ( fox_is_edit() ) {
    $result = 'Archive Title';
} else {
    if ( 'yes' == $disable_on_author_page && is_author() ) {
        $result = '';
    } else {
        
        $title = '';
        if ( is_category() || is_tag() ) {
            $term = get_queried_object();
            if ( $term ) {
                $title = $term->name;
            }
        } elseif ( is_search() ) {
            $title  = get_search_query();
            
        } elseif ( is_day() ) {
    
            $title = get_the_time( 'F d, Y' );
    
        } elseif ( is_month() ) {
            
            $title = get_the_time('F Y');
            
        } elseif ( is_year() ) {
            
            $title = get_the_time('Y');
            
        } elseif ( is_404() ) {
            
            if ( is_engine_v6() ) {
                $title = get_theme_mod( 'page_404_title' );
            } elseif ( defined( 'FOX_VERSION') ) {
                $title = get_theme_mod( 'wi_page_404_title' );
            }
            if ( ! $title ) {
                $title = esc_html__( 'Page Not Found', 'wi' );
            }
            
        } elseif ( is_archive() ) {
            
            $title = get_the_archive_title();
            
        }
        $paged = get_query_var( 'paged' );
        if ( $paged ) {
            $page_text = '<span class="paged-label">' . sprintf( foxfw3_word( 'paged' ), $paged ) . '</span>';
            if ( $title ) {
                $title = $title . $page_text;
            }
        }

        $result = $title;

    }
}

if ( empty( $result ) ) {
    return;
}
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    
    <h1 class="el-title-tag"><?php echo $result; ?></h1>
    
</div>
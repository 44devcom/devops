<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'components' => [],
    'meta_separator' => '&middot;',
    'meta_link_underline' => 'none',
]) );

$cl = [ 'el-single-meta' ];

/**
 * meta_link_underline
 */
$cl[] = 'style-link-underline-' . $meta_link_underline;
    
/**
 * final
 */
$cl = join( ' ', $cl );
$count = 0;

$collect_inner = [];

foreach ( (array) $components as $com ) {
    
    extract( wp_parse_args( $com, [
        'type' => '',
    ]) );
    
    ob_start();
    
    switch( $type ) {
            
        /* Date
        ------------------------ */
        case 'date' :
            
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { 
                if ( isset( $com[ 'date_format' ] ) && $com[ 'date_format' ] ) {
                    $format = $com[ 'date_format' ];
                } else {
                    $format = 'M d, Y';
                }
                ?>
                <span><?php echo date( $format, time() ); ?></span>
                <?php
            } elseif ( function_exists( 'fox_elementor_post_date' ) ) {
                $args = [];
                if ( isset( $com[ 'date_format' ] ) && $com[ 'date_format' ] ) {
                    $args[ 'format' ] = $com[ 'date_format' ];
                }
                fox_elementor_post_date( $args );
            }
            break;
            
        /* Category
        ------------------------ */
        case 'category' :
            
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { ?>
                <div class="entry-categories">
                    <a href="#">Sample Category</a>
                </div>
            
            <?php } else {
                if ( is_engine_v6() ) {
                    fox56_meta_categories();
                } elseif ( defined( 'FOX_VERSION' ) ) {
                    fox_post_categories();
                }
            }
            break;
           
        /* Author
        ------------------------ */
        case 'author' :
            
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { ?>
    <div class="entry-author fox-meta-author">
        <?php if ( 'yes' == $author_avatar ) { ?>
        <a href="#" class="meta-author-avatar">
            <img src="<?php echo FOX_ELEMENTOR_URL; ?>images/avatar.jpg" alt="Avatar" width="200" />
        </a>
        <?php } ?>
        <span class="byline">
            by <a href="#">Jone Doe</a>
        </span>
    </div>
            <?php } else {
                $show_avatar = isset( $com[ 'author_avatar' ] ) && 'yes' == $com[ 'author_avatar' ];
                if ( is_engine_v6() ) {
                    fox56_meta_author([
                        'author_avatar' => $show_avatar
                    ]);
                } elseif ( defined( 'FOX_VERSION' ) ) {
                    fox_post_author( $show_avatar );
                }
            }
            break;
          
        /* View
        ------------------------ */
        case 'view' :
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { ?>
    <div class="entry-view">
        100 views
    </div>
            <?php } else {
                if ( is_engine_v6() ) {
                    fox56_meta_view([
                        'author_avatar' => $show_avatar
                    ]);
                } elseif ( defined( 'FOX_VERSION' ) ) {
                    fox_post_view(); 
                }
            }
            break;
            
        /* Comment
        ------------------------ */
        case 'comment' :
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { ?>
    <div class="entry-comment-link">
        <a href="#">2 comments</a>
    </div>
            <?php } else {
                if ( is_engine_v6() ) {
                    fox56_meta_comment_link();
                } elseif ( defined( 'FOX_VERSION' ) ) {
                    fox_comment_link(); 
                }
            }
            break;
         
        /* Reading Time
        ------------------------ */
        case 'reading' :
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { ?>
    <div class="entry-reading-time">
        <a href="#">2 mins reading</a>
    </div>
            <?php } else {
                if ( is_engine_v6() ) {
                    fox56_meta_reading_time(); 
                } elseif ( defined( 'FOX_VERSION' ) ) {
                    fox_reading_time(); 
                }
            }
            break;
            
        /* Live
        ------------------------ */
        case 'live' :
            if ( fox_is_edit() || is_singular( 'elementor_library' ) ) { ?>
    <span class="live-indicator">
        <span class="live-circle"></span>
        <span class="live-word"><?php if ( function_exists( 'fox_word' ) ) { echo fox_word( 'live' ); } ?></span>
        <span class="live-updated">
            <time class="published" itemprop="dateModified" datetime="<?php echo get_the_modified_date( DATE_W3C ); ?>">
                <?php if ( function_exists( 'fox_word' ) ) { echo fox_word( 'justnow' ); } ?>
            </time>
        </span>
    </span>
            <?php } else {
                if ( is_engine_v6() ) {
                    fox56_live_indicator(); 
                } elseif ( defined( 'FOX_VERSION' ) ) {
                    fox_live_indicator(); 
                }
            }
            break;
            
        default:
            break;
            
    }
    
    $item = ob_get_clean();
    if ( ! empty( $item ) ) {
        $collect_inner[] = $item;
    }
    
} // foreach

if ( empty( $collect_inner ) ) {
    return;
} ?>

<div class="<?php echo esc_attr( $cl ); ?>">
    <?php echo join( '<span class="sep">' . $meta_separator . '</span>', $collect_inner ); ?>
</div>
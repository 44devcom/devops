<?php
$params[ 'demo_image' ] = array(
    'type' => 'media',
    'title' => 'Demo image',
    'desc' => 'In your actual post, this will be replaced by your post thumbnail. However, to make it easier to imagine, you can upload a demo image here.',
    
    'section' => 'general',
    'section_title' => 'General',
);

$params[ 'size' ] = array(
    'type' => 'image_size',
    'title' => 'Thumbnail size',
    'std' => 'full',
    'name' => 'thumbnail',
);
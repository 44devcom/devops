<?php
$params = [];

$params[ 'source' ] = array(
    'title' => 'Ads Source',
    'type' => 'select',
    'options' => [
        'banner' => 'Responsive Image Banner',
        'code' => 'Custom Code',
    ],
    'std' => 'banner',

    'section' => 'settings',
    'section_title' => 'Settings',
);
    
$params[ 'code' ] = array(
    'title' => esc_html__( 'Custom Ad Code', 'wi' ),
    'type' => 'textarea',

    'condition' => [
        'source[value]' => 'code',
    ],
);

/* DESKTOP
------------------------------------ */
$params[ 'image' ] = array(
    'title' => 'Upload Image',
    'type' => 'media',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

$params[ 'image_width' ] = array(
    'title' => 'Image width (Responsive)',
    'desc' => 'You can adjust image size on tablet and mobile',
    'type' => 'size',
    
    'std_size' => 728,
    'std_unit' => 'px',
    'px_min' => 100,
    'px_max' => 1500,
    
    'selectors' => array(
        '{{WRAPPER}} .el-banner .the-banner' => 'width:{{SIZE}}{{UNIT}};' 
    ),
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

$params[ 'link' ] = array(
    'title' => 'Image link',
    'type' => 'url',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

/* TABLET
------------------------------------ */
$params[ 'tablet_heading' ] = array(
    'title' => 'Tablet',
    'type' => 'heading',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

$params[ 'tablet_image' ] = array(
    'title' => 'Custom image for tablet',
    'type' => 'media',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

$params[ 'tablet_link' ] = array(
    'title' => 'Custom link for tablet',
    'type' => 'url',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

/* MOBILE
------------------------------------ */
$params[ 'mobile_heading' ] = array(
    'title' => 'Mobile',
    'type' => 'heading',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

$params[ 'mobile_image' ] = array(
    'title' => 'Custom image for mobile',
    'type' => 'media',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);

$params[ 'mobile_link' ] = array(
    'title' => 'Custom link for mobile',
    'desc' => 'You may add custom link to App Store on mobile for instance',
    'type' => 'url',
    
    'condition' => [
        'source[value]' => 'banner',
    ],
);
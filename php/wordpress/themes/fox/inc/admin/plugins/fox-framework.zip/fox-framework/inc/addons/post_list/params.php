<?php
/* query params
----------------------------------- */
$params += foxfw3_query_params();

// since Fox v5.4
$params[ 'column' ] = array(
    'type' => 'select',
    'options' => [
        '1' => '1 column',
        '2' => '2 columns',
        '3' => '3 columns',
        '4' => '4 columns',
    ],
    'std' => '1',
    'title' => 'Column (Experimental)',
    'desc' => 'This is an experimental feature. It may cause some small bugs in combination with other options. If you found one, please give us a feedback <a href="https://withemes.ticksy.com/" target="_blank">in our support desk</a>',
    
    'section' => 'layout',
    'section_title' => 'Layout',
);

$params[ 'list_hspacing' ] = array(
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .blog-list.columnized' => 'margin-left:-{{SIZE}}{{UNIT}};margin-right:-{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .blog-list.columnized .post-list' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
    ],
    'title' => 'Horizontal Spacing',

    'std_unit' => 'px',
    'std_size' => 10,
    'px_max' => 60,
    'px_min' => 0,
    
    'condition' => array( 
        'column[value]' => [ '2', '3', '4' ]
    ),
);

/**
 * we need this because of the legacy reason
 */
$params[ 'list_spacing_type' ] = array(
    'type' => 'select',
    'options' => [
        'predefined' => 'Predefined',
        'custom' => 'Custom',
    ],
    'std' => 'predefined',
    'title' => 'Item spacing type',
);

    $params[ 'list_spacing' ] = array(
        'type' => 'select',
        'options' => [
            'none' => 'No spacing',
            'tiny' => 'Tiny',
            'small' => 'Small',
            'normal' => 'Normal',
            'wide' => 'Wide',
            'wider' => 'Wider',
        ],
        'std' => 'normal',
        'title' => 'Item spacing',
        'condition' => array( 'list_spacing_type[value]' => 'predefined' ),
    );

    $params[ 'list_vspacing' ] = array(
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} .v-spacing-custom .post-list + .post-list' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .v-spacing-custom .post-standard + .post-list' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .v-spacing-custom .post-list-sep' => 'padding-top:{{SIZE}}{{UNIT}};',
            
            // for columnized case
            '{{WRAPPER}} .blog-list.columnized .post-list' => 'padding-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .blog-list.columnized' => 'margin-top:-{{SIZE}}{{UNIT}};',
        ],
        'title' => 'Vertical spacing',
        'condition' => array( 'list_spacing_type[value]' => 'custom' ),
        
        'std_unit' => 'px',
        'std_size' => 40,
        'px_max' => 200,
        'px_min' => 0,
    );

$params[ 'list_valign' ] = array(
    'title' => 'Item vertical align',
    'type' => 'select',
    'std' => 'top',
    'options' => [
        'top' => 'Top',
        'middle' => 'Middle',
        'bottom' => 'Bottom',
    ],
);

$params[ 'item_align' ] = array(
    'title' => 'Item alignment',
    'type' => 'align',
    'std' => 'left',
);

$params[ 'item_background' ] = array(
    'title' => 'Item background',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .post-item-inner' => 'background-color:{{VALUE}};',
    ],
);

$params[ 'list_mobile_layout' ] = array(
    'title' => 'Mobile layout',
    'type' => 'select',
    'std' => 'list',
    'options' => [
        'list' => 'List',
        'grid' => 'Grid',
    ],
);

$params[ 'list_index' ] = array(
    'title' => 'List index 01, 02..',
    'type' => 'switcher',
    'std' => 'no',
);

$params[ 'list_index_width' ] = array(
    'title' => 'List index width',
    'type' => 'size',
    
    'selectors' => [
        '{{WRAPPER}} .post-list-count' => 'width:{{SIZE}}{{UNIT}};',
    ],
    'std_unit' => 'px',
    'std_size' => 40,
    'px_max' => 100,
    'px_min' => 10,
    
    'condition' => [
        'list_index[value]' => 'yes',
    ],
);

$params[ 'list_index_color' ] = array(
    'title' => 'Index color',
    'type' => 'color',
    
    'selectors' => [
        '{{WRAPPER}} .post-list-count' => 'color:{{VALUE}};',
    ],
    
    'condition' => [
        'list_index[value]' => 'yes',
    ],
);

$params[ 'list_index_typography' ] = array(
    'title' => 'Index typography',
    'type' => 'typography',
    
    'selector' => '{{WRAPPER}} .post-list-count',
    
    'condition' => [
        'list_index[value]' => 'yes',
    ],
);

$params[ 'item_template' ] = array(
    'title' => 'Elements order',
    'type' => 'select',

    'options' => [
        '1' => 'Title > Meta > Excerpt',
        '2' => 'Meta > Title > Excerpt',
        '3' => 'Title > Excerpt > Meta',

        '4' => 'Category > Title > Meta > Excerpt',
        '5' => 'Category > Title > Excerpt > Meta',
    ],
    'std' => '1',
);

$params[ 'text_color' ] = array(
    'title' => 'Custom Text Color',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .wi-blog' => 'color:{{VALUE}};',
    ],
);

$params[ 'list_sep' ] = array(
    'title' => 'Separator between items',
    'type' => 'switcher',
    'std' => 'no' ,
);

$params[ 'list_sep_style' ] = array(
    'title' => 'Separator style',
    'type' => 'select',
    'std' => 'solid' ,
    'options' => [
        'solid' => 'Solid',
        'dashed' => 'Dashed',
        'dotted' => 'Dotted',
    ],
);

$params[ 'list_sep_color' ] = array(
    'title' => 'Separator color',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .post-list-sep' => 'border-color:{{VALUE}};',
    ],
);

$params[ 'thumbnail_spacing' ] = array(
    'title' => 'Thumbnail - Text Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-thumbnail-align-left .list-thumbnail + .post-body' => 'padding-left:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-thumbnail-align-right .list-thumbnail + .post-body' => 'padding-right:{{SIZE}}{{UNIT}};',
    ],
    'std_unit' => 'px',
    'std_size' => 30,
    'px_max' => 100,
    'px_min' => 0,
);

$params[ 'title_meta_spacing' ] = array(
    'title' => 'Upper Meta - Title Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-header-section + .post-header-section.post-item-title' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-list .component56.meta56 + .component56.title56' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 6,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'header_excerpt_spacing' ] = array(
    'title' => 'Title - Excerpt Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-header+.post-item-excerpt' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-list .component56 + .component56.excerpt56' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 16,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'bottom_meta_spacing' ] = array(
    'title' => 'Excerpt - Bottom Meta Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-excerpt+.post-item-meta' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-list .excerpt56+.meta56' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 22,
    'px_max' => 60,
    'px_min' => 0,
);

/* thumbnail
----------------------------------- */
$params[ 'thumbnail_heading' ] = [
    'type' => 'heading',
    'title' => 'Thumbnail',

    'section' => 'thumbnail',
    'section_title' => 'Thumbnail',
];

$params[ 'show_thumbnail' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show thumbnail',
);

$params[ 'disable_thumbnail_after_first' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Disable thumbnail from 2nd post',
);

$params[ 'thumbnail' ] = array(
    'type' => 'select',
    'options' => [
        'thumbnail' => 'Thumbnail (150x150)',
        
        'landscape' => 'Medium crop (480x384)',
        'square' => 'Square crop (480x480)',
        'portrait' => 'Portrait crop (480x600)',
        'thumbnail-large' => 'Large crop (720x480)',
        
        'medium' => 'Medium (no crop)',
        'large' => 'Large (no crop)',

        'original' => 'Original ratio (Fullwidth)',
        'original_fixed' => 'Original ratio (Fixed height)',
        'custom' => 'Custom',
    ],
    'std' => 'landscape',
    'title' => 'Thumbnail',
);

$params[ 'thumbnail_custom' ] = array(
    'type' => 'text',
    'title' => 'Custom Size (Eg. 425x360)',
    
    'condition' => [
        'thumbnail[value]' => 'custom',
    ]
);

$params[ 'thumbnail_width' ] = array(
    'type' => 'size',
    'title' => 'Thumbnail width',
    
    'std_unit' => '%',
    'std_size' => '40',
    
    'selectors' => [
        '{{WRAPPER}} .post-list .list-thumbnail' => 'width:{{SIZE}}{{UNIT}};',
    ],
);

$params[ 'thumbnail_position' ] = array(
    'type' => 'select',
    'title' => 'Thumbnail position',
    'options' => [
        'left' => 'Left',
        'right' => 'Right',
        'alternative' => 'Alternative',
    ],
    'std' => 'left',
);

$params[ 'thumbnail_placeholder' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Placeholder thumbnail',
    'desc' => 'For posts dont have a thumbnail'
);

$params[ 'thumbnail_padding' ] = array(
    'title' => 'Thumbnail padding',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-thumbnail' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 200,
    'px_min' => 0,
);

$params[ 'thumbnail_padding_top' ] = array(
    'title' => 'Thumbnail padding top/bottom',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-thumbnail' => 'padding-top:{{SIZE}}{{UNIT}};padding-bottom:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 100,
    'px_min' => 0,
);

$params[ 'thumbnail_border' ] = array(
    'title' => 'Thumbnail border width',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-thumbnail' => 'border-width:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 20,
    'px_min' => 0,
);

$params[ 'thumbnail_border_color' ] = array(
    'title' => 'Thumbnail border color',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-thumbnail' => 'border-color:{{VALUE}};',
    ],
);

// @todo: more shape
$params[ 'thumbnail_shape' ] = array(
    'type'  => 'select',
    'std'   => 'acute',
    'options' => [
        'acute'     => 'Acute',
        'round'     => 'Round',
        'circle'    => 'Circle',
    ],
    'title' => 'Thumbnail shape',
);

$params[ 'thumbnail_hover_effect' ] = array(
    'type'  => 'select',
    'std'   => 'none',
    'options' => [
        'none'      => 'None',
        'fade'      => 'Image Fade',
        'grayscale' => 'Grayscale',
        'sepia'     => 'Sepia',
        'dark'      => 'Dark',
        'letter'    => 'Title First Letter',
        'zoomin'    => 'Image Zoom In',
        'logo'      => 'Custom Logo',
    ],
    'title' => 'Thumbnail hover effect',
);

$params[ 'thumbnail_hover_logo' ] = array(
    'type'  => 'image',
    'title' => 'Thumbnail hover logo',
);
$params[ 'thumbnail_hover_logo_size' ] = array(
    'type'  => 'image_size',
    'name' => 'thumbnail_hover_logo',
    'title' => 'Thumbnail logo size',
);

$params[ 'thumbnail_hover_logo_width' ] = array(
    'type'  => 'size',
    
    'std_unit' => '%',
    'std_size' => 40,
    
    'title' => 'Logo width',
    'selectors' => [
        '{{WRAPPER}} .image-logo' => 'width:{{SIZE}}{{UNIT}};',
    ],
);

$params[ 'thumbnail_showing_effect' ] = array(
    'type'  => 'select',
    'std'   => 'none',
    'options' => [
        'none'      => 'None',
        'fade'      => 'Image Fade',
        'slide'     => 'Slide',
        'popup'     => 'Pop up',
        'zoomin'    => 'Zoom In',
    ],
    'title' => 'Thumbnail showing effect',
);

$params[ 'format_indicator' ] = array(
    'type'  => 'switcher',
    'std'   => 'yes',
    'title' => 'Show format indicator',
);

$params[ 'thumbnail_index' ] = array(
    'type'  => 'switcher',
    'title' => 'Index 01, 02.. on thumbnail',
);

$params[ 'thumbnail_review_score' ] = array(
    'type'  => 'switcher',
    'std'   => '',
    'title' => 'Review Score?',
);

$params[ 'thumbnail_view' ] = array(
    'type'  => 'switcher',
    'title' => 'Display view count',
);

$params[ 'thumbnail_caption' ] = array(
    'type'  => 'switcher',
    'title' => 'Thumbnail caption?',
);

/* text + components
----------------------------------- */
$params[ 'title_heading' ] = [
    'type' => 'heading',
    'title' => 'Title',

    'section' => 'text',
    'section_title' => 'Text',
];

$params[ 'show_title' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show title',
);

$params[ 'title_tag' ] = array(
    'type' => 'select',
    'options' => [
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
    ],
    'std' => 'h2',
    'title' => 'Title tag',
);

/* Excerpt
 * ------------------------ */
$params[ 'excerpt_heading' ] = [
    'type' => 'heading',
    'title' => 'Excerpt',
];

$params[ 'show_excerpt' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display excerpt?',
);

$params[ 'excerpt_length' ] = array(
    'type' => 'text',
    'std' => '22',
    'title' => 'Excerpt length',
);

$params[ 'excerpt_more' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'More Link',
);

$params[ 'excerpt_more_style' ] = array(
    'type' => 'select',
    'options' => [
        'simple' => 'Plain Link',
        'simple-btn' => 'Minimal Link', // simple button
        'btn' => 'Fill Button', // default btn
        'btn-black' => 'Solid Black Button',
        'btn-primary' => 'Primary Button',
    ],
    'std' => 'simple',
    'title' => 'More text style',
);

$params[ 'excerpt_more_text' ] = array(
    'type' => 'text',
    'placeholder' => 'More',
    'title' => 'Custom More Text',
);

/* Date
 * ------------------------ */
$params[ 'date_heading' ] = [
    'type' => 'heading',
    'title' => 'Date',
];

$params[ 'show_date' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show post date',
);

/* Category
 * ------------------------ */
$params[ 'category_heading' ] = [
    'type' => 'heading',
    'title' => 'Category',
];

$params[ 'show_category' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show post categories',
);

/* Author
 * ------------------------ */
$params[ 'author_heading' ] = [
    'type' => 'heading',
    'title' => 'Author',
];

$params[ 'show_author' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show post author',
);

$params[ 'show_author_avatar' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show author avatar',
);

$params[ 'author_avatar_size' ] = array(
    'type' => 'size',
    'title' => 'Author avatar size',
    
    'std_unit' => 'px',
    'std_size' => 32,
    'px_max' => 80,
    'px_min' => 10,
    
    'selectors' => [
        '{{WRAPPER}} .post-list .meta-author-avatar' => 'width:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-list .meta56__author a img' => 'width:{{SIZE}}{{UNIT}};',
    ],
    
    'condition' => array( 'show_author_avatar[value]' => 'yes' ),
);

/* View count
 * ------------------------ */
$params[ 'view_count_heading' ] = [
    'type' => 'heading',
    'title' => 'View Count',
];

$params[ 'show_view' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show view count',
);

/* Comment link
 * ------------------------ */
$params[ 'comment_link_heading' ] = [
    'type' => 'heading',
    'title' => 'Comment Link',
];

$params[ 'show_comment_link' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show comment link',
);

/* Reading Time
 * ------------------------ */
$params[ 'reading_time_heading' ] = [
    'type' => 'heading',
    'title' => 'Reading Time',
];

$params[ 'show_reading_time' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show reading time',
);

/* ----------------------------------------------------------------------
// STYLE
---------------------------------------------------------------------- */

/* title
----------------------------------- */
// legacy
$params[ 'title_size' ] = array(
    'type'  => 'select',
    'std'   => 'normal',
    'options' => [
        'supertiny' => 'Super Tiny',
        'tiny' => 'Tiny',
        'small' => 'Small',
        'normal' => 'Normal',
        'medium' => 'Medium',
        'large' => 'Large',
    ],
    'title' => 'Title size',
    'desc' => 'Legacy option for compatibility, use Title Typography instead',
    
    'section' => 'post_item_style',
    'section_title' => 'Post item style',
    'section_tab' => 'style',
);

// legacy
$params[ 'title_weight' ] = array(
    'type'  => 'select',
    'std'   => '',
    'options' => [
        '' => 'Default',
        '300' => 'Light',
        '400' => 'Normal',
        '700' => 'Bold',
        '900' => 'Heavy',
    ],
    'title' => 'Title weight',
    'desc' => 'Legacy option for compatibility, use Title Typography instead',
);

$params[ 'title_typography' ] = array(
    'type' => 'typography',
    'title' => 'Title typography',
    'selector' => '{{WRAPPER}} .post-list .post-item-title, {{WRAPPER}} .post-list .title56',
);

$params[ 'title_color' ] = array(
    'type' => 'color',
    'title' => 'Title color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-title a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .title56 a' => 'color:{{VALUE}};'
    ],
);

$params[ 'title_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Title hover color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-title a:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .title56 a:hover' => 'color:{{VALUE}};'
    ],
);

$params[ 'title_hover_effect' ] = array(
    'type' => 'select',
    'title' => 'Title hover effect',
    'options' => [
        'none' => 'None',
        'underline' => 'Underline',
        'line-through' => 'Line through',
    ],
    'std' => 'none',
);

$params[ 'title_hover_underline_color' ] = array(
    'type' => 'color',
    'title' => 'Title hover underline color',
    'selectors' => [
        '{{WRAPPER}} .style-title-hover-underline .post-item-title a:hover' => 'text-decoration-color:{{VALUE}};',
        '{{WRAPPER}} .style-title-hover-line-through .post-item-title a:hover' => 'text-decoration-color:{{VALUE}};',

        '{{WRAPPER}} .style-title-hover-underline .title56 a:hover' => 'text-decoration-color:{{VALUE}};',
        '{{WRAPPER}} .style-title-hover-line-through .title56 a:hover' => 'text-decoration-color:{{VALUE}};',
    ],
);

/* excerpt
----------------------------------- */
$params[ 'excerpt_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Excerpt',
);

$params[ 'excerpt_size' ] = array(
    'type' => 'select',
    'options' => [
        'small' => 'Small',
        'normal' => 'Normal',
        'medium' => 'Medium',
    ],
    'title' => 'Excerpt font size',
    'std'   => 'normal',
);

$params[ 'excerpt_typography' ] = array(
    'type' => 'typography',
    'title' => 'Excerpt typography',
    'selector' => '{{WRAPPER}} .post-list .post-item-excerpt, {{WRAPPER}} .post-list .excerpt56',
);

$params[ 'excerpt_color' ] = array(
    'type' => 'color',
    'title' => 'Excerpt color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-excerpt' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .excerpt56' => 'color:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_typography' ] = array(
    'type' => 'typography',
    'title' => 'More button typography',
    'selector' => '{{WRAPPER}} .post-list .readmore, {{WRAPPER}} .post-list .readmore56',
);

$params[ 'excerpt_more_color' ] = array(
    'type' => 'color',
    'title' => 'More button text color',
    'selectors' => [
        '{{WRAPPER}} .post-list .readmore' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .readmore56' => 'color:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_hover_color' ] = array(
    'type' => 'color',
    'title' => 'More button hover text color',
    'selectors' => [
        '{{WRAPPER}} .post-list .readmore:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .readmore56:hover' => 'color:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_bg' ] = array(
    'type' => 'color',
    'title' => 'More button background',
    'selectors' => [
        '{{WRAPPER}} .post-list .readmore.fox-btn' => 'background:{{VALUE}};',
        '{{WRAPPER}} .post-list .readmore56.button56' => 'background:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_hover_bg' ] = array(
    'type' => 'color',
    'title' => 'More button hover background',
    'selectors' => [
        '{{WRAPPER}} .post-list .readmore.fox-btn:hover' => 'background:{{VALUE}};',
        '{{WRAPPER}} .post-list .readmore56.button56:hover' => 'background:{{VALUE}};',
    ],
);

/* meta
----------------------------------- */
$params[ 'meta_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Post meta',
);

$params[ 'meta_typography' ] = array(
    'type' => 'typography',
    'title' => 'Meta typography',
    'selector' => '{{WRAPPER}} .post-list .post-item-meta, {{WRAPPER}} .post-list .meta56',
);

$params[ 'meta_color' ] = array(
    'type' => 'color',
    'title' => 'Meta color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-meta' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .meta56' => 'color:{{VALUE}};'
    ],
);

$params[ 'meta_link_color' ] = array(
    'type' => 'color',
    'title' => 'Meta link color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-meta a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .meta56 a' => 'color:{{VALUE}};',
    ],
);

$params[ 'meta_link_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Meta link hover color',
    'selectors' => [
        '{{WRAPPER}} .post-list .post-item-meta a:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .meta56 a:hover' => 'color:{{VALUE}};',
    ],
);

/* standalone categories
----------------------------------- */
$params[ 'standalone_cats_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Standalone Category',
);

$params[ 'standalone_categories_color' ] = array(
    'type' => 'color',
    'title' => 'Standalone Category Color',
    'selectors' => [
        '{{WRAPPER}} .post-list .standalone-categories a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-list .meta56__category--fancy a' => 'color:{{VALUE}};',
    ]
);

$params[ 'standalone_categories_typography' ] = array(
    'type' => 'typography',
    'title' => 'Standalone Category typography',
    'selector' => '{{WRAPPER}} .post-list .standalone-categories, {{WRAPPER}} .post-list .meta56__category--fancy',
);

/* readmore button
----------------------------------- */


/* ----------------------------------------------------------------------
// FIRST STANDARD
---------------------------------------------------------------------- */
$params[ 'first_standard' ] = array(
    'title' => 'First post is standard layout?',
    'type' => 'switcher',
    'std' => 'no',
    
    'section' => 'first_standard',
    'section_title' => 'First standard post',
);

$standard_params = foxfw3_elementor_standard_params([
    'prefix' => 'standard_',
    
    'include' => [
        'header_align',
        'item_template',
        'text_color',
        'show_thumbnail',
        'thumbnail_header_order',
        'spacing_thumbnail_content',
        'spacing_header_content',
        'thumbnail_type',
        'thumbnail_caption',
        'thumbnail_shape',
        'title_heading',
        'show_title',
        'title_tag',
        'excerpt_heading',
        'display_excerpt',
        'content_excerpt',
        'excerpt_length',
        'excerpt_more',
        'excerpt_more_style',
        'excerpt_more_text',
        'date_heading',
        'show_date',
        'category_heading',
        'show_category',
        'author_heading',
        'show_author',
        'show_author_avatar',
        'others_link_heading',
        'show_comment_link',
        'show_view',
        'show_reading_time',
        'show_share',
        'show_related',        
        'title_typography',
        'title_color',
        'title_hover_color',
        'excerpt_style_heading',
        'excerpt_typography',
        'excerpt_color',
        'meta_style_heading',
        'meta_typography',
        'meta_color',
        'meta_link_color',
        'meta_link_color',
        'meta_link_hover_color',
        'standalone_categories_typography',
    ],
    'alter' => [
        
        // we just remove section
        'header_align' => [
            'title' => 'Header text align',
            'type' => 'select',
            'options' => array(
                '' => 'Default',
                'left' => 'Left',
                'center' => 'Center',
                'right' => 'Right',
            ),
            'std' => '',
        ],
        'show_thumbnail' => [
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show thumbnail',

            'section'   => 'thumbnail',
            'section_title' => 'Standard Thumbnail',
        ],
        'title_heading' => [
            'type' => 'heading',
            'title' => 'Excerpt',

            'section'   => 'text',
            'section_title' => 'Standard Text',
        ],
        
        /* title
        ----------------------------------- */
        'title_typography' => [
            'type' => 'typography',
            'title' => 'Title typography',
            'selector' => '{{WRAPPER}} .post-standard .post-item-title, {{WRAPPER}} .post-standard .title56',

            'section' => 'post_item_style',
            'section_title' => 'Standard style',
            'section_tab' => 'style',
        ],
    ],
    
]);
$params += $standard_params;

/* pagination params
----------------------------------- */
$params += foxfw3_pagination_params();

/* misc
----------------------------------- */
$params[ 'thumbnail_youtube_player' ] = [
    'title' => 'YouTube plays when click thumbnail',
    'desc' => 'This applies to video post format with YouTube thumbnail',
    'type' => 'switcher',
    'std' => 'no',

    'section' => 'misc',
    'section_title' => 'Miscellaneous',
];

$params[ 'live_indicator' ] = [
    'title' => 'Live Indicator (for LIVE posts)',
    'type' => 'switcher',
    'std' => 'yes',
];

$params[ 'live_indicator_color' ] = [
    'title' => 'Live Indicator Color',
    'type' => 'color',
    'std' => '#d0022c',
    
    'selectors' => [
        '{{WRAPPER}} .live-indicator' => 'color:{{VALUE}};',
        '{{WRAPPER}} .live-circle' => 'background:{{VALUE}};',
    ],
];
<?php
$params = foxfw3_query_params();
$params += foxfw3_generate_options([
    'base' => 'grid',
    'exclude' => [
        
        'first_standard',
        
        'thumbnail_position',
        'thumbnail_width',
        'list_mobile_layout',
        'list_sep',
        'list_sep_style',
        'list_sep_color',
        'list_spacing',
        'list_valign',

        'thumbnail', 
        'thumbnail_custom',
        'thumbnail_placeholder',
    ],
    'override' => [
        'item_spacing' => [
            'title' => 'Item Spacing'
        ],
        'item_align' => [
            'title' => 'Item Align',
        ],
    ],
    'append' => [
        'big_first_post' => [
            'title' => 'Big first post',
            'type' => 'switcher',
            'std' => 'yes',
            'after' => 'column',
        ],
        'masonry_item_creative' => [
            'title' => 'Creative item',
            'type' => 'switcher',
            'std' => '',
            'after' => 'column',
        ],
    ],
    'context' => 'elementor',

    'section' => 'layout',
    'section_title' => 'Layout',
]);
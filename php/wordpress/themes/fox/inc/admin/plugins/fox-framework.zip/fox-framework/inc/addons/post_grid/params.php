<?php
/* query params
----------------------------------- */
$params += foxfw3_query_params();

/* layout
----------------------------------- */
$params[ 'column' ] = array(
    'type' => 'select',
    'options' => [
        '1' => '1 column',
        '2' => '2 columns',
        '3' => '3 columns',
        '4' => '4 columns',
        '5' => '5 columns',
        '6' => '6 columns',
    ],
    'std' => '3',
    'title' => 'Column',
    
    'section' => 'layout',
    'section_title' => 'Layout',
);

$params[ 'first_double' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'First item takes 2 columns',
    'desc' => 'By enabling this, the first post takes spot of 2 columns and bigger.', 
);

$params[ 'item_card' ] = array(
    'title' => 'Card Style',
    'type' => 'select',
    'std' => 'none',
    'options' => [
        'none' => 'None',
        'normal' => 'Normal',
        'normal_no_shadow' => 'Normal + no shadow',
        'overlap' => 'Text Overlaps Image',
        'overlap_no_shadow' => 'Overlap + no shadow',
    ]
);

$params[ 'item_card_overlap_width' ] = array(
    'title' => 'Text Item Width',
    'type' => 'size',
    
    'std_unit' => '%',
    'std_size' => 95,
    'px_max' => 1200,
    'px_min' => 100,
    
    'selectors' => [
        '{{WRAPPER}} .blog-card-overlap .post-grid-body .post-body-inner' => 'width:{{SIZE}}{{UNIT}};'
    ],
    
    'condition' => [
        'item_card[value]' => [ 'overlap', 'overlap_no_shadow' ]
    ]
);

$params[ 'item_card_overlap_translation' ] = array(
    'title' => 'Text Item Translation',
    'type' => 'size',
    
    'std_unit' => 'px',
    'std_size' => 36,
    'px_max' => 300,
    'px_min' => 0,
    
    'selectors' => [
        '{{WRAPPER}} .blog-card-overlap .post-grid-body .post-body-inner' => 'margin-top:-{{SIZE}}{{UNIT}};'
    ],
    
    'condition' => [
        'item_card[value]' => [ 'overlap', 'overlap_no_shadow' ]
    ]
);

$params[ 'item_card_padding' ] = array(
    'title' => 'Card Padding',
    'type' => 'size',
    'condition' => [
        'item_card[value]' => [ 'normal', 'normal_no_shadow', 'overlap', 'overlap_no_shadow' ],
    ],
    
    'std_unit' => 'px',
    'std_size' => 30,
    'px_max' => 60,
    'px_min' => 0,
    
    'selectors' => [
        '{{WRAPPER}} .blog-card-normal .post-item-body,{{WRAPPER}} .blog-card-overlap .post-grid-body .post-body-inner' => 'padding:{{SIZE}}{{UNIT}};'
    ]
);

$params[ 'item_card_background' ] = array(
    'title' => 'Card Background',
    'type' => 'color',
    
    'selectors' => [
        '{{WRAPPER}} .blog-card-overlap .post-grid-body .post-body-inner,{{WRAPPER}} .blog-card-normal .post-item-inner' => 'background:{{VALUE}};',
    ],
    
    'condition' => [
        'item_card[value]' => [ 'normal', 'normal_no_shadow', 'overlap', 'overlap_no_shadow' ],
    ],
);

$params[ 'item_card_hover_background' ] = array(
    'title' => 'Card Hover Background',
    'type' => 'color',
    
    'selectors' => [
        '{{WRAPPER}} .blog-card-overlap .post-item-inner:hover .post-grid-body .post-body-inner,{{WRAPPER}} .blog-card-normal .post-item-inner:hover' => 'background:{{VALUE}};',
    ],
    
    'condition' => [
        'item_card[value]' => [ 'normal', 'normal_no_shadow', 'overlap', 'overlap_no_shadow' ],
    ],
);

$params[ 'item_background' ] = array(
    'title' => 'Item background',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .post-item-inner' => 'background-color:{{VALUE}};',
    ],
    'condition' => [
        'item_card[value]' => 'none',
    ],
);

/**
 * we need this because of the legacy reason
 */
$params[ 'item_spacing_type' ] = array(
    'type' => 'select',
    'options' => [
        'predefined' => 'Predefined',
        'custom' => 'Custom',
    ],
    'std' => 'predefined',
    'title' => 'Item spacing type',
);

    $params[ 'item_spacing' ] = array(
        'type' => 'select',
        'options' => [
            'none' => 'No spacing',
            'tiny' => 'Tiny',
            'small' => 'Small',
            'normal' => 'Normal',
            'wide' => 'Wide',
            'wider' => 'Wider',
        ],
        'std' => 'normal',
        'title' => 'Item spacing',
        'condition' => array( 'item_spacing_type[value]' => 'predefined' ),
    );

    $params[ 'item_hspacing' ] = array(
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} .spacing-custom.fox-grid' => 'margin-left:-{{SIZE}}{{UNIT}};margin-right:-{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .spacing-custom .fox-grid-item' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
        ],
        'title' => 'Horizontal spacing',
        'condition' => array( 'item_spacing_type[value]' => 'custom' ),
        
        'std_unit' => 'px',
        'std_size' => 20,
        'px_max' => 100,
        'px_min' => 0,
    );

    $params[ 'item_vspacing' ] = array(
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} .spacing-custom.fox-grid' => 'margin-top:-{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .spacing-custom .fox-grid-item' => 'padding-top:{{SIZE}}{{UNIT}};',
        ],
        'title' => 'Vertical spacing',
        'condition' => array( 'item_spacing_type[value]' => 'custom' ),
        
        'std_unit' => 'px',
        'std_size' => 40,
        'px_max' => 200,
        'px_min' => 0,
    );

$params[ 'item_align' ] = array(
    'title' => 'Item alignment',
    'type' => 'align',
    'std' => 'left',
);

$params[ 'item_template' ] = array(
    'title' => 'Elements order',
    'type' => 'select',

    'options' => [
        '1' => 'Title > Meta > Excerpt',
        '2' => 'Meta > Title > Excerpt',
        '3' => 'Title > Excerpt > Meta',

        '4' => 'Category > Title > Meta > Excerpt',
        '5' => 'Category > Title > Excerpt > Meta',
    ],
    'std' => '1',
);

$params[ 'item_border' ] = [
    'title' => 'Vertical border between items',
    'type' => 'switcher',
    'std' => 'no',
];

$params[ 'item_border_color' ] = [
    'title' => 'Border color',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .grid-lines' => 'color:{{VALUE}};',
    ],
    
    'condition' => [
        'item_border[value]' => 'yes',
    ],
];

$params[ 'text_color' ] = array(
    'title' => 'Custom Text Color',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .wi-blog' => 'color:{{VALUE}};',
    ],
);

$params[ 'thumbnail_spacing' ] = array(
    'title' => 'Thumbnail - Text Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .grid-thumbnail + .grid-body' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    'std_unit' => 'px',
    'std_size' => 16,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'title_meta_spacing' ] = array(
    'title' => 'Upper Meta - Title Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-header-section + .post-header-section.post-item-title' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-grid .component56.meta56 + .component56.title56' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 6,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'excerpt_spacing' ] = array(
    'title' => 'Title Below Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-header + .post-item-excerpt, ' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-grid .post-header-section + .post-header-section.post-item-meta' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-grid .post-item-header + .post-item-excerpt' => 'margin-top:{{SIZE}}{{UNIT}};',

        '{{WRAPPER}} .post-grid .component56 + .component56.excerpt56' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 16,
    'px_max' => 60,
    'px_min' => 0,
);

$params[ 'bottom_meta_spacing' ] = array(
    'title' => 'Excerpt - Bottom Meta Spacing',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-excerpt + .post-item-meta' => 'margin-top:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .post-grid .excerpt56 + .meta56' => 'margin-top:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 22,
    'px_max' => 60,
    'px_min' => 0,
);

/* thumbnail
----------------------------------- */
$params[ 'thumbnail_heading' ] = [
    'type' => 'heading',
    'title' => 'Thumbnail',

    'section' => 'thumbnail',
    'section_title' => 'Thumbnail',
];

$params[ 'show_thumbnail' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show thumbnail',
);

$params[ 'disable_thumbnail_after_first' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Disable thumbnail from 2nd post',
);

$thumbnail_options = [
    'thumbnail' => 'Thumbnail (150x150)',
    
    'landscape' => 'Medium crop (480x384)',
    'square' => 'Square crop (480x480)',
    'portrait' => 'Portrait crop (480x600)',
    'thumbnail-large' => 'Large crop (720x480)',
    
    'medium' => 'Medium (no crop)',
    'large' => 'Large (no crop)',

    'original' => 'Original ratio (Fullwidth)',
    'original_fixed' => 'Original ratio (Fixed height)',
    'custom' => 'Custom',
];

$params[ 'thumbnail' ] = array(
    'type' => 'select',
    'options' => $thumbnail_options,
    'std' => 'landscape',
    'title' => 'Thumbnail',
);

$params[ 'thumbnail_custom' ] = array(
    'type' => 'text',
    'title' => 'Custom Size (Eg. 425x360)',
    
    'condition' => [
        'thumbnail[value]' => 'custom',
    ]
);

$first_thumbnail_options = [ '' => 'Inherit' ];
$first_thumbnail_options = array_merge( $first_thumbnail_options, $thumbnail_options );

$params[ 'first_thumbnail' ] = array(
    'type' => 'select',
    'options' => $first_thumbnail_options,
    'std' => '',
    'title' => 'First post thumbnail',
);

$params[ 'first_thumbnail_custom' ] = array(
    'type' => 'text',
    'title' => 'Custom Size (Eg. 425x360)',
    'condition' => [
        'first_thumbnail[value]' => 'custom',
    ],
);

$params[ 'thumbnail_placeholder' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Placeholder thumbnail',
    'desc' => 'For posts dont have a thumbnail'
);

$params[ 'thumbnail_padding' ] = array(
    'title' => 'Thumbnail padding',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-thumbnail' => 'padding-left:{{SIZE}}{{UNIT}};padding-right:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 200,
    'px_min' => 0,
);

$params[ 'thumbnail_padding_top' ] = array(
    'title' => 'Thumbnail padding top/bottom',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-thumbnail' => 'padding-top:{{SIZE}}{{UNIT}};padding-bottom:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 100,
    'px_min' => 0,
);

$params[ 'thumbnail_border' ] = array(
    'title' => 'Thumbnail border width',
    'type' => 'size',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-thumbnail' => 'border-width:{{SIZE}}{{UNIT}};',
    ],
    
    'std_unit' => 'px',
    'std_size' => 0,
    'px_max' => 20,
    'px_min' => 0,
);

$params[ 'thumbnail_border_color' ] = array(
    'title' => 'Thumbnail border color',
    'type' => 'color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-thumbnail' => 'border-color:{{VALUE}};',
    ],
);

// @todo: more shape
$params[ 'thumbnail_shape' ] = array(
    'type'  => 'select',
    'std'   => 'acute',
    'options' => [
        'acute'     => 'Acute',
        'round'     => 'Round',
        'circle'    => 'Circle',
    ],
    'title' => 'Thumbnail shape',
);

$params[ 'thumbnail_hover_effect' ] = array(
    'type'  => 'select',
    'std'   => 'none',
    'options' => [
        'none'      => 'None',
        'fade'      => 'Image Fade',
        'grayscale' => 'Grayscale',
        'sepia'     => 'Sepia',
        'dark'      => 'Dark',
        'letter'    => 'Title First Letter',
        'zoomin'    => 'Image Zoom In',
        'logo'      => 'Custom Logo',
    ],
    'title' => 'Thumbnail hover effect',
);

$params[ 'thumbnail_hover_logo' ] = array(
    'type'  => 'image',
    'title' => 'Thumbnail hover logo',
    
    'condition' => [
        'thumbnail_hover_effect[value]' => 'logo',
    ]
);
$params[ 'thumbnail_hover_logo_size' ] = array(
    'type'  => 'image_size',
    'name' => 'thumbnail_hover_logo',
    'title' => 'Thumbnail logo size',
    
    'condition' => [
        'thumbnail_hover_effect[value]' => 'logo',
    ]
);

$params[ 'thumbnail_hover_logo_width' ] = array(
    'type'  => 'size',
    
    'std_unit' => '%',
    'std_size' => 40,
    
    'title' => 'Logo width',
    'selectors' => [
        '{{WRAPPER}} .image-logo' => 'width:{{SIZE}}{{UNIT}};',
    ],
    
    'condition' => [
        'thumbnail_hover_effect[value]' => 'logo',
    ]
);

$params[ 'thumbnail_showing_effect' ] = array(
    'type'  => 'select',
    'std'   => 'none',
    'options' => [
        'none'      => 'None',
        'fade'      => 'Image Fade',
        'slide'     => 'Slide',
        'popup'     => 'Pop up',
        'zoomin'    => 'Zoom In',
    ],
    'title' => 'Thumbnail showing effect',
);

$params[ 'format_indicator' ] = array(
    'type'  => 'switcher',
    'std'   => 'yes',
    'title' => 'Show format indicator',
);

$params[ 'thumbnail_index' ] = array(
    'type'  => 'switcher',
    'std'   => '',
    'title' => 'Index 01, 02.. on thumbnail',
);

$params[ 'thumbnail_review_score' ] = array(
    'type'  => 'switcher',
    'std'   => '',
    'title' => 'Review Score?',
);

$params[ 'thumbnail_view' ] = array(
    'type'  => 'switcher',
    'std'   => '',
    'title' => 'Display view count',
);

/* text + components
----------------------------------- */
$params[ 'title_heading' ] = [
    'type' => 'heading',
    'title' => 'Title',

    'section' => 'text',
    'section_title' => 'Text',
];

$params[ 'show_title' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show title',
);

$params[ 'title_tag' ] = array(
    'type' => 'select',
    'options' => [
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
    ],
    'std' => 'h2',
    'title' => 'Title tag',
    
    'condition' => [
        'show_title[value]' => 'yes',
    ],
);

/* Excerpt
 * ------------------------ */
$params[ 'excerpt_heading' ] = [
    'type' => 'heading',
    'title' => 'Excerpt',
];

$params[ 'show_excerpt' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Display excerpt?',
);

$params[ 'disable_excerpt_first' ] = array(
    'type' => 'switcher',
    'std' => 'no',
    'title' => 'Disable excerpt for the first post?',
);

$params[ 'excerpt_length' ] = array(
    'type' => 'text',
    'std' => '22',
    'title' => 'Excerpt length',
    
    'condition' => [
        'show_excerpt[value]' => 'yes',
    ],
);

$params[ 'excerpt_more' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'More Link',
);

$params[ 'excerpt_more_style' ] = array(
    'type' => 'select',
    'options' => [
        'simple' => 'Plain Link',
        'simple-btn' => 'Minimal Link', // simple button
        'btn' => 'Fill Button', // default btn
        'btn-black' => 'Solid Black Button',
        'btn-primary' => 'Primary Button',
    ],
    'std' => 'simple',
    'title' => 'More text style',
    
    'condition' => [
        'excerpt_more[value]' => 'yes',
    ],
);

$params[ 'excerpt_more_text' ] = array(
    'type' => 'text',
    'placeholder' => 'More',
    'title' => 'Custom More Text',
    
    'condition' => [
        'excerpt_more[value]' => 'yes',
    ],
);

/* Date
 * ------------------------ */
$params[ 'date_heading' ] = [
    'type' => 'heading',
    'title' => 'Date',
];

$params[ 'show_date' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show post date',
);

/*
@todo
when we have elementor_meta function
$params[ 'date_format' ] = array(
    'type' => 'text',
    'title' => 'Custom date format',
    'desc' => 'Please read <a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">this article</a> to understand how to customize data format.',
    
    'condition' => [
        'show_date[value]' => 'yes',
    ],
);
*/

/* Category
 * ------------------------ */
$params[ 'category_heading' ] = [
    'type' => 'heading',
    'title' => 'Category',
];

$params[ 'show_category' ] = array(
    'type' => 'switcher',
    'std' => 'yes',
    'title' => 'Show post categories',
);

/* Author
 * ------------------------ */
$params[ 'author_heading' ] = [
    'type' => 'heading',
    'title' => 'Author',
];

$params[ 'show_author' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show post author',
);

$params[ 'show_author_avatar' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show author avatar',
);

$params[ 'author_avatar_size' ] = array(
    'type' => 'size',
    'title' => 'Author avatar size',
    
    'selectors' => [
        '{{WRAPPER}} .meta-author-avatar' => 'width:{{SIZE}}{{UNIT}};',
        '{{WRAPPER}} .meta56__author a img' => 'width:{{SIZE}}{{UNIT}};',
    ],
    
    'condition' => array( 'show_author_avatar[value]' => 'yes' ),
    
    'std_unit' => 'px',
    'std_size' => 32,
    'px_max' => 80,
    'px_min' => 10,
);

/* View count
 * ------------------------ */
$params[ 'view_count_heading' ] = [
    'type' => 'heading',
    'title' => 'View Count',
];

$params[ 'show_view' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show view count',
);

/* Comment link
 * ------------------------ */
$params[ 'comment_link_heading' ] = [
    'type' => 'heading',
    'title' => 'Comment Link',
];

$params[ 'show_comment_link' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show comment link',
);

/* Reading Time
 * ------------------------ */
$params[ 'reading_time_heading' ] = [
    'type' => 'heading',
    'title' => 'Reading Time',
];

$params[ 'show_reading_time' ] = array(
    'type' => 'switcher',
    'std' => '',
    'title' => 'Show reading time',
);

/* ----------------------------------------------------------------------
// STYLE
---------------------------------------------------------------------- */

/* title
----------------------------------- */
// legacy
$params[ 'title_size' ] = array(
    'type'  => 'select',
    'std'   => 'normal',
    'options' => [
        'supertiny' => 'Super Tiny',
        'tiny' => 'Tiny',
        'small' => 'Small',
        'normal' => 'Normal',
        'medium' => 'Medium',
        'large' => 'Large',
    ],
    'title' => 'Title size',
    'desc' => 'Legacy option for compatibility, you can use Title Typography option',
    
    'condition' => [
        'show_title[value]' => 'yes',
    ],
    
    'section' => 'post_item_style',
    'section_title' => 'Post item style',
    'section_tab' => 'style',
);

// legacy
$params[ 'title_weight' ] = array(
    'type'  => 'select',
    'std'   => '',
    'options' => [
        '' => 'Default',
        '300' => 'Light',
        '400' => 'Normal',
        '700' => 'Bold',
        '900' => 'Heavy',
    ],
    'title' => 'Title weight',
    'desc' => 'Legacy option for compatibility, you can use Title Typography option',
    
    'condition' => [
        'show_title[value]' => 'yes',
    ],
);

$params[ 'title_typography' ] = array(
    'type' => 'typography',
    'title' => 'Title typography',
    'selector' => '{{WRAPPER}} .post-grid .post-item-title, {{WRAPPER}} .post-grid .title56',
);

$params[ 'title_color' ] = array(
    'type' => 'color',
    'title' => 'Title color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-title a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .title56 a' => 'color:{{VALUE}};',
    ],
);

$params[ 'title_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Title hover color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-title a:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .title56 a:hover' => 'color:{{VALUE}};',
    ],
);

$params[ 'title_hover_effect' ] = array(
    'type' => 'select',
    'title' => 'Title hover effect',
    'options' => [
        'none' => 'None',
        'underline' => 'Underline',
        'line-through' => 'Line through',
    ],
    'std' => 'none',
);

$params[ 'title_hover_underline_color' ] = array(
    'type' => 'color',
    'title' => 'Title hover underline color',
    'selectors' => [
        '{{WRAPPER}} .style-title-hover-underline .post-item-title a:hover' => 'text-decoration-color:{{VALUE}};',
        '{{WRAPPER}} .style-title-hover-line-through .post-item-title a:hover' => 'text-decoration-color:{{VALUE}};',

        '{{WRAPPER}} .style-title-hover-underline .title56 a:hover' => 'text-decoration-color:{{VALUE}};',
        '{{WRAPPER}} .style-title-hover-line-through .title56 a:hover' => 'text-decoration-color:{{VALUE}};',
    ],
);

/* excerpt
----------------------------------- */
$params[ 'excerpt_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Excerpt',
);

$params[ 'excerpt_size' ] = array(
    'type' => 'select',
    'options' => [
        'small' => 'Small',
        'normal' => 'Normal',
        'medium' => 'Medium',
    ],
    'title' => 'Excerpt font size',
    'std'   => 'normal',
    
    'condition' => [
        'show_excerpt[value]' => 'yes',
    ],
    
    'desc' => 'Legacy option for compatibility, you can use Title Typography option',
);

$params[ 'excerpt_typography' ] = array(
    'type' => 'typography',
    'title' => 'Excerpt typography',
    'selector' => '{{WRAPPER}} .post-grid .post-item-excerpt, {{WRAPPER}} .post-grid .excerpt56',
);

$params[ 'excerpt_color' ] = array(
    'type' => 'color',
    'title' => 'Excerpt color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-excerpt' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .excerpt56' => 'color:{{VALUE}};'
    ],
);

$params[ 'excerpt_more_typography' ] = array(
    'type' => 'typography',
    'title' => 'More button typography',
    'selector' => '{{WRAPPER}} .post-grid .readmore, {{WRAPPER}} .post-grid .readmore56',

);

$params[ 'excerpt_more_color' ] = array(
    'type' => 'color',
    'title' => 'More button text color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .readmore' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .readmore56' => 'color:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_hover_color' ] = array(
    'type' => 'color',
    'title' => 'More button hover text color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .readmore:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .readmore56:hover' => 'color:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_bg' ] = array(
    'type' => 'color',
    'title' => 'More button background',
    'selectors' => [
        '{{WRAPPER}} .post-grid .readmore.fox-btn' => 'background:{{VALUE}};',
        '{{WRAPPER}} .post-grid .readmore56.button56' => 'background:{{VALUE}};',
    ],
);

$params[ 'excerpt_more_hover_bg' ] = array(
    'type' => 'color',
    'title' => 'More button hover background',
    'selectors' => [
        '{{WRAPPER}} .post-grid .readmore.fox-btn:hover' => 'background:{{VALUE}};',
        '{{WRAPPER}} .post-grid .readmore56.button56:hover' => 'background:{{VALUE}};',
    ],
);

/* meta
----------------------------------- */
$params[ 'meta_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Post meta',
);

$params[ 'meta_typography' ] = array(
    'type' => 'typography',
    'title' => 'Meta typography',
    'selector' => '{{WRAPPER}} .post-grid .post-item-meta, {{WRAPPER}} .post-grid .meta56',
);

$params[ 'meta_color' ] = array(
    'type' => 'color',
    'title' => 'Meta color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-meta' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .meta56' => 'color:{{VALUE}};',
    ],
);

$params[ 'meta_link_color' ] = array(
    'type' => 'color',
    'title' => 'Meta link color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-meta a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .meta56 a' => 'color:{{VALUE}};',
    ],
);

$params[ 'meta_link_hover_color' ] = array(
    'type' => 'color',
    'title' => 'Meta link hover color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .post-item-meta a:hover' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .meta56 a:hover' => 'color:{{VALUE}};',
    ],
);

/* standalone categories
----------------------------------- */
$params[ 'standalone_cats_style_heading' ] = array(
    'type' => 'heading',
    'title' => 'Standalone Category',
);

$params[ 'standalone_categories_color' ] = array(
    'type' => 'color',
    'title' => 'Standalone Category Color',
    'selectors' => [
        '{{WRAPPER}} .post-grid .standalone-categories a' => 'color:{{VALUE}};',
        '{{WRAPPER}} .post-grid .meta56__category--fancy a' => 'color:{{VALUE}};',
    ]
);

$params[ 'standalone_categories_typography' ] = array(
    'type' => 'typography',
    'title' => 'Standalone Category Typography',
    'selector' => '{{WRAPPER}} .post-grid .standalone-categories, {{WRAPPER}} .post-grid .meta56__category--fancy',
);

/* readmore button
----------------------------------- */


/* ----------------------------------------------------------------------
// FIRST STANDARD
---------------------------------------------------------------------- */
$params[ 'first_standard' ] = array(
    'title' => 'First post is standard layout?',
    'type' => 'switcher',
    'std' => 'no',
    
    'section' => 'first_standard',
    'section_title' => 'First standard post',
);

$standard_params = foxfw3_elementor_standard_params([
    'prefix' => 'standard_',
    
    'include' => [
        'header_align',
        'item_template',
        'text_color',
        'show_thumbnail',
        'thumbnail_header_order',
        'spacing_thumbnail_content',
        'spacing_header_content',
        'thumbnail_type',
        'thumbnail_caption',
        'thumbnail_shape',
        'title_heading',
        'show_title',
        'title_tag',
        'excerpt_heading',
        'display_excerpt',
        'content_excerpt',
        'excerpt_length',
        'excerpt_more',
        'excerpt_more_style',
        'excerpt_more_text',
        'date_heading',
        'show_date',
        'category_heading',
        'show_category',
        'author_heading',
        'show_author',
        'show_author_avatar',
        'others_link_heading',
        'show_comment_link',
        'show_view',
        'show_reading_time',
        'show_share',
        'show_related',        
        'title_typography',
        'title_color',
        'title_hover_color',
        'excerpt_style_heading',
        'excerpt_typography',
        'excerpt_color',
        'meta_style_heading',
        'meta_typography',
        'meta_color',
        'meta_link_color',
        'meta_link_color',
        'meta_link_hover_color',
    ],
    'alter' => [
        
        // we just remove section
        'header_align' => [
            'title' => 'Header text align',
            'type' => 'select',
            'options' => array(
                '' => 'Default',
                'left' => 'Left',
                'center' => 'Center',
                'right' => 'Right',
            ),
            'std' => '',
        ],
        'show_thumbnail' => [
            'type' => 'switcher',
            'std' => 'yes',
            'title' => 'Show thumbnail',

            'section'   => 'thumbnail',
            'section_title' => 'Standard Thumbnail',
        ],
        'title_heading' => [
            'type' => 'heading',
            'title' => 'Excerpt',

            'section'   => 'text',
            'section_title' => 'Standard Text',
        ],
        
        /* title
        ----------------------------------- */
        'title_typography' => [
            'type' => 'typography',
            'title' => 'Title typography',
            'selector' => '{{WRAPPER}} .post-standard .post-item-title, {{WRAPPER}} .post-standard .title56',

            'section' => 'post_item_style',
            'section_title' => 'Standard style',
            'section_tab' => 'style',
        ],
    ],
    
]);

// @todo
$inserted = [
    'standard_title_meta_spacing' => [
        'title' => 'Upper Meta - Title Spacing',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} .post-standard .post-header-section + .post-header-section.post-item-title' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 6,
        'px_max' => 60,
        'px_min' => 0,
    ],
    
    'standard_excerpt_spacing' => [
        'title' => 'Title Below Spacing',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} .post-standard .post-item-header+.post-item-excerpt' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .post-standard .post-item-header + .post-item-meta' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 16,
        'px_max' => 60,
        'px_min' => 0,
    ],
    
    'bottom_meta_spacing' => [
        'title' => 'Excerpt - Bottom Meta Spacing',
        'type' => 'size',
        'selectors' => [
            '{{WRAPPER}} .post-standard .post-item-excerpt+.post-item-meta' => 'margin-top:{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .post-standard .excerpt56 + .meta56' => 'margin-top:{{SIZE}}{{UNIT}};',
        ],

        'std_unit' => 'px',
        'std_size' => 22,
        'px_max' => 60,
        'px_min' => 0,
    ],
    
];

$k_index = 3;

$standard_params = array_slice( $standard_params, 0, $k_index, true ) +
    $inserted +
    array_slice( $standard_params, $k_index, count( $standard_params )- $k_index, true);

$params += $standard_params;

/* pagination params
----------------------------------- */
$params += foxfw3_pagination_params();

/* misc
----------------------------------- */
$params[ 'thumbnail_youtube_player' ] = [
    'title' => 'YouTube plays when click thumbnail',
    'desc' => 'This applies to video post format with YouTube thumbnail',
    'type' => 'switcher',
    'std' => 'no',

    'section' => 'misc',
    'section_title' => 'Miscellaneous',
];

$params[ 'live_indicator' ] = [
    'title' => 'Live Indicator (for LIVE posts)',
    'type' => 'switcher',
    'std' => 'yes',
];

$params[ 'live_indicator_color' ] = [
    'title' => 'Live Indicator Color',
    'type' => 'color',
    'std' => '#d0022c',
    
    'selectors' => [
        '{{WRAPPER}} .live-indicator' => 'color:{{VALUE}};',
        '{{WRAPPER}} .live-circle' => 'background:{{VALUE}};',
    ],
];
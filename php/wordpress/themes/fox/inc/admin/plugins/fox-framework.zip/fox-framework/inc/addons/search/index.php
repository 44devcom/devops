<?php
namespace Fox_Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Class;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Search extends Fox_Widget_Base {

	public function get_name() {
		return 'fox_search';
	}
    
    public function _base() {
        return 'search';
    }

	public function get_title() {
		return 'FOX Search Form';
	}
    
    public function get_keywords() {
		return [ 'search' ];
	}

	public function get_icon() {
        return 'eicon-search-bold';
	}
    
}
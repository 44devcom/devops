<?php
/* post class
---------------------------------------- */
$post_class = [ 'wi-post', 'post-item', 'post-list' ];

if ( isset( $settings[ 'post_extra_class' ] ) ) {
    $post_class[] = $settings[ 'post_extra_class' ];
}

/* post body
---------------------------------------- */
$post_body_class = [ 'post-body', 'post-item-body' ];
$post_body_class[] = 'list-body';
$post_body_class[] = 'post-list-body';

/**
 * title_hover_effect
 */
if ( isset( $settings[ 'title_hover_effect' ] ) ) {
    $post_class[] = 'style-title-hover-' . $settings[ 'title_hover_effect' ];
}

/* thumbnail
---------------------------------------- */
$thumbnail_args = $settings;

// position
$thumbnail_position = isset( $settings[ 'thumbnail_position' ] ) ? $settings[ 'thumbnail_position' ] : '';
if ( 'right' != $thumbnail_position && 'alternative' != $thumbnail_position ) $thumbnail_position = 'left';

if ( 'alternative' == $thumbnail_position ) {
    $final_thumbnail_position = ( $count % 2 ) ? 'right' : 'left';
} else {
    $final_thumbnail_position = $thumbnail_position;
}

$post_class[] = 'post-thumbnail-align-' . $final_thumbnail_position;

// extra
$thumbnail_args[ 'thumbnail_extra_class' ] = 'list-thumbnail';

/* valign
---------------------------------------- */
$list_valign = isset( $settings[ 'list_valign' ] ) ? $settings[ 'list_valign' ] : 'top';
if ( 'middle' != $list_valign && 'bottom' != $list_valign ) $list_valign = 'top';
$post_class[] = 'post-valign-' . $list_valign;

/* mobile layout
---------------------------------------- */
if ( ! isset( $settings[ 'list_mobile_layout' ] ) ) {
    $settings[ 'list_mobile_layout' ] = 'grid';
}
if ( 'list' != $settings[ 'list_mobile_layout' ] ) $settings[ 'list_mobile_layout' ] = 'grid';
$post_class[] = 'list-mobile-layout-' . $settings[ 'list_mobile_layout' ];

/* list sep
---------------------------------------- */
$sep_cl = [ 'post-list-sep' ];
if ( ! isset( $settings[ 'list_sep_style' ] ) ) {
    $settings[ 'list_sep_style' ] = 'solid';
}
$sep_cl[] = 'sep-' . $settings[ 'list_sep_style' ];

?>

<article <?php post_class( $post_class ); ?> itemscope itemtype="https://schema.org/CreativeWork">

    <?php if ( isset( $settings[ 'list_sep'] ) && 'yes' == $settings[ 'list_sep'] ) { ?>
    <div class="<?php echo esc_attr( join( ' ', $sep_cl ) ); ?>"></div>
    <?php } ?>
    
    <?php if ( isset( $settings[ 'list_index' ] ) && 'yes' == $settings[ 'list_index' ] ) { ?>
    <span class="post-list-count color-accent font-heading">
        <?php /* since v5.4, we display without leading printf("%02d", $settings[ 'count' ] ); */ echo $settings[ 'count' ]; ?>
    </span>
    <?php } ?>

    <div class="post-item-inner list-inner post-list-inner">
        
        <?php if ( isset( $settings[ 'show_thumbnail' ] ) && 'yes' == $settings[ 'show_thumbnail' ] ) {
            foxfw3_elementor_thumbnail( $thumbnail_args );
        } ?>
        
        <div class="<?php echo esc_attr( join( ' ', $post_body_class ) ); ?>">

            <div class="post-body-inner">

                <?php
                if ( is_engine_v6() ) {
                    foxfw3_elementor_post_body( $settings );
                } else {
                    fox_elementor_post_body( $settings );
                }
                ?>

            </div><!-- .post-body-inner -->

        </div><!-- .post-item-body -->

    </div><!-- .post-item-inner -->

</article><!-- .post-item -->
<?php
$settings = $this->get_settings_for_display();
extract( wp_parse_args( $settings, [
    'subtitle_preview_text' => '',
]) );

/* preview text
------------------------------ */
if ( ! $subtitle_preview_text ) {
    $subtitle_preview_text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';
}

if ( ! fox_is_edit() ) {
    $subtitle = trim( get_post_meta( get_the_ID(), '_wi_subtitle', true ) );
    if ( ! $subtitle ) {
        return;
    }
}

$cl = [ 'el-single-subtitle' ];

/**
 * final
 */
$cl = join( ' ', $cl );
?>

<div class="<?php echo esc_attr( $cl ); ?>">
    <?php if ( fox_is_edit() ) { ?>
    
    <span><?php echo $subtitle_preview_text; ?></span>
    
    <?php } else { ?>
    
    <?php echo $subtitle; ?>
    
    <?php } ?>
</div>